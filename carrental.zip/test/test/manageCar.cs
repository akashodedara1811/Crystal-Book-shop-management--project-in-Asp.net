﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;


namespace test
{
    public partial class manageCar : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adr;
        public manageCar()
        {
            InitializeComponent();
            string conne = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
            con = new SqlConnection(conne);
            con.Open();
            dis();
        }

        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            manageCar md = new manageCar();
            md.Show();
            this.Close();
        }

        private void gunaAdvenceButton2_Click_1(object sender, EventArgs e)
        {
            DashBoard ds = new DashBoard();
            ds.Show();
            this.Close();
        }

        private void gunaControlBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void managecars_Load(object sender, EventArgs e)
        {
           // Panel1.BackColor = Color.FromArgb(100, 0, 0, 0);
        }

        private void gunaAdvenceButton4_Click(object sender, EventArgs e)
        {
            ManageCutomer cs = new ManageCutomer();
            cs.Show();

            this.Close();
        }

        private void gunaAdvenceButton6_Click(object sender, EventArgs e)
        {
            ManageReturn re = new ManageReturn();
            re.Show();
            this.Close();
        }

        private void gunaAdvenceButton5_Click(object sender, EventArgs e)
        {
            RantCar rt = new RantCar();
            rt.Show();
            this.Close();
        }

        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                DialogResult ds = MessageBox.Show("please enter the value..", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
            Regex r2 = new Regex(@"[0-9]");
            bool checknum = r2.IsMatch(textBox4.Text);
            Regex r3 = new Regex(@"\d{4}");
            bool checkmodel = r3.IsMatch(textBox3.Text);
            int year = DateTime.Now.Year;
            if (Convert.ToInt16(textBox3.Text) >= year)
            {
                DialogResult rs = MessageBox.Show("Please enter valid Model Year.", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (checknum == false || checkmodel == false)
                {
                    if (checknum == false)
                    {
                        DialogResult rs = MessageBox.Show("Please enter digites only In price", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBox4.Focus();
                    }
                    else if (checkmodel == false)
                    {
                        DialogResult rs = MessageBox.Show("Please enter valid Model number.", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBox3.Focus();
                    }



                }

                else
                {
                    cmd = new SqlCommand("select * from manageCarsTbl where Regnum='" + textBox1.Text + "'", con);
                    adr = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adr.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        DialogResult rs = MessageBox.Show("this values are all ready inserted...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {

                            cmd = new SqlCommand("insert into manageCarsTbl values('" + textBox1.Text + "','" + textBox2.Text + "','" + Convert.ToInt16(textBox3.Text) + "','" + comboBox1.SelectedItem.ToString() + "','" + Convert.ToInt16(textBox4.Text) + "')", con);
                            int a = cmd.ExecuteNonQuery();
                            if (a > 0)
                            {
                                DialogResult rs = MessageBox.Show("data added...", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            textBox1.Text = "";
                            textBox2.Text = "";
                            textBox3.Text = "";
                            textBox4.Text = "";
                            comboBox1.SelectedIndex = -1;
                        }
                        dis();
                    }
                }
            }
        }

        public void dis()
        {
            cmd = new SqlCommand("Select * from manageCarsTbl", con);
            adr = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adr.Fill(dt);
            gunaDataGridView1.RowTemplate.Height = 40;

           gunaDataGridView1.DataSource = dt;
           gunaDataGridView1.Columns["Regnum"].HeaderText = "Registration Number";
           gunaDataGridView1.Columns["Brand"].HeaderText = "Car Name ";
           gunaDataGridView1.Columns["model"].HeaderText = "Car Model ";
           gunaDataGridView1.Columns["status"].HeaderText = "Available / Booked";
           gunaDataGridView1.Columns["price"].HeaderText = "Rant price ";
            
        }

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.ReadOnly = true;
            textBox1.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox2.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox3.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textBox4.Text = gunaDataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

        private void gunaAdvenceButton7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || comboBox1.SelectedIndex == -1)
            {
                DialogResult ds = MessageBox.Show("please enter the value..", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
            Regex r2 = new Regex(@"[0-9]");
            bool checknum = r2.IsMatch(textBox4.Text);
            Regex r3 = new Regex(@"\d{4}");
            bool checkmodel = r3.IsMatch(textBox3.Text);
            int year = DateTime.Now.Year;
            if (Convert.ToInt16(textBox3.Text) >= year)
            {
                DialogResult rs = MessageBox.Show("Please enter valid Model Year.", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                if (checknum == false || checkmodel == false)
                {
                    if (checknum == false)
                    {
                        DialogResult rs = MessageBox.Show("Please enter digites only In price", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBox4.Focus();
                    }
                    else if (checkmodel == false)
                    {
                        DialogResult rs = MessageBox.Show("Please enter valid Model number.", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBox3.Focus();
                    }



                }

                else
                {
                   

                        textBox1.ReadOnly = true;
                        cmd = new SqlCommand("update manageCarsTbl set Brand ='" + textBox2.Text + "',model='" + Convert.ToInt16(textBox3.Text) + "',status='" + comboBox1.SelectedItem.ToString() + "',price='" + Convert.ToInt16(textBox4.Text) + "' where Regnum='" + textBox1.Text + "'", con);
                        int a = cmd.ExecuteNonQuery();
                        if (a > 0)
                        {
                            DialogResult rs = MessageBox.Show("data Updated successfully..", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        comboBox1.SelectedIndex = -1;
                    }
                    dis();
                }
            }
        }

        private void gunaAdvenceButton8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "")
            {
                DialogResult ds = MessageBox.Show("please enter the value..", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                textBox1.ReadOnly = true;


                cmd = new SqlCommand("DELETE FROM manageCarsTbl where Regnum='" + textBox1.Text + "'", con);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    DialogResult rs = MessageBox.Show("data delete successfully..", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                comboBox1.SelectedIndex = -1;
            }
            dis();
        }

        private void gunaAdvenceButton9_Click(object sender, EventArgs e)
        {
            DialogResult rs = MessageBox.Show("Are you sure to Refresh the data?", "Refresh information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
          
            if (textBox1.ReadOnly == true)
            {
                textBox1.ReadOnly = false;
            }
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.SelectedIndex = -1;
            }

        private void gunaAdvenceButton10_Click(object sender, EventArgs e)
        {
            login c2 = new login();
            c2.Show();
            this.Hide();
        }
        
      
 
    }
}
