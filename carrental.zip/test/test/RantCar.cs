﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text.RegularExpressions;

namespace test
{
    public partial class RantCar : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adr;
        public RantCar()
        {
            InitializeComponent();
            string conne = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
            con = new SqlConnection(conne);
           
            dateTimePicker1.MinDate = DateTime.Now;
            dateTimePicker1.MaxDate = DateTime.Now.AddDays(50);
            getcar();
            getcustomer();
            displayRat();
            textBox4.Hide();
            gunaTextBox1.Visible = false;
            gunaTextBox2.Visible = false;
            textbox1.ReadOnly = true;
           
        }

        private void RantCar_Load(object sender, EventArgs e)
        {

        }

        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            DashBoard ds = new DashBoard();
            ds.Show();
            this.Close();
        }


        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            manageCar ca = new manageCar();
            ca.Show();
            this.Close();
        }

        private void gunaAdvenceButton4_Click(object sender, EventArgs e)
        {
            ManageCutomer cu = new ManageCutomer();
            cu.Show();
            this.Close();
        }

        private void gunaAdvenceButton5_Click(object sender, EventArgs e)
        {
            this.Show();
        }

        private void gunaAdvenceButton6_Click(object sender, EventArgs e)
        {
            ManageReturn re = new ManageReturn();
            re.Show();
            this.Close();
        }

        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("select * from managerantTbl where cname='" + comboBox1.Text + "'", con);
            adr = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adr.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DialogResult de = MessageBox.Show("this data allredy inserted...", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (comboBox1.Text == "" || comboBox2.Text == "" || dateTimePicker1.Text == "" || dateTimePicker2.Text == "" || textbox1.Text == "")
                {
                    DialogResult de = MessageBox.Show("Please enter value....", "information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                else
                {
                    Regex r1 = new Regex(@"^\d{10}$");
                    bool check = r1.IsMatch(textbox1.Text);
                    if (check == false)
                    {
                        DialogResult de = MessageBox.Show("please enter valid number...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textbox1.Focus();
                    }
                    else
                    {
                        cmd = new SqlCommand("insert into managerantTbl values('" + comboBox1.Text + "','" + comboBox2.Text + "','" + dateTimePicker1.Text + "','" + dateTimePicker2.Text + "','" + textbox1.Text + "')", con);
                        int ans = cmd.ExecuteNonQuery();
                        if (ans > 0)
                        {
                            DialogResult de = MessageBox.Show("Data inseted success fully...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        cmd = new SqlCommand("update manageCarsTbl set status='Booked' where Brand='" + comboBox1.Text + "'", con);
                        adr = new SqlDataAdapter(cmd);
                        DataTable dr = new DataTable();
                        adr.Fill(dr);

                    }
                }
                
                displayRat();
                getcar();
                textbox1.Text = "";
                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;
               

            }
            con.Close();
        }
        public void getcar()
        {
           
            cmd = new SqlCommand("select * from manageCarsTbl where status='Available'", con);
            adr = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adr.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.ValueMember = "id";
            comboBox1.DisplayMember = "Brand";
            con.Close();
        }
        public void displayRat()
        {
           
            cmd = new SqlCommand("select * from managerantTbl", con);
            adr = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataGridView1.RowTemplate.Height = 40;
            adr.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["Id"].HeaderText = "ID Number";
            dataGridView1.Columns["cname"].HeaderText = "Car Name ";
            dataGridView1.Columns["cuname"].HeaderText = "Customer Name ";
            dataGridView1.Columns["rantdate"].HeaderText = "Rant Date";
            dataGridView1.Columns["returndate"].HeaderText = "Return Date";
            dataGridView1.Columns["number"].HeaderText = "Customer Number ";
            con.Close();

        }
        public void getcustomer()
        {
           
            cmd = new SqlCommand("select * from managercustomer", con);
            adr = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adr.Fill(dt);
            comboBox2.DataSource = dt;
            comboBox2.ValueMember = "id";
            comboBox2.DisplayMember = "name";
            con.Close();
        }

        

        private void gunaAdvenceButton7_Click(object sender, EventArgs e)
        {
            con.Open();
            if (comboBox2.Text == "" || dateTimePicker1.Text == "" || dateTimePicker2.Text == "" || textbox1.Text == "")
            {
                DialogResult de = MessageBox.Show("Please enter value....", "information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            else
            {
                cmd = new SqlCommand("select * from managerantTbl where cuname='" + comboBox1.Text + "'", con);
                adr = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adr.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    DialogResult de = MessageBox.Show("this data allredy inserted...", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    Regex r1 = new Regex(@"^\d{10}$");
                    bool check = r1.IsMatch(textbox1.Text);
                    if (check == false)
                    {
                        DialogResult de = MessageBox.Show("please enter valid number...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textbox1.Focus();
                    }
                    else
                    {
                        if(gunaTextBox1.Visible =false)
                        {
                            DialogResult de = MessageBox.Show("please choose the value from list...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        cmd = new SqlCommand("update managerantTbl set rantdate='" + dateTimePicker1.Text + "', returndate='" + dateTimePicker2.Text + "', number='" + textbox1.Text + "' where Id='" + textBox4.Text + "'", con);
                        int ans = cmd.ExecuteNonQuery();
                        if (ans > 0)
                        {
                            DialogResult de = MessageBox.Show("Data updated success fully...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            displayRat();
            getcar();
            textbox1.Text = "";
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            comboBox1.Visible = true;
            comboBox2.Visible = true;
            gunaTextBox1.Visible = false;
            gunaTextBox2.Visible = false;
            con.Close();
        }

        private void gunaAdvenceButton8_Click(object sender, EventArgs e)
        {
            con.Open();
            if ( dateTimePicker1.Text=="" || dateTimePicker2.Text=="" || textbox1.Text=="" || textBox4.Text=="")
            {
                DialogResult de = MessageBox.Show("Please enter value....", "information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                cmd = new SqlCommand("delete from managerantTbl where id='" + textBox4.Text + "'", con);
                int ans = cmd.ExecuteNonQuery();
                if (ans > 0)
                {
                    DialogResult de = MessageBox.Show("Data Deleted success fully...", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                displayRat();
                cmd = new SqlCommand("update manageCarsTbl set status='Available' where Brand='" + gunaTextBox1.Text + "'", con);
                adr = new SqlDataAdapter(cmd);
                DataTable dr = new DataTable();
                adr.Fill(dr);

       
            }
          
            getcar();
            textbox1.Text = "";
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            comboBox1.Visible = true;
            comboBox2.Visible = true;
            gunaTextBox1.Visible = false ;
            gunaTextBox2.Visible = false;
            con.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            con.Open();
            comboBox1.Visible = false;
            comboBox2.Visible = false;
            gunaTextBox1.Visible = true;
            gunaTextBox2.Visible = true;
            
            textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            gunaTextBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            gunaTextBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textbox1.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                dateTimePicker1.CustomFormat = "D/D/Y";
                dateTimePicker2.CustomFormat = "D/D/Y";
                con.Close();
        }

        private void dateTimePicker1_ValueChanged_1(object sender, EventArgs e)
        {
            con.Open();
            dateTimePicker2.MinDate = dateTimePicker1.Value;
            dateTimePicker2.MaxDate = dateTimePicker1.Value.AddDays(30);
            dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            dateTimePicker2.CustomFormat = "dd/MM/yyyy";
            con.Close();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            cmd = new SqlCommand("select phone from managercustomer where name='"+comboBox2.Text+"'",con);
            
            con.Open();
            SqlDataReader dt = cmd.ExecuteReader();
            while (dt.Read())
            {
                textbox1.Text = dt["phone"].ToString();
            }
            con.Close();
        }

        private void gunaAdvenceButton9_Click(object sender, EventArgs e)
        {
            DialogResult rs = MessageBox.Show("Are you sure to Refresh the data?", "Refresh information", MessageBoxButtons.OK, MessageBoxIcon.Information);


          
            textbox1.Text = "";
            textBox4.Text = "";
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            comboBox1.Visible = true;
            comboBox2.Visible = true;
            gunaTextBox1.Visible = false;
            gunaTextBox2.Visible = false;
            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker2.Value = dateTimePicker1.Value;
        }

        private void gunaAdvenceButton10_Click(object sender, EventArgs e)
        {
            login c2 = new login();
            c2.Show();
            this.Hide();
        }

        
    }
}
