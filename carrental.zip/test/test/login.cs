﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Data;
using System.Configuration;
namespace test
{
    public partial class login : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adr;
        public login()
        {
            InitializeComponent();
            string conne = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
            con = new SqlConnection(conne);
            con.Open();
            gunaTextBox1.UseSystemPasswordChar = true;
            if (textBox1.Text == "")
            {
                textBox1.Text = "Please enter Name";

            }
            if (gunaTextBox1.Text == "")
            
            {
                gunaTextBox1.Text = "Please enter Passwored:";

            }
            gunaAdvenceButton3.Visible = false;
        }
        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "" || gunaTextBox1.Text == "")
            {
                   DialogResult rs = MessageBox.Show("please enter username & passwored", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cmd = new SqlCommand("select * from reguserTbl where username='" + textBox1.Text + "'and password='" + gunaTextBox1.Text +"'", con);
            adr = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adr.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DashBoard c1 = new DashBoard();
                c1.Show();
                this.Hide();
            }
            else
            {
                DialogResult rs = MessageBox.Show("not valid..", "NOT VALID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Show();
                textBox1.Text = "";
                gunaTextBox1.Text = "";
            }
            }
        }

      
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (textBox1.Text == "Please enter Name")
            {
                textBox1.Text = "";

            }
        }

        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            gunaTextBox1.UseSystemPasswordChar = false;
            gunaAdvenceButton3.Show();
            gunaAdvenceButton2.Visible = false;
        }

        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            gunaTextBox1.UseSystemPasswordChar = true;
            gunaAdvenceButton2.Show();
            gunaAdvenceButton3.Visible = false;
        }

        private void gunaTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (gunaTextBox1.Text == "Please enter Passwored:")
            {
                gunaTextBox1.Text = "";

            }
        }

      

        

       

       

       


    }
}
