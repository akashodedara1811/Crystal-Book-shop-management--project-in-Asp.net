﻿namespace test
{
    partial class ManageCutomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManageCutomer));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gunaAdvenceButton3 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaDataGridView1 = new Guna.UI.WinForms.GunaDataGridView();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.gunaAdvenceButton9 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton8 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton7 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton1 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaAdvenceButton4 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.textBox4 = new Guna.UI.WinForms.GunaTextBox();
            this.textBox3 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaControlBox4 = new Guna.UI.WinForms.GunaControlBox();
            this.gunaCirclePictureBox1 = new Guna.UI.WinForms.GunaCirclePictureBox();
            this.gunaAdvenceButton6 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.textBox2 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaControlBox5 = new Guna.UI.WinForms.GunaControlBox();
            this.gunaLinePanel1 = new Guna.UI.WinForms.GunaLinePanel();
            this.gunaAdvenceButton11 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton5 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaAdvenceButton2 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaControlBox3 = new Guna.UI.WinForms.GunaControlBox();
            this.gunaControlBox2 = new Guna.UI.WinForms.GunaControlBox();
            this.textBox1 = new Guna.UI.WinForms.GunaTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.gunaDataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).BeginInit();
            this.gunaLinePanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaAdvenceButton3
            // 
            this.gunaAdvenceButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaAdvenceButton3.Animated = true;
            this.gunaAdvenceButton3.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton3.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton3.BaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton3.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton3.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton3.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton3.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton3.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton3.CheckedImage")));
            this.gunaAdvenceButton3.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton3.ForeColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton3.Image = null;
            this.gunaAdvenceButton3.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton3.LineBottom = 5;
            this.gunaAdvenceButton3.LineColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton3.Location = new System.Drawing.Point(390, 3);
            this.gunaAdvenceButton3.Name = "gunaAdvenceButton3";
            this.gunaAdvenceButton3.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton3.OnHoverForeColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton3.OnHoverImage = null;
            this.gunaAdvenceButton3.OnHoverLineColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gunaAdvenceButton3.Size = new System.Drawing.Size(122, 39);
            this.gunaAdvenceButton3.TabIndex = 1;
            this.gunaAdvenceButton3.Text = "Cars";
            this.gunaAdvenceButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton3.Click += new System.EventHandler(this.gunaAdvenceButton3_Click);
            // 
            // gunaDataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.gunaDataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.gunaDataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaDataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gunaDataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.gunaDataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gunaDataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gunaDataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gunaDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.gunaDataGridView1.ColumnHeadersHeight = 30;
            this.gunaDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gunaDataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.gunaDataGridView1.EnableHeadersVisualStyles = false;
            this.gunaDataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gunaDataGridView1.Location = new System.Drawing.Point(12, 308);
            this.gunaDataGridView1.Name = "gunaDataGridView1";
            this.gunaDataGridView1.RowHeadersVisible = false;
            this.gunaDataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.gunaDataGridView1.Size = new System.Drawing.Size(967, 328);
            this.gunaDataGridView1.TabIndex = 73;
            this.gunaDataGridView1.Theme = Guna.UI.WinForms.GunaDataGridViewPresetThemes.Guna;
            this.gunaDataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.gunaDataGridView1.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.gunaDataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.gunaDataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.gunaDataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.gunaDataGridView1.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.gunaDataGridView1.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gunaDataGridView1.ThemeStyle.HeaderStyle.Height = 30;
            this.gunaDataGridView1.ThemeStyle.ReadOnly = false;
            this.gunaDataGridView1.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.gunaDataGridView1.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.gunaDataGridView1.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.gunaDataGridView1.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.gunaDataGridView1.ThemeStyle.RowsStyle.Height = 22;
            this.gunaDataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.gunaDataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.gunaDataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gunaDataGridView1_CellContentClick);
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel7.ForeColor = System.Drawing.Color.OliveDrab;
            this.gunaLabel7.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.gunaLabel7.Location = new System.Drawing.Point(48, 263);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Padding = new System.Windows.Forms.Padding(13, 2, 13, 3);
            this.gunaLabel7.Size = new System.Drawing.Size(183, 33);
            this.gunaLabel7.TabIndex = 72;
            this.gunaLabel7.Text = "Customer List :";
            this.gunaLabel7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // gunaAdvenceButton9
            // 
            this.gunaAdvenceButton9.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton9.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton9.BackColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton9.BaseColor = System.Drawing.Color.Turquoise;
            this.gunaAdvenceButton9.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton9.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton9.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton9.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton9.CheckedImage = null;
            this.gunaAdvenceButton9.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton9.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton9.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton9.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaAdvenceButton9.ForeColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton9.Image = null;
            this.gunaAdvenceButton9.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton9.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton9.Location = new System.Drawing.Point(573, 224);
            this.gunaAdvenceButton9.Name = "gunaAdvenceButton9";
            this.gunaAdvenceButton9.OnHoverBaseColor = System.Drawing.Color.Turquoise;
            this.gunaAdvenceButton9.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton9.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton9.OnHoverImage = null;
            this.gunaAdvenceButton9.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton9.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton9.Radius = 8;
            this.gunaAdvenceButton9.Size = new System.Drawing.Size(105, 34);
            this.gunaAdvenceButton9.TabIndex = 71;
            this.gunaAdvenceButton9.Text = "Save";
            this.gunaAdvenceButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton9.Click += new System.EventHandler(this.gunaAdvenceButton9_Click);
            // 
            // gunaAdvenceButton8
            // 
            this.gunaAdvenceButton8.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton8.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton8.BackColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton8.BaseColor = System.Drawing.Color.Red;
            this.gunaAdvenceButton8.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton8.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton8.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton8.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton8.CheckedImage = null;
            this.gunaAdvenceButton8.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton8.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton8.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaAdvenceButton8.ForeColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton8.Image = null;
            this.gunaAdvenceButton8.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton8.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton8.Location = new System.Drawing.Point(438, 224);
            this.gunaAdvenceButton8.Name = "gunaAdvenceButton8";
            this.gunaAdvenceButton8.OnHoverBaseColor = System.Drawing.Color.Brown;
            this.gunaAdvenceButton8.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton8.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton8.OnHoverImage = null;
            this.gunaAdvenceButton8.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton8.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton8.Radius = 8;
            this.gunaAdvenceButton8.Size = new System.Drawing.Size(105, 34);
            this.gunaAdvenceButton8.TabIndex = 70;
            this.gunaAdvenceButton8.Text = "Remove";
            this.gunaAdvenceButton8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton8.Click += new System.EventHandler(this.gunaAdvenceButton8_Click);
            // 
            // gunaAdvenceButton7
            // 
            this.gunaAdvenceButton7.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton7.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton7.BackColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton7.BaseColor = System.Drawing.Color.Yellow;
            this.gunaAdvenceButton7.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton7.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton7.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton7.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton7.CheckedImage = null;
            this.gunaAdvenceButton7.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton7.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton7.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaAdvenceButton7.ForeColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton7.Image = null;
            this.gunaAdvenceButton7.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton7.Location = new System.Drawing.Point(302, 224);
            this.gunaAdvenceButton7.Name = "gunaAdvenceButton7";
            this.gunaAdvenceButton7.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.gunaAdvenceButton7.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton7.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton7.OnHoverImage = null;
            this.gunaAdvenceButton7.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton7.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton7.Radius = 8;
            this.gunaAdvenceButton7.Size = new System.Drawing.Size(105, 34);
            this.gunaAdvenceButton7.TabIndex = 69;
            this.gunaAdvenceButton7.Text = "Edit";
            this.gunaAdvenceButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton7.Click += new System.EventHandler(this.gunaAdvenceButton7_Click);
            // 
            // gunaAdvenceButton1
            // 
            this.gunaAdvenceButton1.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton1.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton1.BaseColor = System.Drawing.Color.DodgerBlue;
            this.gunaAdvenceButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton1.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton1.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton1.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton1.CheckedImage = null;
            this.gunaAdvenceButton1.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaAdvenceButton1.ForeColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton1.Image = null;
            this.gunaAdvenceButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton1.Location = new System.Drawing.Point(160, 224);
            this.gunaAdvenceButton1.Name = "gunaAdvenceButton1";
            this.gunaAdvenceButton1.OnHoverBaseColor = System.Drawing.Color.DeepSkyBlue;
            this.gunaAdvenceButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton1.OnHoverImage = null;
            this.gunaAdvenceButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(58)))), ((int)(((byte)(170)))));
            this.gunaAdvenceButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton1.Radius = 8;
            this.gunaAdvenceButton1.Size = new System.Drawing.Size(105, 34);
            this.gunaAdvenceButton1.TabIndex = 68;
            this.gunaAdvenceButton1.Text = "Save";
            this.gunaAdvenceButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton1.Click += new System.EventHandler(this.gunaAdvenceButton1_Click);
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel6.Location = new System.Drawing.Point(774, 128);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(143, 21);
            this.gunaLabel6.TabIndex = 66;
            this.gunaLabel6.Text = "Customer Number:";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel4.Location = new System.Drawing.Point(420, 128);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(141, 21);
            this.gunaLabel4.TabIndex = 62;
            this.gunaLabel4.Text = "Customer Address:";
            // 
            // gunaAdvenceButton4
            // 
            this.gunaAdvenceButton4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaAdvenceButton4.Animated = true;
            this.gunaAdvenceButton4.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton4.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton4.BaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton4.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton4.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton4.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton4.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton4.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton4.CheckedImage")));
            this.gunaAdvenceButton4.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton4.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton4.ForeColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton4.Image = null;
            this.gunaAdvenceButton4.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton4.LineBottom = 5;
            this.gunaAdvenceButton4.LineColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton4.Location = new System.Drawing.Point(518, 3);
            this.gunaAdvenceButton4.Name = "gunaAdvenceButton4";
            this.gunaAdvenceButton4.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton4.OnHoverForeColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton4.OnHoverImage = null;
            this.gunaAdvenceButton4.OnHoverLineColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gunaAdvenceButton4.Size = new System.Drawing.Size(122, 39);
            this.gunaAdvenceButton4.TabIndex = 2;
            this.gunaAdvenceButton4.Text = "Customers";
            this.gunaAdvenceButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton4.Click += new System.EventHandler(this.gunaAdvenceButton4_Click);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.Transparent;
            this.textBox4.BaseColor = System.Drawing.Color.White;
            this.textBox4.BorderColor = System.Drawing.Color.Silver;
            this.textBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox4.FocusedBaseColor = System.Drawing.Color.White;
            this.textBox4.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.textBox4.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox4.Location = new System.Drawing.Point(769, 152);
            this.textBox4.Name = "textBox4";
            this.textBox4.PasswordChar = '\0';
            this.textBox4.Radius = 10;
            this.textBox4.SelectedText = "";
            this.textBox4.Size = new System.Drawing.Size(160, 30);
            this.textBox4.TabIndex = 64;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.Transparent;
            this.textBox3.BaseColor = System.Drawing.Color.White;
            this.textBox3.BorderColor = System.Drawing.Color.Silver;
            this.textBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox3.FocusedBaseColor = System.Drawing.Color.White;
            this.textBox3.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.textBox3.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox3.Location = new System.Drawing.Point(413, 152);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.PasswordChar = '\0';
            this.textBox3.Radius = 10;
            this.textBox3.SelectedText = "";
            this.textBox3.Size = new System.Drawing.Size(165, 52);
            this.textBox3.TabIndex = 63;
            // 
            // gunaControlBox4
            // 
            this.gunaControlBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox4.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox4.AnimationSpeed = 0.03F;
            this.gunaControlBox4.BackColor = System.Drawing.Color.Transparent;
            this.gunaControlBox4.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MaximizeBox;
            this.gunaControlBox4.IconColor = System.Drawing.Color.Black;
            this.gunaControlBox4.IconSize = 15F;
            this.gunaControlBox4.Location = new System.Drawing.Point(883, 7);
            this.gunaControlBox4.Name = "gunaControlBox4";
            this.gunaControlBox4.OnHoverBackColor = System.Drawing.Color.DimGray;
            this.gunaControlBox4.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox4.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox4.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox4.TabIndex = 55;
            // 
            // gunaCirclePictureBox1
            // 
            this.gunaCirclePictureBox1.BaseColor = System.Drawing.Color.Transparent;
            this.gunaCirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaCirclePictureBox1.Image")));
            this.gunaCirclePictureBox1.Location = new System.Drawing.Point(0, 0);
            this.gunaCirclePictureBox1.Name = "gunaCirclePictureBox1";
            this.gunaCirclePictureBox1.Size = new System.Drawing.Size(187, 45);
            this.gunaCirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaCirclePictureBox1.TabIndex = 51;
            this.gunaCirclePictureBox1.TabStop = false;
            this.gunaCirclePictureBox1.UseTransfarantBackground = false;
            // 
            // gunaAdvenceButton6
            // 
            this.gunaAdvenceButton6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaAdvenceButton6.Animated = true;
            this.gunaAdvenceButton6.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton6.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton6.BaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton6.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton6.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton6.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton6.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton6.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton6.CheckedImage")));
            this.gunaAdvenceButton6.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton6.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton6.ForeColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton6.Image = null;
            this.gunaAdvenceButton6.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton6.LineBottom = 5;
            this.gunaAdvenceButton6.LineColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton6.Location = new System.Drawing.Point(774, 3);
            this.gunaAdvenceButton6.Name = "gunaAdvenceButton6";
            this.gunaAdvenceButton6.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton6.OnHoverForeColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton6.OnHoverImage = null;
            this.gunaAdvenceButton6.OnHoverLineColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton6.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gunaAdvenceButton6.Size = new System.Drawing.Size(122, 39);
            this.gunaAdvenceButton6.TabIndex = 4;
            this.gunaAdvenceButton6.Text = "Return";
            this.gunaAdvenceButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton6.Click += new System.EventHandler(this.gunaAdvenceButton6_Click);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.Transparent;
            this.textBox2.BaseColor = System.Drawing.Color.White;
            this.textBox2.BorderColor = System.Drawing.Color.Silver;
            this.textBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox2.FocusedBaseColor = System.Drawing.Color.White;
            this.textBox2.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.textBox2.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox2.Location = new System.Drawing.Point(37, 152);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '\0';
            this.textBox2.Radius = 10;
            this.textBox2.SelectedText = "";
            this.textBox2.Size = new System.Drawing.Size(160, 30);
            this.textBox2.TabIndex = 59;
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.Location = new System.Drawing.Point(43, 128);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(131, 21);
            this.gunaLabel2.TabIndex = 58;
            this.gunaLabel2.Text = "Customer Name :";
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.ForeColor = System.Drawing.Color.OliveDrab;
            this.gunaLabel1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.gunaLabel1.Location = new System.Drawing.Point(445, 45);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Padding = new System.Windows.Forms.Padding(13, 2, 13, 3);
            this.gunaLabel1.Size = new System.Drawing.Size(229, 33);
            this.gunaLabel1.TabIndex = 57;
            this.gunaLabel1.Text = "Manage Customers:";
            this.gunaLabel1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // gunaControlBox5
            // 
            this.gunaControlBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox5.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox5.AnimationSpeed = 0.03F;
            this.gunaControlBox5.BackColor = System.Drawing.Color.Transparent;
            this.gunaControlBox5.IconColor = System.Drawing.Color.Black;
            this.gunaControlBox5.IconSize = 15F;
            this.gunaControlBox5.Location = new System.Drawing.Point(929, 7);
            this.gunaControlBox5.Name = "gunaControlBox5";
            this.gunaControlBox5.OnHoverBackColor = System.Drawing.Color.DimGray;
            this.gunaControlBox5.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox5.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox5.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox5.TabIndex = 56;
            // 
            // gunaLinePanel1
            // 
            this.gunaLinePanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaLinePanel1.BackColor = System.Drawing.Color.Transparent;
            this.gunaLinePanel1.Controls.Add(this.gunaAdvenceButton11);
            this.gunaLinePanel1.Controls.Add(this.gunaAdvenceButton6);
            this.gunaLinePanel1.Controls.Add(this.gunaAdvenceButton5);
            this.gunaLinePanel1.Controls.Add(this.gunaAdvenceButton4);
            this.gunaLinePanel1.Controls.Add(this.gunaAdvenceButton3);
            this.gunaLinePanel1.Controls.Add(this.gunaAdvenceButton2);
            this.gunaLinePanel1.Controls.Add(this.gunaLabel1);
            this.gunaLinePanel1.LineColor = System.Drawing.Color.Black;
            this.gunaLinePanel1.LineStyle = System.Windows.Forms.BorderStyle.None;
            this.gunaLinePanel1.Location = new System.Drawing.Point(-12, 39);
            this.gunaLinePanel1.Name = "gunaLinePanel1";
            this.gunaLinePanel1.Size = new System.Drawing.Size(1120, 120);
            this.gunaLinePanel1.TabIndex = 54;
            // 
            // gunaAdvenceButton11
            // 
            this.gunaAdvenceButton11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaAdvenceButton11.Animated = true;
            this.gunaAdvenceButton11.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton11.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton11.BackColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton11.BaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton11.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton11.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton11.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton11.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton11.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton11.CheckedImage")));
            this.gunaAdvenceButton11.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton11.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton11.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton11.ForeColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton11.Image = null;
            this.gunaAdvenceButton11.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton11.LineBottom = 5;
            this.gunaAdvenceButton11.LineColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton11.Location = new System.Drawing.Point(899, 3);
            this.gunaAdvenceButton11.Name = "gunaAdvenceButton11";
            this.gunaAdvenceButton11.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton11.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton11.OnHoverForeColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton11.OnHoverImage = null;
            this.gunaAdvenceButton11.OnHoverLineColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton11.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton11.Radius = 7;
            this.gunaAdvenceButton11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gunaAdvenceButton11.Size = new System.Drawing.Size(87, 30);
            this.gunaAdvenceButton11.TabIndex = 75;
            this.gunaAdvenceButton11.Text = "Logout";
            this.gunaAdvenceButton11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton11.Click += new System.EventHandler(this.gunaAdvenceButton11_Click);
            // 
            // gunaAdvenceButton5
            // 
            this.gunaAdvenceButton5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaAdvenceButton5.Animated = true;
            this.gunaAdvenceButton5.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton5.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton5.BaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton5.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton5.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton5.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton5.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton5.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton5.CheckedImage")));
            this.gunaAdvenceButton5.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton5.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton5.ForeColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton5.Image = null;
            this.gunaAdvenceButton5.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton5.LineBottom = 5;
            this.gunaAdvenceButton5.LineColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton5.Location = new System.Drawing.Point(646, 3);
            this.gunaAdvenceButton5.Name = "gunaAdvenceButton5";
            this.gunaAdvenceButton5.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton5.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton5.OnHoverForeColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton5.OnHoverImage = null;
            this.gunaAdvenceButton5.OnHoverLineColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton5.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gunaAdvenceButton5.Size = new System.Drawing.Size(122, 39);
            this.gunaAdvenceButton5.TabIndex = 3;
            this.gunaAdvenceButton5.Text = "Rant";
            this.gunaAdvenceButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton5.Click += new System.EventHandler(this.gunaAdvenceButton5_Click);
            // 
            // gunaAdvenceButton2
            // 
            this.gunaAdvenceButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaAdvenceButton2.Animated = true;
            this.gunaAdvenceButton2.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton2.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton2.BaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton2.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton2.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton2.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton2.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton2.CheckedImage")));
            this.gunaAdvenceButton2.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton2.ForeColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton2.Image = null;
            this.gunaAdvenceButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton2.LineBottom = 5;
            this.gunaAdvenceButton2.LineColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton2.Location = new System.Drawing.Point(262, 3);
            this.gunaAdvenceButton2.Name = "gunaAdvenceButton2";
            this.gunaAdvenceButton2.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton2.OnHoverBorderColor = System.Drawing.Color.White;
            this.gunaAdvenceButton2.OnHoverForeColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton2.OnHoverImage = null;
            this.gunaAdvenceButton2.OnHoverLineColor = System.Drawing.Color.DarkGray;
            this.gunaAdvenceButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.gunaAdvenceButton2.Size = new System.Drawing.Size(122, 39);
            this.gunaAdvenceButton2.TabIndex = 0;
            this.gunaAdvenceButton2.Text = "DashBoard";
            this.gunaAdvenceButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton2.Click += new System.EventHandler(this.gunaAdvenceButton2_Click);
            // 
            // gunaControlBox3
            // 
            this.gunaControlBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox3.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox3.AnimationSpeed = 0.03F;
            this.gunaControlBox3.BackColor = System.Drawing.Color.Transparent;
            this.gunaControlBox3.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MinimizeBox;
            this.gunaControlBox3.IconColor = System.Drawing.Color.Black;
            this.gunaControlBox3.IconSize = 15F;
            this.gunaControlBox3.Location = new System.Drawing.Point(820, 7);
            this.gunaControlBox3.Name = "gunaControlBox3";
            this.gunaControlBox3.OnHoverBackColor = System.Drawing.Color.DimGray;
            this.gunaControlBox3.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox3.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox3.TabIndex = 53;
            // 
            // gunaControlBox2
            // 
            this.gunaControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox2.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox2.AnimationSpeed = 0.03F;
            this.gunaControlBox2.BackColor = System.Drawing.Color.Transparent;
            this.gunaControlBox2.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MaximizeBox;
            this.gunaControlBox2.IconColor = System.Drawing.Color.Black;
            this.gunaControlBox2.IconSize = 15F;
            this.gunaControlBox2.Location = new System.Drawing.Point(974, 10);
            this.gunaControlBox2.Name = "gunaControlBox2";
            this.gunaControlBox2.OnHoverBackColor = System.Drawing.Color.DimGray;
            this.gunaControlBox2.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox2.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox2.TabIndex = 52;
            // 
            // textBox1
            // 
            this.textBox1.BaseColor = System.Drawing.Color.White;
            this.textBox1.BorderColor = System.Drawing.Color.Silver;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox1.FocusedBaseColor = System.Drawing.Color.White;
            this.textBox1.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.textBox1.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.textBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBox1.Location = new System.Drawing.Point(3, 152);
            this.textBox1.Name = "textBox1";
            this.textBox1.PasswordChar = '\0';
            this.textBox1.SelectedText = "";
            this.textBox1.Size = new System.Drawing.Size(28, 30);
            this.textBox1.TabIndex = 74;
            // 
            // ManageCutomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(975, 611);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.gunaDataGridView1);
            this.Controls.Add(this.gunaLabel7);
            this.Controls.Add(this.gunaAdvenceButton9);
            this.Controls.Add(this.gunaAdvenceButton8);
            this.Controls.Add(this.gunaAdvenceButton7);
            this.Controls.Add(this.gunaAdvenceButton1);
            this.Controls.Add(this.gunaLabel6);
            this.Controls.Add(this.gunaLabel4);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.gunaControlBox4);
            this.Controls.Add(this.gunaCirclePictureBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.gunaLabel2);
            this.Controls.Add(this.gunaControlBox5);
            this.Controls.Add(this.gunaLinePanel1);
            this.Controls.Add(this.gunaControlBox3);
            this.Controls.Add(this.gunaControlBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ManageCutomer";
            this.Text = "ManageCutomer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.gunaDataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaCirclePictureBox1)).EndInit();
            this.gunaLinePanel1.ResumeLayout(false);
            this.gunaLinePanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton3;
        private Guna.UI.WinForms.GunaDataGridView gunaDataGridView1;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton9;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton8;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton7;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton1;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton4;
        private Guna.UI.WinForms.GunaTextBox textBox4;
        private Guna.UI.WinForms.GunaTextBox textBox3;
        private Guna.UI.WinForms.GunaControlBox gunaControlBox4;
        private Guna.UI.WinForms.GunaCirclePictureBox gunaCirclePictureBox1;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton6;
        private Guna.UI.WinForms.GunaTextBox textBox2;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaControlBox gunaControlBox5;
        private Guna.UI.WinForms.GunaLinePanel gunaLinePanel1;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton5;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton2;
        private Guna.UI.WinForms.GunaControlBox gunaControlBox3;
        private Guna.UI.WinForms.GunaControlBox gunaControlBox2;
        private Guna.UI.WinForms.GunaTextBox textBox1;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton11;
    }
}