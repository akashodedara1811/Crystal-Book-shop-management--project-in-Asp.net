<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With");
include "con.php";
$data = json_decode(file_get_contents("php://input"), true);
$pname = $data['proname'];
$pdes = $data['prodes'];
$pcat = $data['procat'];
$psub = $data['prosub'];
$pprice = $data['proprice'];
$pstock = $data['prostock'];
$q = "insert into product(pname,pdes,pcat,psub,pprice,pstock) values('{$pname}','{$pdes}','{$pcat}','{$psub}','{$pprice}','{$pstock}')";
if(mysqli_query($con,$q))
{
  echo json_encode("Recored inserted...");
}
else
{
    echo json_encode("Recored Not inserted...");
}
?>