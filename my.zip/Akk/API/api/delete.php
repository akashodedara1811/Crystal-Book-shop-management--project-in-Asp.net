<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With");
  
$con = mysqli_connect("localhost","root","root","Ajax_catlog");
$data = json_decode(file_get_contents("php://input"),true);
$proid =$data['proid'];
$q = "delete from product where id = '{$proid}'";

if(mysqli_query($con,$q))
{
    http_response_code(200);
   echo json_encode("Recored Deleted....");
}
else
{
  //  http_response_code(404);
    echo json_encode("Recored Not Deleted....");

}
?>