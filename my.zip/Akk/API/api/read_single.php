<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
$product_arr['records'] = array();
$product_itrem = array();
$data =  json_decode(file_get_contents("php://input"),true);
$pid = $data['proid'];
$con = mysqli_connect("localhost","root","root","Ajax_catlog");
$q = mysqli_query($con,"select * from product where id={$pid}");
if(mysqli_num_rows($q) > 0)
{
while($r = mysqli_fetch_assoc($q))
{
    extract($r);
   
    $product_itrem= array(
        "id" => $id,
        "pname" => $pname,
        "pdes"=>$pdes,
        "pcat"=>$pcat,
        "psub"=> $psub,
        "pprice"=> $pprice,
        "pstock"=> $pstock, 
    );
    array_push($product_arr['records'],$product_itrem);
}
http_response_code(200);
echo json_encode($product_arr); 
}
else
{
  http_response_code(404);
  echo json_encode("Recored are not found...");
}
?>