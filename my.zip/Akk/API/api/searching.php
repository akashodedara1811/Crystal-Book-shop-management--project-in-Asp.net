<?php
header("Content-type:application/json");
header("Access-Control-Allow-Methods: GET");
include "con.php";

$data = json_decode(file_get_contents("php://input"),true);
$search['searching_item'] = array();
$pname = isset($_GET['search']) ? $_GET['search'] : die();
$q = mysqli_query($con,"select * from product where pname like'%{$pname}%'");
if(mysqli_num_rows($q) > 0)
{
$out = mysqli_fetch_all($q,MYSQLI_ASSOC);
http_response_code(200);
echo json_encode($out);
}
else
{
    http_response_code(404);
echo json_encode("Recored not found");
}
?>