<?php
header("Content-type:application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers:Content-type,Access-Control-Allow-Origin,Access-Control-Allow-Methods, Authorization, X-Requested-With");

$con = mysqli_connect("localhost","root","root","Ajax_catlog");
$data= json_decode(file_get_contents("php://input"),true);
$pid = $data['proid'];
$pname = $data['proname'];
$pdes = $data['prodes'];
$pcat = $data['procat'];
$psub = $data['prosub'];
$pprice = $data['proprice'];
$pstock = $data['prostock'];

$q = "update product set pname='{$pname}',pdes='{$pdes}',pcat='{$pcat}',psub='{$psub}',pprice='{$pprice}',pstock='{$pstock}' where id='{$pid}'";
if(mysqli_query($con,$q))
{
    echo json_encode("Recored SuccessFully Updted....");
}
else
{   
    echo json_encode("Recored Not Updted....");
} 
?>