<?php
header("Content-type:application/json");
header("Access-Control-Allow-Methods:POST");
header("Access-Control-Allow-Origin: *");
$arr = array();
$data = json_decode(file_get_contents("php://input"),true);
$cname = $data['catname'];
include "con.php";
$q = mysqli_query($con,"select csname from category where cname='{$cname}'");
if(mysqli_num_rows($q) > 0)
{
    http_response_code(200);
    $arr = mysqli_fetch_all($q,MYSQLI_ASSOC);
   echo json_encode($arr);
}
else
{

    http_response_code(404);
    $arr = mysqli_fetch_all($q,MYSQLI_ASSOC);
    echo json_encode("Data Not found..");
}
?>