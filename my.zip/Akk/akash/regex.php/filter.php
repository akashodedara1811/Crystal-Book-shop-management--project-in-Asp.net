<?php
// Variable to check
$url="https://www.w3schools.com";

// Encode characters
$url = filter_var($url, FILTER_SANITIZE_ENCODED);//its not working
echo $url;
?> 