<?php
$text1 = "Hello Akash odedara";
$text = trim($text1);
echo $text;
$patter= "/./";
echo preg_match_all($patter,$text);
//echo phpinfo();
?>