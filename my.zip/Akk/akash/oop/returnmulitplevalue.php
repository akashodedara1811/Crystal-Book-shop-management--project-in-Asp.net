<?php
abstract class abcd
{
    abstract protected function testing($nm);
}
class def extends abcd
{
    public function testing($nm,$work=" grate Work")
    {
        return "{$nm}{$work}";
    }
}
$dea = new def();
echo $dea -> testing("akash");

?>