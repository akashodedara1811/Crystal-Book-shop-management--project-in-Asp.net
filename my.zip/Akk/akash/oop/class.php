<?php
class name{// create class
    function myname()
    {
        echo "akash odedara";
    }
}
$class = new name();//create object
echo $class -> myname();
?>