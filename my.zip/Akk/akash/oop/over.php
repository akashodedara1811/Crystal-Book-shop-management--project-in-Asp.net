<?php
class cl1
{
    public $name;
    public $address;
    public function log($name,$address)
    {
        echo "name is {$name} and address is {$address}";
    }
}
class cl2 extends cl1
{
    public function log($name,$address,$age)
    {
        echo "name is {$name} and address is {$address} and age {$age}";
    }
}

$cla = new cl2();
$cla -> log("akash","junagadh","21");
?>