<?php
trait welcome
{
    public function t1()
    {
        echo "Welcome Akash";
    }
}
trait company
{
    public function t2()
    {
        echo "\tTo lujan infoways";
    }
}
class pr
{
  
        use welcome;
        use company;

}
$nm = new pr();
$nm->t1();
$nm->t2();
?>