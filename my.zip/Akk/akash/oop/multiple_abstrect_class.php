<?php
abstract class t1
{
    abstract protected function data();
}
class t2 extends t1
{
   public function data()
   {
    echo "this is a abstract class";
   }
}
class t3 extends t2
{
    public function print()
    {
        echo "this is last class";
    }
}
$new = new t3();
echo "<br>";
$new -> data();
echo "<br>";
$new -> print();
?>