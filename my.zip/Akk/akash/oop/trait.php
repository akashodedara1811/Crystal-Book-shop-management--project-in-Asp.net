<?php
trait welocome{
    public function well()
    {
      echo "Welcome to lujayn infoways";
    }
}
class del
{
    
        use welocome;
    
}
$namespace = new del();
$namespace->well();
?>