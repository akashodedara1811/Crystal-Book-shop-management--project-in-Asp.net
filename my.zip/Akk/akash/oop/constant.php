<?php
class t1
{
 const name = "Akash from Junagadh";
}
echo t1::name;
echo self::name;
?>