<?php
class frute{
    public $name;
    public $price;
    public function __construct($name,$price)
    {
        $this->name=$name;
        $this->price = $price;
    }
    public function print()
    {
        echo "frute name is {$this->name} and price is only {$this->price}";
    }
} 
 class quality extends frute 
{
    
    public function quali()
    {
         echo " quality is best ";
    }
}
$classa  = new quality("apple","230");
$classa -> quali();
$classa->print(); 




/* class Fruit {
    public $name;
    public $color;
    public function __construct($name, $color) {
      $this->name = $name;
      $this->color = $color; 
    }
    public function intro() {
      echo "The fruit is {$this->name} and the color is {$this->color}."; 
    }
  }
  
  // Strawberry is inherited from Fruit
  class Strawberry extends Fruit {
    public function message() {
      echo "Am I a fruit or a berry? "; 
    }
  }
  
  $strawberry = new Strawberry("Strawberry", "red");
  $strawberry->message();
  $strawberry->intro(); */
?>