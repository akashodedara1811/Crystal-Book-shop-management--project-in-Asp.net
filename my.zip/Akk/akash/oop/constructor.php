<form action="" method="post">
    <input type="text" name="nm"><br>
    <input type="text" name="address"><br>
    <input type="text" name="age"><br>
    <input type="submit" name="s"><br>
</form>
<?php
if(isset($_POST["s"]))
{
    $nm = $_POST['nm'];
    $address = $_POST['address'];
    $age = $_POST['age'];

class text{
    public $name;
    public $address;
    public $age;
    function __construct($name,$address,$age)
    {
       $this->name = $name;
       $this->address= $address;
       $this->age = $age;
    }
    function printname()
    {
        return ($this->name);
    }
    function printaddress()
    {
        return $this->address;
    }
    function printage()
    {
        return $this->age;
    }
}
$detai = new text($nm,$address,$age);
echo $detai -> printname()." ";
echo $detai -> printaddress()." ";
echo $detai -> printage()." ";
$arr = [$detai->printname(),$detai->printaddress(),$detai->printage()];
echo "<pre>";
print_r($arr);
echo "</pre>";
echo "imploade:".implode("   ",$arr);
}
?>