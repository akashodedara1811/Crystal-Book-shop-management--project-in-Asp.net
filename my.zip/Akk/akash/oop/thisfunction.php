<?php
class details{
    public $name;
    function set_name($name)
    {
        $this-> name = $name;
        return $this->name;
    }/* 
    function myname()
    {
        return $this -> name;
    } */
}
$det = new details();
echo $det -> set_name("odedara Akash");
//echo strtoupper($det->myname());
?>