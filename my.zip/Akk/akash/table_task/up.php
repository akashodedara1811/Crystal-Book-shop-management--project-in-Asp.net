<?php
session_start();
$rows =$_SESSION['row'];
$cols = $_SESSION['cols'];

$con = mysqli_connect("localhost","root","root","table");
if(!$con)
{
    echo "connection problem";
}
else
{
    echo "<form action='four.php'>";
    $q = mysqli_query($con,"select * from t1 order by id desc limit 0,1");
    while($r = mysqli_fetch_assoc($q))
    {
        echo "<input type='hidden' value='{$r['id']}' class='update_id'/>";
        echo "<input type='hidden' value='{$r['rows']}' class='rows'/>";
        echo "<input type='hidden' value='{$r['cols']}' class='cols'/>";
        $item1 = $r['item'];
    }
    $item = explode(",",$item1); 
    echo "<table border=2 style='margin-left:20%;padding:2%;font-size:10px;text-transform:uppercase'>";
    $c = 0;
    for ($i=0; $i < $rows  ; $i++)
     { 
        echo "<tr>";
        for ($j=0; $j < $cols ; $j++) { 
            echo "<input type='hidden' value='[$i][$j]' class='cel'/>";
            echo "<td><input type='text' value='{$_SESSION['value'][$c]}' class='update_text'/></td>";
            $c++;
        }
        echo "</tr>";
       
    }
    echo "</table>";
    echo "<input type='submit' value='update Now' class='up' style='margin-left:35%;'/>";
    echo "</form>";

}
?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    
        $(".up").click(function(e){
       //   e.preventDefault();
            var id = $(".update_id").val();
            var rows = $(".rows").val();
            var cols = $(".cols").val();
            var cel = [];

        //---------------- example of get value from dynamic text box using jquery----------
        var value = [];
        $('.update_text').each(function(key) {
            value[key] =  $(this).val();
        })
        //-------------------------------------------------------------------------------------
        $('.cel').each(function(key) {
            cel[key] =  $(this).val();
        })
         $.ajax({
            url : "update.php",
            type:"post",
            data:{idl :value,id:id,rows:rows,cols:cols,cel:cel},
            success:function(data)
            {
            alert(data);
            }
             }) 
         }); 

       
    </script>