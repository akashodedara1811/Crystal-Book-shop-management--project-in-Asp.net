<?php
session_start();
echo "<form method='post' action='four.php'>";
    $row = $_POST['rows'];
    $col =$_POST['cols'];
    $_SESSION['row'] = $row;
    $_SESSION['cols'] = $col;
    for($i=1;$i<=$row;$i++)
    {
        for($j=1;$j<=$col;$j++)
        {
          echo "<input type='text' name='data[$i][$j]' class='val'/>";
          echo "<input type='hidden' value='[$i][$j]' class='cel'/>";
          echo "<input type='hidden' name='$row'/>";
          echo "<input type='hidden' name='$col'/>";
        }
    echo "<br>";
    }
    echo "<input type='submit' class='s'/>";
    echo "</form>";
 ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    
        $(".s").click(function(e){
        //  e.preventDefault();
            var value = [];
            var cel = [];
        $('.val').each(function(key) {
            value[key] =  $(this).val();
        })
        $('.cel').each(function(key) {
            cel[key] =  $(this).val();
        })
        /* alert(cel); */
         $.ajax({
            url : "two.php",
            type:"post",
            data:{idl :value,cel:cel},
            success:function(data)
            {
                alert(data);
            }
             }) 
         });

       
    </script>