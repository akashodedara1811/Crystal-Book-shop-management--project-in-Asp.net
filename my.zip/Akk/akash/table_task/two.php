<?php
session_start();
$row =$_SESSION['row'];
$cols =$_SESSION['cols'];
$idl = $_POST['idl'];//first array
$_SESSION['value'] = $idl;
$cel = $_POST['cel'];
$combo = array_map("com",$cel,$idl);
function com($a,$b)
{
    return $a.":".$b;
}
$item = implode(",",$combo);

 if($row == "" || $cols =="" || $idl == "")
{
    echo "value is empty";
}
else
{
    
$con = mysqli_connect("localhost","root","root","table");
if(!$con)
{
    echo "connection problem";
}
else
{
  mysqli_query($con,"INSERT INTO `t1` ( `rows`, `cols`, `item`) VALUES ( '$row', '$cols', '$item');");
    
}
}
 ?>