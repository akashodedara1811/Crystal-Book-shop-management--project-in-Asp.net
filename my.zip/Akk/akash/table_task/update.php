<?php
session_start();
$row = $_POST['rows'];
$cols = $_POST['cols'];
$id = $_POST['id'];
$idl = $_POST['idl']; 
$_SESSION['value'] = $idl;
 $cel = $_POST['cel'];
$combo = array_map("com",$cel,$idl);
function com($a,$b)
{
    return $a.":".$b;
}
$item = implode(",",$combo); 
  if($idl == "")
{
    echo "value is empty";
}
else
{
    
$con = mysqli_connect("localhost","root","root","table");
if(!$con)
{
    echo "connection problem";
}
else
{
    echo "connection is right";
    mysqli_query($con,"update `t1` set item='$item' where id='$id'");
    echo "updated..";
}

}  
?>