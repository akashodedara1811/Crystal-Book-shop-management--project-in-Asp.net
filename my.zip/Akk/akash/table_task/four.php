<?php
session_start();
$rows =$_SESSION['row'] ;
$cols = $_SESSION['cols'];
$con = mysqli_connect("localhost","root","root","table");
if(!$con)
{
    echo "connection problem";
}
else
{
    $q = mysqli_query($con,"select * from t1 order by id desc limit 0,1");
    while($r = mysqli_fetch_assoc($q))
    {
        $item1 = $r['item'];
    }
     echo "<table border=2 style='margin-left:30%;padding:2%;font-size:20px'>";
    $c = 0;
    for ($i=0; $i < $rows  ; $i++)
     { 
        echo "<tr>";
        for ($j=0; $j < $cols ; $j++) { 
            echo "<td><a href='up.php'>{$_SESSION['value'][$c]}</a></td>";
            $c++;
        
        } 
        echo "</tr>";
       
    }
    echo "</table>";
}  
?>