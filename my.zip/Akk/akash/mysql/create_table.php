<?php
$servername = "localhost";
$username = "root";
$pass = "root";
$db = "akash";
$con = new mysqli($servername,$username,$pass,$db);
if($con->connect_error)
{
    echo "connection success fully";
}
$query = "create table test(id int(20), name varchar(200), address varchar(300))";
if($con -> query($query) == TRUE)
{
    echo "create table successfully";
}
else
{
    echo "return an error";
}
?>