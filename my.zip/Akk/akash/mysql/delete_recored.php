<?php
$servername = "localhost";
$username = "root";
$pass = "root";
$db = "akash";
$con = new mysqli($servername,$username,$pass,$db);
if($con->connect_error)
{
    echo "connection is not correct";
}
$query = "delete from test where name='akash odedara'";
if($con -> query($query) == TRUE)
{
    echo "recored deleted...";
}
else
{
    echo "return an error";
}
?>