<?php
$servername = "localhost";
$username = "root";
$pass = "root";
try{
$con = new PDO("mysql:host=$servername;dbname=akash",$username,$pass);
$con->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
echo "connected success fully";
}
catch(PDOException $e)
{
    echo "connection failed".$e->getMessage();
} 
?>