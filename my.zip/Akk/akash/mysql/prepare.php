<?php
$servername = "localhost";
$username = "root";
$pass = "root";
$db = "akash";
$con = new mysqli($servername,$username,$pass,$db);
if($con->connect_error)
    {
    echo "connection is not corect..";
    }
$stm = $con->prepare( "insert into test(id,name,address) values(?,?,?)");
$stm ->bind_param("sss",$id,$name,$address);
$id = 2;
$name = "sagar odedara";
$address="Junagadh";
$stm->execute();

$id = 3;
$name = "rahul odedara";
$address="Junagadh";
$stm->execute();

$id = 4;
$name = "Bharat odedara";
$address="Junagadh";
$stm->execute();

$stm ->close();
$con ->close(); 
?>