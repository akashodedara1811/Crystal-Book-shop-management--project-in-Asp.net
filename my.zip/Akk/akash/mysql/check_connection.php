<?php

//using oop
/* $servername = "localhost";
$username = "Akash";
$passwored = "root";
//check conection
$con= new mysqli($servername,$username,$passwored);
//check the connection is correct or not
if($con->connect_error)
{
   die("conaction failed...".$con->connect_error);
}
else
{
   echo "conection is correct..";
} */
//using mysqli
$servername = "localhost";
$username = "root";
$passwored = "root";
$con = mysqli_connect($servername,$username,$passwored);
if(!$con)
{
    echo "<br>connection is failed";
}
else
{
    echo "<br>connection is coorect..";
}
?>