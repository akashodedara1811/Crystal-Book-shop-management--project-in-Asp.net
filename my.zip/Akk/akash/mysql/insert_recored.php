<?php
$servername = "localhost";
$username = "root";
$pass = "root";
$db = "akash";
$con = new mysqli($servername,$username,$pass,$db);
if($con->connect_error)
{
    echo "connection is not correct";
}
$query = "insert into test values (1,'akash odedara','junagadh')";
if($con -> query($query) == TRUE)
{
    echo "insert data successfully";
}
else
{
    echo "return an error";
}
?>