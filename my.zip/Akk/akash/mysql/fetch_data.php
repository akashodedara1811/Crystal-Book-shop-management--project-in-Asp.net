<?php
$servername = "localhost";
$username = "root";
$pass = "root";
$db = "akash";
$con = new mysqli($servername,$username,$pass,$db);
if($con->connect_error)
{
    echo "connection is not corect..";
}
$query = "select * from test order by id desc limit 1,1";
$r = $con->query($query);
if($r -> num_rows > 0)
{   echo "<table border=2>";
    while($result = $r->fetch_assoc())
    {
        echo"<tr><td>{$result["id"]}</td><td>{$result["name"]}</td><td>{$result["address"]}</td></tr>";
      //  echo "<br>".$r["id"];
    }
     echo "</table>";
}
else
{
    echo "function retun an error";
}
?>