
<?php
$servername = "localhost";
$username = "root";
$pass = "root";
$db = "akash";

$rec = 1;
$limit = 5;
$con = mysqli_connect($servername,$username,$pass,$db);
$q = mysqli_query($con,"select * from test");
$qu = mysqli_query($con,"select * from test limit 0 , {$limit}");
$count =mysqli_num_rows($q);
    $page = floor($count / $rec);
echo "<table>";
 while($r = mysqli_fetch_assoc($qu))
 {
    echo "<tr><td>{$r["id"]}</td><td>{$r["name"]}</td><td>{$r["address"]}</td></tr>";
 }
echo "</table>";
//echo "pages :".floor($page);


$c = 1;
  echo "<div class='test'>";
    for($i=1;$i<=$page;$i++)
    {
        echo "<form  method='post' action='pagination_testing.php?page={$i}' styple='display:inline-box'>";
        echo "<input type='submit' value='{$i}' name=val[]/>";
        echo "</form>";  
    }

  ?>