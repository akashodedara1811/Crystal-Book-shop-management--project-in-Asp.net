<?php
/* $name = $_POST['name'];
$pass = md5($_POST['pass']);
$cpass = md5($_POST['cpass']);
$conf = $_POST['cpass'];
$email = $_POST['email'];
$gender = $_POST['gen'];
$hobby1 = $_POST['hob']; 
$hobby = implode(",",$hobby1);
 *//* $filetemp = $_FILES['uploade']['tmp_name'];
$filename = $_FILES['uploade']['name']; */
/*if($_SESSION['name'] == "")
 {
if($cpass == $pass)
{
    
    $con = mysqli_connect("localhost","root","root","akash");
    $q = mysqli_query($con,"select * from register where name='$name'");
    if(mysqli_num_rows($q) > 0)
    {
        return 0;
    }
    else
    {
    move_uploaded_file($filetemp,"img/".$filename);
    mysqli_query($con,"insert into register(name,password,cpass,email,gender,hobby,pic) values('$name','$pass','$conf','$email','$gender','$hobby','$filename') ");
      return 1;

    }
}
else
{
    echo"passwored not matched";
} 
}
else
{
header("location:welcome.php");
} */


//--------------------------------------------------------------------
$name = $_POST['Fname'];    
$pass = md5($_POST['Fpass']);
$cpass = $_POST['Fcpass'];
$email = $_POST['Femail'];
$gender = $_POST['Fgen'];
$hob = $_POST['Fhob'];
$hobb = implode(",",$hob);
//header("location:reg.php");
$con = mysqli_connect("localhost","root","root","akash");
 $q = "insert into register (name,password,cpass,email,gender,hobby) values ('{$name}','{$pass}','{$cpass}','{$email}','{$gender}','{$hobb}')";
if(!mysqli_query($con,$q))
{
    return 0; 
}
else
{
    return 1;
}



?>