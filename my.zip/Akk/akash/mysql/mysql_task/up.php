<?php
    $id = $_POST['Fid'];
    $name = $_POST['Fname'];
    $pass = md5($_POST['Fpass']);
    $ccpass = md5($_POST['Fcpass']);
    $cpass = $_POST['Fcpass'];
    $em =  $_POST['Femail'];
    $gender = $_POST['Fgen']; 
    $hobby1= $_POST['Fhob'];
    $hobby = implode(",",$hobby1);
   $con = mysqli_connect("localhost","root","root","akash");
    $q ="update register set name='{$name}'  , password='{$pass}'  , cpass='{$cpass}'  , email='{$em}'  , gender='{$gender}' , hobby='{$hobby}' where id='{$id}'";
   
    if(mysqli_query($con,$q))
    {
      return 0;
    }
    else
    {
        return 1;
    }
?>