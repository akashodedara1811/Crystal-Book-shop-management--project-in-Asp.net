<?php
session_start();
$name = $_SESSION['name'];
?>
<h2>welcome <?php echo $_SESSION['name'];?></h2>
<form action="" method="post">
  <input type="hidden" value="<?php echo $name; ?>" name="ed">
    <input type="submit" value="logout" name="s">
    <input type="submit" value="Edit data" name="edit">
    <input type="submit" value="Display data" name="dis">
</form>
<?php
if($name == "")
{
  header("location:index.php");
}
else
{
$con = mysqli_connect("localhost","root","root","akash");
$q = mysqli_query($con,"select pic from register where name='{$name}'");
while($r = mysqli_fetch_assoc($q))
{
echo "<img src='img/{$r['pic']}' height='300' width='300' align='right'>";
}
if(isset($_POST['s']))
{
    header("location:logout.php");
}
if(isset($_POST['edit']))
{
  $valu = $_POST['ed'];
  header("location:update.php?name={$valu}");
}
if(isset($_POST['dis']))
{
  header("location:display.php");
}
}
?>