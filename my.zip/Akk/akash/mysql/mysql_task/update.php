<?php
session_start();
$name = $_GET['name'];
echo "<h2 align=center> Edit page</h2>";
echo "<table align=center>";
echo "<form method='post' enctype='multipart/form-data'>";
$con = mysqli_connect("localhost","root","root","akash");
$q = mysqli_query($con,"select * from register where name='{$name}'");
while($r = mysqli_fetch_array($q))
{
    echo "<tr><td></td><td><input type='hidden' placeholder='enter Name:' value='{$r["id"]}' name='id' require id='cid'></td></tr>";
    echo "<tr><td>Name :</td><td><input type='text' placeholder='enter Name:' value='{$r["name"]}' name='name' require class='name'></td></tr>";
    echo "<tr><td>passwored :</td><td><input type='password' placeholder='enter passwored' value='{$r["cpass"]}' name='pass' id='pass'></td></tr>";
    echo "<tr><td>confirm passwored :</td><td><input type='password' placeholder='enter confirm passwored' value='{$r["cpass"]}' name='cpass' id='cpass'></td></tr>";
    echo "<tr><td>Email :</td><td><input type='email' placeholder='enter email' name='em' value='{$r["email"]}' name='em' id='email'></td></tr>";
    if($r['gender']=="Male")
    {
        echo "<tr><td>Gender:</td><td><input type='radio' name='gender' value='Male' checked>Male<input type='radio' name='gender' value='Female'>Female</td></tr>";
    }
    else
    {
        echo "<tr><td>Gender:</td><td><input type='radio' name='gender' value='Male'>Male<input type='radio' name='gender' value='Female' checked>Female</td></tr>"; 
    } 
    $ex = explode(",",$r["hobby"]);
 
     if($ex[0]=="Reading")
     {
        echo "<tr><td>Hobby:</td><td><input type='checkbox' name='hob[]' value='Reading' checked>Reading</td></tr>";
    }
    else
    {
        echo "<tr><td>Hobby:</td><td><input type='checkbox' name='hob[]' value='Reading'>Reading</td></tr>";
    }
     if($ex[1]=="Playing" || $ex[0]=="Playing")
     {
        echo "<tr><td></td><td><input type='checkbox' name='hob[]' value='Playing' checked>Playing</td></tr>";
     }
       else
       {
       echo "<tr><td></td><td><input type='checkbox' name='hob[]' value='Playing'>Playing</td></tr>";
    }
       if($ex[2]=="Traveling" || $ex[1]=="Traveling" || $ex[0]=="Traveling" )
     {
        echo " <tr><td></td><td><input type='checkbox' name='hob[]' value='Traveling' checked>Traveling</td></tr>";
     }
     else
     {
        echo " <tr><td></td><td><input type='checkbox' name='hob[]' value='Traveling'>Traveling</td></tr>";
    } 
break;
}
 echo "<tr><td></td></tr><td></td><td><input type='submit' id='red' name='s' value='Edit Now'></td><tr><td></td></tr>"; 
echo "</form>";
echo "</table>";
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

$(document).ready(function(e){

    $("#red").on("click",function(e)
    {
        e.preventDefault();
         var hobby = []; 
        var cid = $("#cid").val();
         var name = $(".name").val();
        var pass = $("#pass").val();
        var cpass = $("#cpass").val();
        var email = $("#email").val();
        var gen = $("input[name='gender']:checked").val();
        $(':checkbox:checked').each(function(i){
          hobby[i] = $(this).val();
        });
       alert(cid);
          $.ajax({
            url:"up.php",
            type:"POST",
            data:{
                Fid : cid,
                Fname : name,
                Fpass : pass,
                Fcpass: cpass,
                Femail : email,
                Fgen : gen,
                Fhob : hobby,
               
            },
            success:function(data)
            {
                if(data != 1)
                {
                    alert("updated success fully...");
                }
                else
                {
                    alert("not updated success fully...");
                   
                }
            }
        }); 
        
            
    });
   
}); 
        
</script>