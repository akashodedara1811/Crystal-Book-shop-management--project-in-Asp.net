<?php
session_start();
?>
<form action="" method="post">
 <input type="submit" value="register" name="reg"/>&nbsp;&nbsp;&nbsp;
 <input type="submit" value="login" name="log">
</form>
<?php
if(empty($_SESSION['name']))
{
    if(isset($_POST['reg']))
    {
    header("location:reg.php");
    }
    if(isset($_POST['log']))
    {
    header("location:login.php");
    }
}
else
{
    header("location:welcome.php");
}
?>