<?php
session_start();
?>
<h2 align=center> Login page</h2>
<table align=center>
<form action="" method="post" enctype="multipart/form-data">
    
    <tr><td>Name :</td><td><input type="text" placeholder="enter Name:" name="nm"></td></tr>
    <tr><td>passwored :</td><td><input type="password" placeholder="enter passwored" name="pass"></td></tr>
    <tr><td></td></tr><td></td><td><input type="submit" name="s" value="Login Now"></td><tr><td></td></tr>
    
</form>
</table>
<?php
    if(isset($_POST['s']))
    {
        if(empty($_SESSION['name']))
            {

        $name = $_POST['nm'];
        $pass = md5($_POST['pass']);
        $_SESSION['name'] = $name;
        $con = mysqli_connect("localhost","root","root","akash");
        $q = mysqli_query($con,"select * from register where name='$name' and password='$pass'");
        if(mysqli_num_rows($q) > 0)
        {
            header("location:welcome.php");
            
        }
        else
        {
            echo "not matched";
        }
    }
    else
    {
    header("location:welcome.php");
    }
}


?>