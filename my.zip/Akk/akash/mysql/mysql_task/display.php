<?php

echo "<form method='post'>";
echo "<table border=2 align=Center>";
echo "<tr>
  <th>select</th>
  <th>Id</th>
  <th>Name</th>
  <th>Email</th>
  <th>Gender</th>
  <th>Hobby</th>
  
</tr>";
$con = mysqli_connect("localhost","root","root","akash");
$q = mysqli_query($con,"select id,name,email,gender,hobby from register");
while($r = mysqli_fetch_assoc($q))
{
    echo "<tr><td align='center'><input type='checkbox' name='checked[]' Value='{$r["id"]}'/></td><td>{$r["id"]}</td>";
    echo "<td align='center'>{$r["name"]}</td>";
    echo "<td align='center'>{$r["email"]}</td>";
    echo "<td align='center'>{$r["gender"]}</td>";
    echo "<td align='center'>{$r["hobby"]}</td>";
}
echo "</table>";
echo "<input type='submit' id='delete' value='delete' style='margin-left:50%;margin-top:3%;background-color:red'/>";
echo "<input type='submit' id='deleteAll' value='delete All' style='background-color:red' name='de'/>";
echo "</form>";
echo "<div id='display'></div>";
echo "<a href='index.php' name='value'>Back</a>";
 
if(isset($_POST['de']))
{
    header("location:deleteall.php");
}

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
 /*    $("#delete").on("click",function(e){
       // e.preventDefault();
            var data = [];
        $(":checkbox:checked").each(function(key){
             data[key] = $(this).val();
           $.ajax({
                url:"delete.php?val="+data,
                type:"POST",
                data:{id:data},
                success:function(data){
                   $(location).prop('href', "delete.php?val="+data);
                }
           }); 
        }); 
        }); */
    $(document).ready(function(){
        $("#delete").on("click",function(e){
          e.preventDefault();
          var dataa = [];
          $(":checkbox:checked").each(function(key){
             dataa[key] = $(this).val();
          });
          alert(dataa);
              $.ajax({
                url:"delete.php",
                type:"POST",
                data: {id:dataa},
                success:function(data){
                    if(data != 1)
                    {
                        //alert("conection erro");
                        alert(data);
                    }
                    else
                    {
                        alert("error");
                    }
                }
         
        }); 
    });
});
   
</script>
<?php

if(isset($_POST['value']))
{
    $con = mysqli_connect("localhost","root","root","akash");
    $q = mysqli_query($con,"select * from register");
    if(mysqli_num_rows() < 0)
    {
        header("location:index.php");
    }
}
?>