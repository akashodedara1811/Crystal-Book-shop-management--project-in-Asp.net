<?php
$con = mysqli_connect("localhost","root","root","akash");
$q = "delete from register";
mysqli_query($con,$q);
 header("location:display.php");
?>