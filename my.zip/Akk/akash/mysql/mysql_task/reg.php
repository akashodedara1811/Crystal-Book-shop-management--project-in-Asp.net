<h2 align=center> Register page</h2>
<table align=center>
<form action="" ref={authForm} class="myform">
     
    <tr><td>Name :</td><td><input type="text" placeholder="enter Name:" class="name" name="nm" require></td></tr>
    <tr><td>passwored :</td><td><input type="password" placeholder="enter passwored" name="pass" id="pass"></td></tr>
    <tr><td>confirm passwored :</td><td><input type="password" placeholder="enter confirm passwored" name="cpass" id="cpass"></td></tr>
    <tr><td>Email :</td><td><input type="email" placeholder="enter email" name="em" id="email"></td></tr>
    <tr><td>Gender:</td><td><input type="radio" name="gender" value="Male">Male<input type="radio" name="gender" value="Female">Female</td></tr>
     <tr><td>Hobby:</td><td><input type="checkbox" name="hob[]" value="Reading" class="hob">Reading</td></tr>
    <tr><td></td><td><input type="checkbox" name="hob[]" value="Playing" class="hob">Playing</td></tr>
    <tr><td></td><td><input type="checkbox" name="hob[]" value="Traveling" class="hob">Traveling</td></tr>
    <tr><td></td></tr><td></td><td><input type="submit" name="s" value="Register Now" id="red"></td><tr><td></td></tr>
</form>
</table>
<div class="text"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

$(document).ready(function(e){

    $("#red").on("click",function(e)
    {
        e.preventDefault();
         var hobby = []; 
         var name = $(".name").val();
        var pass = $("#pass").val();
        var cpass = $("#cpass").val();
        var email = $("#email").val();
        var gen = $("input[name='gender']:checked").val();
        $(':checkbox:checked').each(function(i){
          hobby[i] = $(this).val();
        });
         $.ajax({
            url:"register.php",
            type:"POST",
            data:{
                Fname : name,
                Fpass : pass,
                Fcpass: cpass,
                Femail : email,
                Fgen : gen,
                Fhob : hobby,
               
            },
            success:function(data)
            {
                if(data == 1)
                {
                    alert('not working');
                }
                else
                {
                    alert("inserted success fully...");
                   
                }
            }
        });  
       
            
    });
   
});
        
</script>