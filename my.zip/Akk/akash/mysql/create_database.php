<?php
$servername = "localhost";
$username = "root";
$passwored = "root";
$con = new mysqli($servername,$username,$passwored);
if($con -> connect_error)
{
    die("conection is failed");
}
$create = "create database akash";
if($con->query($create)==TRUE)
{
    echo "database created successfully";
}
else
{
    echo "it returns an error";
}
?>