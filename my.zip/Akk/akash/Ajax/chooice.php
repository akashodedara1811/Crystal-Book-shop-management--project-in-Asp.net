<!DOCTYPE html>
<html>
<head>
<script>
function showUser(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  } 
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","selection.php?q="+str,true);
  xmlhttp.send();
}

</script>
</head>
<body>

<form>
<select name="users" onchange="showUser(this.value)">
<?php
$servername = "localhost";
$username = "root";
$pass = "root";
$db = "akash";
     $con = new mysqli($servername,$username,$pass,$db);
    if($con->connect_error)
    {
        echo "database connection is not connected...";
    }
    $query = "select name from register";
    $rows = $con->query($query);
    while($r = $rows->fetch_assoc())
    {
        echo "<option value='{$r["name"]}'>{$r["name"]}</option>";
    }
?>
</select>
</form>
<br>
<div id="txtHint"><b>Person info will be listed here.</b></div>

</body>
</html>
