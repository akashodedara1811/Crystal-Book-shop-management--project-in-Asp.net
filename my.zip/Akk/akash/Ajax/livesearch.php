<!DOCTYPE html>
<html lang="en">
<head>
<script>
function showUser(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  } 
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","live.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>
<body>
    <form action="">
        <input type="text"  placeholder="please search here...." name="search" onKeyup="showUser(this.value)">
    </form>
    <div id="txtHint"></div>
</body>
</html>