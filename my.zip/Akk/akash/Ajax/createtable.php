<form action="">
    <input type="text" id="name" placeholder="enter ony row"><br>
    <input type="text" placeholder="enter columans" name="cols"><br>
    <input type="submit" name="s" onclick="test()">
</form>