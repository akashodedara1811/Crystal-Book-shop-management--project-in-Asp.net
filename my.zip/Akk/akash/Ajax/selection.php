<?php
$servername = "localhost";
$username = "root";
$pass = "root";
$db = "akash";
$name = $_GET['q'];

echo "name is :".$name;
 $con = new mysqli($servername,$username,$pass,$db);
if($con->connect_error)
{
    echo "database connection is not connected...";
}
$query = "select * from register where name='$name'";
$rows = $con->query($query);
    echo "<table border=2>";
    while($r = $rows->fetch_assoc())
    {
        echo"<tr><td>{$r["id"]}</td><td>{$r["name"]}</td><td>{$r["email"]}</td><td>{$r["gender"]}</td><td>{$r["hobby"]}</td></tr>";
    }
    echo "</table>";
?>
