<?php
$servername = "localhost";
$username = "root";
$pass = "root";
$db = "akash";
$value = $_GET['q'];
    $con = new mysqli($servername,$username,$pass,$db);
    if($con->connect_error)
    {
        echo "database connection is not connected...";
    }
    $query = "select * from register where name LIKE '%{$value}%'";
        $rows = $con->query($query);
        echo "<table border=2>";
        while($r = $rows->fetch_assoc())
        {
            echo"<tr><td>{$r["id"]}</td><td>{$r["name"]}</td><td>{$r["email"]}</td><td>{$r["gender"]}</td><td>{$r["hobby"]}</td></tr>";
        }
        echo "</table>";
?>