<h1>simple form submission</h1>
<form action="" method="post">
    Name: <input type="text" placeholder="Enter Name:" name="nm"><br>
    Email: <input type="email" placeholder="Enter emial:" name="em"><br><br>
    <input type="submit" name="s">
</form>
<?php
if(isset($_POST['s']))
{
    $name = $_POST['nm'];
    $email = $_POST['em'];
    echo "<br>Thank you, $name ! We have received your submission with email: $email";
}
?>