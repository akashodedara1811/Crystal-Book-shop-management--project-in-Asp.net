<h2>simple calculater</h2>
<form action="" method="post">
Number 1:&nbsp;<input type="text" placeholder="Enter number 1:" name="num1" required><br>
Number 2:&nbsp;<input type="text" placeholder="Enter number 2:" name="num2" required><br>
Options :&nbsp;&nbsp;&nbsp;<select name="selecter">
    <option value="Addition">Addition</option>
    <option value="Subtraction">Subtraction</option>
    <option value="Multiplication">Multiplication</option>
    <option value="Divistion">Divistion</option>
</select><br><br>
<input type="submit" name="s" value="Calculate">
</form>
<?php
if(isset($_POST['s']))
{
    $num1 = $_POST['num1'];
    $num2 = $_POST['num2'];
    $selecter = $_POST['selecter'];
    if($selecter == "Addition")
    {
      echo "Result : ".($num1 + $num2);
    }
    else if($selecter == "Subtraction")
    {
        echo "Result : ".($num1 - $num2);
    }
    else if($selecter == "Multiplication")
    {
        echo "Result : ".($num1 * $num2);
    }
    else{
        if($num1 != 0 || $num2 != 0)
            echo "Result : ".($num1 / $num2);

    }
}
?>