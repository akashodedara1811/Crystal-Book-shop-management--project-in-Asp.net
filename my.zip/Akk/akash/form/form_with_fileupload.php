
<form method="post" enctype="multipart/form-data">
   <input type="file" name="fileuploade" required><br><br>
    <input type="submit" name="s" value="Uploade file">
</form>
<?php
if(isset($_POST['s']))
{
    $name = $_FILES["fileuploade"]["name"];
    $tem = $_FILES["fileuploade"]["tmp_name"];
    move_uploaded_file($tem,"up/".$name);
    
    echo "File uploaded successfully : $name";
    
}   
?>