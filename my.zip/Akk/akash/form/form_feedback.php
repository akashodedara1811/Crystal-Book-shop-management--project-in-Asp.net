<h2>feedback form</h2>
<form action="" method="post">
Name :&nbsp;<input type="text" placeholder="Enter Name:" name="nm"  required><br>
Email :&nbsp;<input type="text" placeholder="Enter Email:" name="em" required><br>&nbsp;
Feedback:<br>&nbsp;<textarea cols=28 name="fd"></textarea><br>
Ratting :&nbsp;&nbsp;&nbsp;<select name="selecter">
    <option value="1 Starts">1 Starts</option>
    <option value="2 Starts">2 Starts </option>
    <option value="3 Starts">3 Starts</option>
    <option value="4 Starts">4 Starts</option>
    <option value="5 Starts">5 Starts</option>
</select><br><br>
<input type="submit" name="s" value="Submit Feedback">
</form>

<?php
if(isset($_POST['s']))
{
$name = $_POST['nm'];
$email = $_POST['em'];
$feedback = $_POST['fd'];
$ratting = $_POST['selecter'];

echo "Thank you,".$name.", for your feedback!<br><br>";
echo "Email: ".$email."<br><br>";
echo "Feedback: ".$feedback."<br><br>";
echo "Ratting : ".$ratting."<br><br>";
}
?>