<form action="" method="post">
    Name:&nbsp;<input type="text" placeholder="Enter name:" name="nm"><br>
    Email:&nbsp;<input type="text" placeholder="Enter Email:" name="em"><br><br>
    password:&nbsp;<input type="text" required name="pass"><br><br>
    <input type="submit" name="s">
</form>
<?php
if(isset($_POST['s']))
{
    $name = $_POST['nm'];
    $email = $_POST['em'];
    $pass = $_POST['pass'];
     $patternforemail = "/^\\S+@\\S+\\.\\S+$/";
     $patternforpass= "/(?=[A-Za-z0-9@#$%^&+!=]+$)^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+!=])(?=.{8,}).*$/";
 
  if(!preg_match($patternforemail,$email))
  {
    echo "<br>please enter valide email id";
  }
  else
  {
    echo "<br>email id is valide";
  }  

  if(!preg_match($patternforpass,$pass))
  {
    echo "<br>please enter valide passwored";
  }
  else
  {
    echo "<br>passwored is valide";
  }  
 }
?>