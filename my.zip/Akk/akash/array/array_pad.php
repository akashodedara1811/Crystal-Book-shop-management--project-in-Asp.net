<?php
$arr1 = ["1"=>"akash","2"=>"odedara","3"=>"apple"];
#print_r($arr1);
$new = array_pad($arr1,7,"dell");//insert value with the help of key if this value is second last at that time its print last value but it not second last value at that time its same value up to set value
print_r($new);

?>