<?php
$arr1 = ["akash","raj","Aman"];
$newarr = array_slice($arr1,1,2,true);//this array is used for devide array into two part
echo "<pre>";
print_r($newarr);
echo "</pre>";
?>