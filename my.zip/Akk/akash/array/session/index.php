<?php
session_start();
$_SESSION['a'] = "user";
echo "session created if you want to show";
?>
<a href="first.php">click here</a>
<?php
?>
