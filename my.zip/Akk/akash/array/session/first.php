<?php
session_start();
echo "session name:".$_SESSION['a'];
echo "<br><br>";
?>
<a href="destroy.php">click here</a>
<?php
echo "session destroy";
?>