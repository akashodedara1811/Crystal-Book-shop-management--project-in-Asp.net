<?php
$num = array("akash","odedara");# this function is used  to create array
var_dump($num);
$num1 = array("A"=>"akash","B"=>"odedara");# this function is used to convert array case
array_change_key_case($num1,CASE_LOWER);
echo "<br>";
var_dump($num1);

echo "<br><pre>";
print_r(array_chunk($num1,1));#this function is used to splite the array
echo "</pre>";
?>
<hr>    
<?php
$detail = array(
    array(
        "id"=>"101",
        "name"=>"Akash",
        "surname"=>"odedara"
    ),
    array(
        "id"=>"102",
        "name"=>"bharat",
        "surname"=>"mer"
    ),
   
    );
    $name=array_column($detail,"surname","id");#this function is used for get selected column
    print_r($name);

?>
<hr>
<?php
$detail1 =
    array(
        "id"=>"101",
        "name"=>"Akash",
        "surname"=>"odedara"
    );
$detail2 =   array(
        "id"=>"102",
        "name"=>"bharat",
        "surname"=>"mer"
);
   

    $name=array_combine($detail1,$detail2);#this function is used to combine two array
    
    print_r($name);
   echo "<pre>";
   print_r(array_count_values($detail1));
   echo "</pre>";

?>
<hr>
<?php
$arra1=["red","blue","gray"];
$arra2 = ["red","green","orange"];
echo "<pre>";
print_r(array_diff($arra1,$arra2));# this is function remove same values from two array and print diffrent value.
echo "</pre>";
?>
<hr>    
<?php
$arra1=["1"=>"red","3"=>"blue","4"=>"gray"];
$arra2 = ["1"=>"red","3"=>"blue","4"=>"orange"];
echo "<pre>";
print_r(array_diff_assoc($arra1,$arra2));#this function is same as diff() but this function check key and value and diff() check only value
echo "</pre>";
?>
<hr>
<?php
$arra1=["1"=>"red","3"=>"blue","4"=>"gray"];
$arra2 = ["1"=>"red","2"=>"blue","4"=>"orange"];
echo "<pre>";
print_r(array_diff_key($arra1,$arra2));#this function remove value from key
echo "</pre>";
?>
<hr>
<?php
$arr1 = array_fill(3,4,"red");
print_r($arr1);# this is function is used to create array same value
?>
<hr>
<?php 
$arr1 = array("1","2","3","4");
$arr2 = array_fill_keys($arr1,"gray");
print_r($arr2);
?>
<hr>
<?php 
/*function check_odd($var)
{
    return($var & 1);
}
$arr1 = array(1,2,3,4);
check_odd($arr1);*/
#note: array_filter function(

?>