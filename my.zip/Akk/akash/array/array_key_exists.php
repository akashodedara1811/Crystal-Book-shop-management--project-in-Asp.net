<?php
 $arr1=[1=>"akash",2=>"raj",3=>"karan"];

 if(array_key_exists(1,$arr1))//this function is used to check key is available or not
 {
    echo "find key";
 }
 else
 {
    echo "not find key";
 }
?>
