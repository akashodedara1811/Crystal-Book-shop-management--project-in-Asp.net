<?php
$arr = ["a"=>"akash","ram"];
$result = each($arr);//this function returns currents key with value
echo "<pre>";
print_r($result);
echo "</pre>";
?>