<?php
$arr1 = array("1","2","3","4","10");

echo array_search("3",$arr1);//return key which value we can fine

?>