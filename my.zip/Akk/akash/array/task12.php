<!-- palidrom string -->
<form action="" method="post">
   <input type="text" placeholder="enter stoped number..." name="nm">
   <input type="submit" name="s">
</form>
<?php
if(isset($_POST['s']))
{
$n = $_POST['nm'];
$tem = strtolower(preg_replace("/[^0-9a-zA-Z]/","",$n));
$len = strlen($n);
$strr = strtolower(strrev($n));
$re = preg_replace("/[^0-9a-z]/","",$strr);

if($tem == $re)
    echo "<br> palidrom string";
else
    echo "<br> not palidrom string";
}
 ?>