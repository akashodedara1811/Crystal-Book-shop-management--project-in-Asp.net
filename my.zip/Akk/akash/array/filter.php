<?php
//EMAIL VALIDATION
$filtertest = "abc12@gmail.com";
if(filter_var($filtertest,FILTER_VALIDATE_EMAIL))
{
  echo "this is valid email";
}
else
{
 echo "not valid email";
}
echo "<br><br><br><hr>";
//INTEGER VALIDATION 
$VAL = 0;
if(filter_var($VAL,FILTER_VALIDATE_INT) || filter_var($VAL,FILTER_VALIDATE_INT)==0)
{
    echo "valide Interger value";
}
else
{
    echo "not valid interger value";
}
echo "<br><br><br><hr>";
//check ip is valid or not
$ip = "127.0.0.7";
if(filter_var($ip,FILTER_VALIDATE_IP))
{
    echo "valide ip address";
}
else
{
    echo "not valide ip address";
}
echo "<br><br><br><hr>";
// CHECK THE INTEGER NUMBER IS WORKING BETWEEN 1 TO 100 OR NOT
$value = 12;

$min = 1;
$max = 100;

 if (!filter_var($value,FILTER_VALIDATE_INT,array("options" => array("min_range"=>$min, "max_range"=>$max))) === false)
    {
        echo("Variable value is not within the legal range");
    }
    else
    {
        echo("Variable value is within the legal range");
    }
    echo "<br><br><br><hr>";
    if (!filter_var($value, FILTER_VALIDATE_INT, array("options" => array("min_range"=>$min, "max_range"=>$max))) === false) {
        echo("Variable value is not within the legal range");
      } else {
        echo("Variable value is within the legal range");
      }
      
      echo "<br><br><br><hr>";
      /*//check url is valid or not
      $url = "https://www.google.com?";
      if(filter_var($url,FILTER_VALIDATE_URL,FILTER_FLAG_QUERY_REQUIRED))
      {
        echo "url is valide";
      }
      else
      {
        echo "not valide";
      }
      strtotime($date,)*/
?>