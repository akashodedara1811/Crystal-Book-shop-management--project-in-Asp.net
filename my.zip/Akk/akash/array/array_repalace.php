<?php
$arr1 = ["abc","dec","efg"];
$arr2 = ["akash","raj"];
$new = array_replace($arr1,$arr2);//this function is replace the value in array 1
print_r($new);
?>