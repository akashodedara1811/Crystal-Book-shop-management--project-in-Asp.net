<?php
$arr = ["10"=>"Akash","20"=>"karan","30"=>"bharat"];
array_walk($arr,"testing","is a very cool man");

function testing($val,$key,$pattern)
{
  echo "Roll number : {$Key}. {$pattern} name is : {$val}<BR><BR>" ;
}
?>