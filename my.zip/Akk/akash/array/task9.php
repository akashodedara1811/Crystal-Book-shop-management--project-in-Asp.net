<form action="" method="post">
    <input type="text" placeholder="please enter stoped number.." name="nm">
    <input type="submit" name="s">
</form>
<?php
#factorial number
if(isset($_POST['s']))
{ $mul =1;
    $n = $_POST['nm'];
    for($i=$n;$i>=1;$i--)
    {
        $mul = $i * $mul ;
    }
    echo "value :".$mul;
}
?>