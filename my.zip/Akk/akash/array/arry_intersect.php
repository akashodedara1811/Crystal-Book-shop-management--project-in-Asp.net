<?php
$arr1 =["1"=>"akash","2"=>"raj","3"=>"karan","4"=>"dipen"];
$arr2 =["2"=>"akash","1"=>"raj","4"=>"karan","3"=>"tushar"];
$new = array_intersect($arr1,$arr2);//this function is compere array1 whith arr2 and print same value from array1
echo "<pre>";
print_r($new);
echo "</pre>"; 
?>