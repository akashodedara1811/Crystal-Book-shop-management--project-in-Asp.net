<form action="" method="post">
   <input type="text" placeholder="enter stoped number..." name="nm">
   <input type="submit" name="s">
</form>
<?php
#armstong number
if(isset($_POST['s']))
{
$n = $_POST['nm'];
$temp=$n;
$c = 0;
$r = 0;
$val = strlen($n);
while($n > 0)
{
   $c = $n % 10;
   $r = $r + pow($c,$val) ;
   $n = $n / 10;

}
 if($temp == $r)
    echo "Armstong number";
else    
   echo "not armstong number";
}
 ?>