<?php
for($i=1;$i<=10;$i++)
{
    echo "Value:".$i."<br>";
}
echo "<br>";
echo "<br>"."<hr>";
for($i=1;$i<=5;$i++)
{
    for($j=1;$j<=$i;$j++)
    {
        echo " ".$j;
    }
    echo "<br>";
}


echo "<br>";
echo "<br>"."<hr>";
for($i=5;$i>=1;$i--)
{
    for($j=5;$j>=$i;$j--)
    {
        echo " ".$j;
    }
    echo "<br>";
}

echo "<br>";
echo "<br>"."<hr>";
for($i=1;$i<=5;$i++)
{
    for($j=5;$j>=$i;$j--)
    {
        echo " ".$j;
    }
    echo "<br>";
}

echo "<br>";
echo "<br>"."<hr>";
$c=1;
for($i=1;$i<=5;$i++)
{
    for($j=1;$j<=$i;$j++)
    {
        echo " ".$c;
        $c+=1;
    }
    echo "<br>";
   

}
echo "<br>"."<hr>";
echo "<br>";
$x = 10;
$y = NULL;

if($x == $y)
{
    echo "values are same";
}
else
{
   echo "not same";
}

echo "<br>"."<hr>";
if($x == $y)
{
    echo "values are same";
}
else if($x == NULL || $y ==NULL)
{
   echo "null value";
}
else
{
    echo "not same";
}
echo "<br>"."<hr>";

$n = 2;
switch($n)
{
    case 1:
        echo "Apple";
        break;
    case 2:
        echo "dell";
        break;
}
echo "<br>"."<hr>";
if($x >= 5)
{
    echo "bigger then 5";
}
if($x == 0)
{
    echo "value is zero";
}
if($x <= 5)
{
    echo "smaler then 5";
}
echo "<br>"."<hr>";
echo "<h1>while loop</h1>";
$a = 1;
while($a <= 5)
{
    $b = 1;
    while($b <= $a)
    {
        echo $b;
        $b++;
    }
    $a+=1;
    echo "<br>";

}
echo "<br>"."<hr>";
echo "<h1>Do while loop</h1>";
$a = 1;
do{
    echo $a;
    $a++;
}while($a <6);

echo "<br>"."<hr>";
echo "<h1>foreach loop</h1>";
$a = array("1","2","Akash");
foreach($a as $name){
    echo $name;
}
echo "<br>"."<hr>";
echo "<h1>key pair value foreach loop</h1>";
$a = array("1"=>"hi","2"=>"hello","Akash"=>"i am akash odedara");
foreach($a as $key=>$name){
    echo $key.":".$name."<br>";
}

echo "<br>"."<hr>";
echo "<h1>function</h1>";
echo "<h2> default function</h2>";
function abc()
{
    echo "defult function";
}
abc();

echo "<br>"."<hr>";
echo "<h2> with parameter function</h2>";
function abcd($a)
{
    echo $a." function";
}
$a="parameter";
abcd($a);

echo "<br>"."<hr>";
echo "<h2> default with return value function</h2>";
function abcde()
{
     $a = "default with return value function";
     return $a;
}

echo abcde();

echo "<br>"."<hr>";
echo "<h2> with parameter with return value function</h2>";
function abcdef($a)
{
     return $a;
}
$a ="with parameter";
echo abcdef($a);

echo "<br>"."<hr>";
echo "<h1> Array </h1>";
$a1=array("apple","dell","hp");
foreach($a1 as $v)
{
    echo $v."<br>";
}
echo "<br>";
$a1[1]="hp";
foreach($a1 as $v)
{
    echo $v."<br>";
}
array_push($a1,"odedara");
echo "<br>";
foreach($a1 as $v)
{
    echo $v."<br>";
}

$a1 += ["abc"=>"akash","bcd"=>"abc","efg"=>"def"];

echo "<br>";
foreach($a1 as $v)
{
    echo $v."<br>";
}
echo "<br>";
echo "<br>";
echo "<br>";

array_splice($a1,0,2);

foreach($a1 as $v)
{
    echo $v."<br>";
}
var_dump($a1);
 unset($a1["abc"]);
 echo "<br>";
foreach($a1 as $v)
{
    echo $v."<br>";
}
array_pop($a1);
echo "<br>";
foreach($a1 as $v)
{
    echo $v."<br>";
}
array_shift($a1);
echo "<br>";
foreach($a1 as $v)
{
    echo $v."<br>";
}

/*array_diff($a1,["odedara","abc"]);

echo "<br>";
foreach($a1 as $v)
{
    echo $v."<br>";
}*/
echo "<hr>";
$b1 = ["dell","lenovo","apple"];
 sort($b1);
 foreach($b1 as $v1)
 {
    echo $v1."<br>";
 }
 echo "<hr>";
 rsort($b1);
 foreach($b1 as $v1)
 {
    echo $v1."<br>";
 }
 echo "<hr>";
 $asso = ["3"=>"akash","2"=>"odedara","1"=>"i am"];
 asort($asso);
 foreach($asso as $v1)
 {
    echo $v1."<br>";
 }

 echo "<hr>";
 ksort($asso);
 foreach($asso as $v1)
 {
    echo $v1."<br>";
 }

 echo "<hr>";
 arsort($asso);
 foreach($asso as $v1)
 {
    echo $v1."<br>";
 }
?>
  

