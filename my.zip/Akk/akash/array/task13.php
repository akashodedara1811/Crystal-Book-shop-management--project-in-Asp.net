<form action="" method="post">
   <input type="text" placeholder="enter stoped number..." name="nm">
   <input type="submit" name="s">
</form>
<?php
if(isset($_POST['s']))
{
    //prime number
$n = $_POST['nm'];

for($i=2;$i<$n;$i++)
{
    if($n % $i == 0)
    {
        $d = 10;
        break;
    }

}

if($d == 10)
{
    echo "$n is not prime number";
}
else
{
    echo "$n is a prime number";
} 
}
?>