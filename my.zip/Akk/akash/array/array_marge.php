<?php
$arr1 = ["akash","ram","lakhan"];
$arr2 = ["tushar","karan","dipen"];
$new = array_merge($arr1,$arr2);
echo "<pre>";
print_r($new);
echo "</pre>";
?>