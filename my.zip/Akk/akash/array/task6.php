<form action="" method="post">
    <input type="text" placeholder="please enter any string:" name="nm"><br>
    <input type="submit" name="s"><br>
</form>
<?php

#first task completed 
if(isset($_POST["s"]))
{
$str = $_POST['nm'];
$str1 = explode(" ",$str);
 $count = (int)count($str1);
#echo "count:".$count;
for($i=0;$i<$count-1;$i++)
{
        echo $str1[$i]."&nbsp";
 }   
}
 ?>