<form action="" method="post">
    <input type="text" placeholder="please enter any string:" name="nm"><br>
    <input type="submit" name="s"><br>
</form>
<?php

#first task completed 
if(isset($_POST["s"]))
{
$arr1 = $_POST['nm'];

$count = 0; 
 while($arr1[$count] != NULL)
{ 
    $arr2[$count] = $arr1[$count];
    $count++;
}
for($i=$count-1;$i>=0;$i--)
{
    if($arr2[$i]==" ")
    {
        echo "&nbsp";
    }
    else
    {
     echo"".$arr2[$i];
    }
}
}
?>