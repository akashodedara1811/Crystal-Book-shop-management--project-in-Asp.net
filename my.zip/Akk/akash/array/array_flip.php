<?php
$arr1 = ["1"=>"akash","2"=>"raj","3"=>"karan"];
$new = array_flip($arr1);//this function is used convert key as a value and value as a key
echo "<pre>";
print_r($new);
echo "</pre>";
?>