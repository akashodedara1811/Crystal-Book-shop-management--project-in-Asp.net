<?php
function test($a,$b)
{
    if($a %2 == 1 or $b%2 == 1)
    {
        return 0;//this block true and return 
    }
    else
    {
        return 1;
    }
}
    $arr1=["1"=>"akash","2"=>"raj","3"=>"karan"];
    $arr2=["1"=>"akash","4"=>"raj","3"=>"karan"];

    $new = array_intersect_uassoc($arr1,$arr2,"test");
    echo "<pre>";
    print_r($new);
    echo "</pre>";

?>