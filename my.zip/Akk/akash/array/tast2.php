<?php
for($i=1;$i<=5;$i++)
{
    for($j=1;$j<=$i;$j++)
    {
        echo " ".$j;

    }
    echo "<br>";
}
echo "<br><br><br>";
 $c=1;

for($i=1;$i<=6;$i++)
{
    for($j=6;$j>$i;$j--)
    {
        echo "&nbsp;&nbsp;&nbsp;";
    }
    for($j=2;$j<$i;$j++)
    {
        echo " &nbsp;".$c;
        $c++;
    } 
     for($j=2;$j<=$i;$j++)
    {
        echo " &nbsp;".$c;
        $c-=1;
    }
    echo "<br>";
    $c = $i;
    
}
 echo "<br><br><br>";
for($i=5;$i>=1;$i--)
{
    for($j=1;$j<=$i;$j++)
    {
        echo "&nbsp;".$j;
    }
    echo "<br>";
    }
    echo "<br><br><br>";
for($i=1;$i<=5;$i++)
{
    for($j=1;$j<=$i;$j++)
    {
        if($j==1 || $i == $j)
        {
        echo "&nbsp;".$j;
        }
        else if($i == 5)
        {
           echo "&nbsp".$j;
        }
        else
        {
            echo "&nbsp;&nbsp;&nbsp;";
        }
    }
    echo "<br>";
    }




    echo "<br><br><br>";
for($i=5;$i>=1;$i--)
{
    for($j=1;$j<=$i;$j++)
    {
         if($j== 1|| $j == $i)
        {
            echo "&nbsp;".$j;
        } 
        else if($i==5)
        {
            echo "&nbsp;".$j;
        }
        else
        {
            echo "&nbsp;&nbsp;&nbsp;";
        }
        
    }
    echo "<br>";
    } 

    echo "<br><br><br>";
 
    for($i=1;$i<=5;$i++)
{
    for($j=5;$j>=$i;$j--)
    {
        echo "&nbsp;&nbsp;&nbsp;";
    }
    for($j=1;$j<=$i;$j++)
    {
        if($j==1 || $i == $j)
        {
        echo "&nbsp;&nbsp;&nbsp;".$j;
        }
        else if($i == 5)
        {
           echo "&nbsp;&nbsp;&nbsp;".$j;
        }
        else
        {
            
            echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        }
    }
    echo "<br>";
    }
?>