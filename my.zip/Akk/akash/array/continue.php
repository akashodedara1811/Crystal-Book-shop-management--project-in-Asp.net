<?php
for($i = 1;$i <=6 ; $i++)
{
    for($j=1;$j<=$i;$j++)
    {
         if($i%2==0)
        {continue;
 
        }
        else
        {
            echo " ".$j;
        }
        
    }
    if($i%2==0)
    {
    echo "<br>";
}
}
?>