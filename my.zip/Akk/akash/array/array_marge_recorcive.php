<?php
$arr1 = ["1"=>"akash","2"=>"ram","3"=>"lakhan"];
$arr2 = ["1"=>"tushar","2"=>"karan","5"=>"dipen"];

echo "<pre>";
print_r(array_merge_recursive($arr1,$arr2));
echo "</pre>";
?>