<?php
$arr = [1,2,3,4,5,6,7,8];
$n = count($arr);//count the elements
echo $n;

$surname = "odedara";
$name = "akash";
$new = compact("surname","name");//print variable into array
print_r($new);
?>