<?php
for($i=1;$i<=5;$i++)
{
    for($j=1;$j<=$i;$j++)
{
    echo "* ";
}
    echo "<br>";
}
for($i=5;$i>=1;$i--)
{
    for($j=1;$j<=$i;$j++)
{
    echo "* ";
}
    echo "<br>";
}
echo "<br>";
echo "<table border='2'>";
$c=1;
for($i=1;$i<=10;$i++)
{
    echo "<tr>";
    for($j=0;$j<10;$j++)
    {
        if($j> 1 || $i > 1 || $j != 10)
        {
          
                echo "<td>&nbsp;&nbsp; &nbsp;".$c."</td>";
                $c+=$i;    
        }
        elseif ($j == 10) {
            echo "<td>&nbsp;&nbsp; &nbsp;".$c."</td>";
        }
        else
        {
            echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;".$c."</td>";
            $c+=$j;
        }
       
    }
    $c = $i+1;
    echo "&nbsp;<br>";
    echo "</tr>";
}
echo "</table>";
echo "<br>";
$str1 ="HELLO I AM akash odedara";
$str2 = str_split($str1);

for($i=1;$i<=count($str2);$i++)
{
    if($str2[$i+1]=="a" || $str2[0]=="a" )
    {
        $count++;
     
    } 
}  
echo "<br>value:".($count);
?>