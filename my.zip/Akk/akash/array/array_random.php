<?php
$arr1 = ["red","blue","gray","yellow","brown"];
$rendom = array_rand($arr1,1);
echo $a[$rendom[0]];
echo $a[$rendom[1]];

?>