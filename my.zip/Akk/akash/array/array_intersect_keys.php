<?php
$arr1 =["1"=>"akash","2"=>"raj","3"=>"karan","4"=>"dipen"];
$arr2 =["a"=>"akash","b"=>"raj","c"=>"karan","4"=>"tushar"];
$new1 = array_intersect_key($arr1,$arr2);//this function contains $arr1 and $arr2 same key and print $arr1 key value
echo "<pre>";
print_r($new1);
echo "</pre>";
?>