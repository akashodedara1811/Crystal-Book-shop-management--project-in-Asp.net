<?php
$arr1 = ["akash","raj","lakhan"];
if(in_array("aman",$arr1))
{
    echo "values is available in array";
}
else
{
    echo "value are not available";
}
?>