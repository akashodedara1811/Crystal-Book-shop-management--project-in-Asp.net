<?php
$arr1 = [1,2,3,4,5,6];
function test($a)
{
    if($a >= 2)
    {
      return ($a * $a);
    }
    else
    {
        return 0;
    }
}
$new = array_map("test",$arr1);//THIS FUNCTION IS USED TO GET VALUE AND PROCESS ON IT.
print_r($new);
?>