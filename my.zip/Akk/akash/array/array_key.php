<?php
$arr1 = ["abc","adc","arct"];
$new = array_keys($arr1);//this function is used to contains keys and get in array
print_r($new);
?>