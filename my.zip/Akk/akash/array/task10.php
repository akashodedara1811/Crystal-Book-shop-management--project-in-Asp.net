<form action="" method="post">
    <input type="text" placeholder="enter stoped number..." name="n">
    <input type="submit" name="s">
</form>

<?php
//fibonaci serize
if(isset($_POST['s']))
{
$n = $_POST['n'];
$f =1;
$b = 0;
for($i=0;$i<=$n;$i++)
{
    $c = $f + $b;
    echo "value:".$c."<br>";
    $f = $b;
    $b = $c;
}
}
?>