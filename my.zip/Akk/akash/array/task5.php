<style>
    .dark
    {
       width : 100px;
       height : 100px;
       background-color : black;
    }
    .white
    {

       width : 100px;
       height : 100px;
       background-color : white;
    }
</style>

<table border = "2">
<?php
$c = 1;
for($i = 1; $i <= 8; $i++)
{
    echo "<tr>";
    for($j = 1;$j <=8; $j++)
    {
        if($c % 2 == 0)
            echo "<td class='dark'> </td>";
        else
            echo "<td class='white'></td>";
        $c++;
    }
    $c-=1;
    echo "<br>";
    echo "</tr>";
}
for($i=5;$i>=1;$i--)
{
    for($j=5;$j>=$i;$j--)
    {
        echo "&nbsp;".$i;
    }
    echo "<br>";
}
echo "<br><br>";
for($i=1;$i<=10;$i++)
{
    for($j=1;$j<=4;$j++)
    {
        if($i == 1 && $j == 4 || $i== 10 && $j==1 || $i==2 && $j != 4 && $j !=1 || $i==9 && $j != 4 && $j !=1)
        {
           
                echo "&nbsp;&nbsp;";
           
        }
        else if($i >= 3 && $j>1 && $i<=8)
        {
            echo " ";
        }
        else
        {
            echo "*";
        }
        
    }
    echo "<br>";
}
?>
</table>