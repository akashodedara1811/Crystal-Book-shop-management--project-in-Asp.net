<?php
    $arr1 = ["1"=>"akash","2"=>"odedara","3"=>"apple"];
    print_r($arr1);
array_multisort($arr1);//this function is used to sort the array value    
print_r($arr1);
?>