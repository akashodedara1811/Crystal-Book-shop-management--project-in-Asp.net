<?php
$arr1 = ["1"=>array("akash","ram"),"2"=>"odedara"];
$arr2 = ["3"=>"abc","1"=>"bharat"];
$new = array_replace_recursive($arr1,$arr2);
echo "<pre>";
print_r($new);
echo "</pre>";
?>