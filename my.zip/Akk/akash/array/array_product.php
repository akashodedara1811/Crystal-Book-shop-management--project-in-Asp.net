<?php
$m1= array(4,15,90,10,25,75,6250,50,70,1,4270,110);
$m2 = array(11227);
$new = array_sum($m2)-array_sum($m1);//this function is used multiplay all array value
print_r($new);
?>