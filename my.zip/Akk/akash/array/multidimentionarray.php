<?php
$versions = [array(1,"A"),array(2,"B"),array(3,"C"),];
for($row = 0 ; $row <=2 ; $row++)
{
    echo "row no:".$row;
    for($col = 0;$col<=2;$col++)
    {
        echo "<br>";
        echo $versions[$row][$col];
    }
    echo "<br>";
}
?>