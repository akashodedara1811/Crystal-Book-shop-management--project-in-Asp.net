
<?php
// Variable to check
$url="https://www.w3schools.com";

// Encode characters and remove all characters with ASCII value > 127
$url = filter_var($url, FILTER_SANITIZE_ENCODED, FILTER_FLAG_STRIP_LOWER);
echo $url;
?> 