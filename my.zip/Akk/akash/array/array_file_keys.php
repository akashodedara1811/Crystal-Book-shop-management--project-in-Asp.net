<?php
$arr1 = ["a","b","c","d"];
$new = array_fill_keys($arr1,"akash");//this fuction is used to create same value but key not same
echo "<pre>";
print_r($new);
echo "</pre>"; 
?>