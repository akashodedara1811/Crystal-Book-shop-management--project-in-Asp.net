<?php
$day = date("D");//get date in words like std,sun etc
$Day = date("d");//get date in digites
$year = date("Y");//get year etc 2024
$Year = date("y");//sort year like 22,21
$hour = date("h");//get hour
$minutes = date("i");//get minutes
$second = date("s");//get  second
$a = date("a");//get am/pm
echo $Day."<br>";
echo $day."<br>";
echo $year."<br>";
echo $Year."<br>";
echo $hour."<br>";
echo $Hour."<br>";
echo $second."<br>";
echo $a."<br>";

?>