<?php
$d = strtotime("10:30pm april 10 2001");
echo "<br>".date("d/m/Y",$d);
echo "<br>".date("h:i:sa",$d);
$d = strtotime("+3 week");
echo "<br>".date("d/m/Y",$d);
$d = strtotime("+3 day");
echo "<br>".date("h:i:sa",$d);
?>