<?php
$arr1 = [1,2,3,4,5];
print_r(array_reduce($arr1,"test"));//this function is used to combine with string using user define function
function test($v1,$v2)
{
    return $v1."__".$v2;
}
?>