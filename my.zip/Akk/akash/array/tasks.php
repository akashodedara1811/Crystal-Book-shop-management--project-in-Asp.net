<?php
for($i=1;$i<5;$i++)
{
    for($j=1;$j<=$i;$j++)
    {
        echo " ".$j;

    }
    echo "<br>";
}
echo "<br><br><br>";
echo "<table>";
$c=1;
for($i=0;$i<10;$i++)
{
    echo "<tr>";
    for($j=0;$j<10;$j++)
    {
        if($j == 0 || $i == 0)
        {
            $d=0;
        echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;".$d."</td>";
        }
        else if($j> 1 || $i > 1)
        {
          
                echo "<td>&nbsp;&nbsp; &nbsp;".$c."</td>";
                $c+=$i;    
        }
        else
        {
            echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;".$c."</td>";
            $c+=$j;
        }
       
    }
    $c = $i+1;
    echo "&nbsp;<br>";
    echo "</tr>";
}
echo "</table>";
echo "<br><br><br>";
for($i=1;$i<=10;$i++)
{
    for($j=10;$j>$i;$j--)
    {
        echo "&nbsp;&nbsp;&nbsp;";
    }
    for($j=1;$j<$i;$j++)
    {
        echo " ".$j;
    }
    for($j=$i;$j>=1;$j--)
    {
        echo " ".$j;
    }
    echo "<br>";
}
echo "<br><br><br>";
for($i=1;$i<=10;$i++)
{
    for($j=10;$j>$i;$j--)
    {
        echo "&nbsp;&nbsp;&nbsp;";
    }
    for($j=1;$j<$i;$j++)
    {
        echo " ".$j;
    }
    for($j=$i;$j>=1;$j--)
    {
        echo " ".$j;
    }
    echo "<br>";
}
for($i=9;$i>=1;$i--)
{
    for($j=9;$j>=$i;$j--)
    {
        echo "&nbsp;&nbsp;&nbsp;";
    }
   for($j=1;$j<=$i;$j++)
   {
    echo " ".$j;
   }
   echo "<br>";
}
?>