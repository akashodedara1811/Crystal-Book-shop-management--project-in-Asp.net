<?php
$arr1 = ["akash","ram","raj"];
$arr2 = ["ak","me"];
$n = array_splice($arr1,1,3,$arr2);
echo "<pre>";
print_r($n);
echo "</pre>";

$arr2 = [1,4,6,3,2];
echo array_sum($arr2);
?>