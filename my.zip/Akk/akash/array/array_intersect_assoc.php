<?php
$arr1 = ["1"=>"akash","2"=>"odedara"];
$arr2 = ["1"=>"akash","3"=>"odedara"];
$new = array_intersect_assoc($arr1,$arr2);//this dunction return same associated array value
echo "<pre>";
print_r($new);
echo "</pre>";
?>