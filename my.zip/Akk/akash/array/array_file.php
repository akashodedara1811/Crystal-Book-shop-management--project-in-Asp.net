<?php
$arr1 = array("akash","raj","karan");
$newarr = array_fill(1,3,"dipen");//create an array same values
echo "<pre>";
print_r($newarr);//this is array display same value array
echo "</pre>";

echo "<pre>";
print_r($arr1);//this array is display only those values which we have descover in arr1
echo "</pre>";
?>