<?php
class loop
{
    function pattern1($n)
    {
        if(!is_int($n))
        {
            return 0;
        }
        else
        {
      if($n <= 0)
      {
        echo "please enter valide value";
      }
      else
      {
        for($i=1;$i<$n;$i++)
    {
    for($j=1;$j<=$i;$j++)
    {
        echo " ".$j;

    }
    echo "<br>";
    }
}
}
    }
    function pattern2($n)
    {

    if($n <= 0)
    {
      echo "please enter valide value";
    }
    else
    {
        echo "<table>";
$c=1;
for($i=0;$i<$n;$i++)
{
   
    echo "<tr>";
    for($j=0;$j<$n;$j++)
    {
        if($j == 0 || $i == 0)
        {
            $d=0;
        echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;".$d."</td>";
        }
        else if($j> 1 || $i > 1)
        {
          
                echo "<td>&nbsp;&nbsp; &nbsp;".$c."</td>";
                $c+=$i;    
        }
        else
        {
            echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;".$c."</td>";
            $c+=$j;
        }
       
    }
    $c = $i+1;
    echo "&nbsp;<br>";
    echo "</tr>";

}
echo "</table>";
}
    }
  
     function pattern3($n)
     {

    if($n <= 0)
    {
      echo "please enter valide value";
    }
    else
    {
        for($i=1;$i<=$n;$i++)
    {
    for($j=$n;$j>$i;$j--)
    {
        echo "&nbsp;&nbsp;&nbsp;";
    }
    for($j=1;$j<$i;$j++)
    {
        echo " ".$j;
    }
    for($j=$i;$j>=1;$j--)
    {
        echo " ".$j;
    }
    echo "<br>";
    }
}
     }
     function pattern4($n)
     {
        if($n <= 0)
        {
          echo "please enter valide value";
        }
        else
        {

        for($i=1;$i<=$n;$i++)
       {
    for($j=$n;$j>$i;$j--)
    {
        echo "&nbsp;&nbsp;&nbsp;";
    }
    for($j=1;$j<$i;$j++)
    {
        echo " ".$j;
    }
    for($j=$i;$j>=1;$j--)
    {
        echo " ".$j;
    }
    echo "<br>";
   }
for($i=$n-1;$i>=1;$i--)
{
    for($j=$n-1;$j>=$i;$j--)
    {
        echo "&nbsp;&nbsp;&nbsp;";
    }
   for($j=1;$j<=$i;$j++)
   {
    echo " ".$j;
   }
   echo "<br>";
 }
}
     }
     function pattern5($n)
     {
      if($n == 0)
      {
        echo "please enter valid value";
      }
      else
      {
        $c=1;

for($i=1;$i<=$n;$i++)
{
    for($j=$n;$j>$i;$j--)
    {
        echo "&nbsp;&nbsp;&nbsp;";
    }
    for($j=2;$j<$i;$j++)
    {
        echo " &nbsp;".$c;
        $c++;
    } 
     for($j=2;$j<=$i;$j++)
    {
        echo " &nbsp;".$c;
        $c-=1;
    }
    echo "<br>";
    $c = $i;
    
}
      }
     }
     function pattern6($n)
     {

      if($n == 0)
      {
        echo "please enter valid value";
      }
      else
      {
        for($i=$n;$i>=1;$i--)
{
    for($j=1;$j<=$i;$j++)
    {
        echo "&nbsp;".$j;
    }
    echo "<br>";
    }

      }
     }
     function pattern7($n)
     {

      if($n == 0)
      {
        echo "please enter valid value";
      }
      else
      {
        for($i=$n;$i>=1;$i--)
{
    for($j=1;$j<=$i;$j++)
    {
         if($j== 1|| $j == $i)
        {
            echo "&nbsp;".$j;
        } 
        else if($i==$n)
        {
            echo "&nbsp;".$j;
        }
        else
        {
            echo "&nbsp;&nbsp;&nbsp;";
        }
        
    }
    echo "<br>";
    } 

      }
     }
     function pattern8($n)
     {

      if($n == 0)
      {
        echo "please enter valid value";
      }
      else
      {
        for($i=1;$i<=$n;$i++)
{
    for($j=$n;$j>=$i;$j--)
    {
        echo "&nbsp;&nbsp;&nbsp;";
    }
    for($j=1;$j<=$i;$j++)
    {
        if($j==1 || $i == $j)
        {
        echo "&nbsp;&nbsp;&nbsp;".$j;
        }
        else if($i == $n)
        {
           echo "&nbsp;&nbsp;&nbsp;".$j;
        }
        else
        {
            
            echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
        }
    }
    echo "<br>";
    }
      }
     }

     function pattern9($n)
     {
       
      if($n == 0)
      {
        echo "please enter valid value";
      }
      else
      {
        for($i=1;$i<=$n;$i++)
{
    for($j=1;$j<=$i;$j++)
    {
        if($j==1 || $i == $j)
        {
        echo "&nbsp;".$j;
        }
        else if($i == $n)
        {
           echo "&nbsp".$j;
        }
        else
        {
            echo "&nbsp;&nbsp;&nbsp;";
        }
    }
    echo "<br>";
    }
      } 
     }  
}

$a = 5;
$lop = new loop();
$lop -> pattern1($a);
echo "<br><hr>";
$lop -> pattern2($a);
echo "<br><hr>";
$lop -> pattern3($a);
echo "<br><hr>";
$lop -> pattern4($a);
echo "<br><hr>";
$lop -> pattern5($a);
echo "<br><hr>";
$lop -> pattern6($a);
echo "<br><hr>";
$lop -> pattern7($a);
echo "<br><hr>";
$lop -> pattern8($a);
echo "<br><hr>";
$lop -> pattern9($a);
echo "<br><hr>";
?>