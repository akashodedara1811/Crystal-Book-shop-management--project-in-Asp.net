<?php
$arr1 = ["abc","dec","efg"];
$new = array_reverse($arr1,$arr2);//this function is used to reverce the array same as rsort()
print_r($new);
?>