<?php
$arr = array(array(
    'id' => 5698,
    'first_name' => 'Peter',
    'last_name' => 'Griffin',
  ),
  array(
    'id' => 4767,
    'first_name' => 'Ben',
    'last_name' => 'Smith',
  ),
  array(
    'id' => 3809,
    'first_name' => 'Joe',
    'last_name' => 'Doe',
  ));
$arr1= array_column($arr,"last_name");
echo "<pre>";
print_r($arr1);
echo "</pre>";
?>