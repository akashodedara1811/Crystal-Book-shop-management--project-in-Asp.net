<?php
$arr = array("A"=>"akash","B"=>"akash","C"=>"akash",);
$arr1 = array_change_key_case($arr);
echo "<pre>";
print_r($arr1);
echo "</pre>";
?>