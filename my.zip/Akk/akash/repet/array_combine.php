<?php
$arr1 = array("name"=>"Akash","surname"=>"odedara");
$arr2 = array("work"=>"full-time","place"=>"ahemdabad");
$arr3 = array_combine($arr1,$arr2);
?>