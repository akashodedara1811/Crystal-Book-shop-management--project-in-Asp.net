<?php
   $arr = array(1,2,3,4,5);
   foreach($arr as $i)
   {
    echo "".$i."<br>";
   }
echo "<br><br>";
   #index array
   $arr[0]= 1;
   $arr[2]= 50;
   $arr[1]= 30;
   $arr[3]= 20;
   foreach($arr as $i)
   {
    echo "".$i."<br>";
   }
   echo "<br><br>";
   #associative array
   $aarr['a'] = 10;
   $aarr['b'] = 20;
   $aarr['c'] = 30;
   foreach($aarr as $key=>$i)
   {
    echo "key :".$key."&nbsp&nbspValue:".$i."<br>";
   }

   #multidimension array
   $arr=array(array(1,2,3),array(4,5,6),array(7,8,9),);
   echo "<pre>";
   print_r($arr);
   echo "</pre>";
?>