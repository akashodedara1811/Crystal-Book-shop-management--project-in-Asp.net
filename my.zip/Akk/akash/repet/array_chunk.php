<?php
$arr = array(1,2,3,4,5);
$arr1 = array_chunk($arr,2);
echo "<pre>";
print_r($arr1);
echo "</pre>";
?>