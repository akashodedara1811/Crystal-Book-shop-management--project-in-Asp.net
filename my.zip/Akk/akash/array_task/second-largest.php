<?php
function large($arr)
{
    $max = 0;
    $sec=0;
    $max = max($arr);
    for ($i=0; $i <count($arr) ; $i++) { 
        for ($j=0; $j < count($arr); $j++)
         { 
            if($arr[$i] > $arr[$j] && $max > $arr[$i])
            {
                $sec = $arr[$i];
            }
        }
    }
    return $sec;
}
$arr = array(1,3,56,50,58,678,675);
print_r(large($arr));
?>