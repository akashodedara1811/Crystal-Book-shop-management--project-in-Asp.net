<?php
$arr = array(array(11,12,13),array(14,15,16),array(17,18,19),array(20,21,22));
$c = 0;
$row = 4;
if($row % 2 == 1)
{
for ($i=0; $i < $row; $i++) { 
    for ($j=0; $j < $row; $j++) { 
        if($j % 2 == 0 && $j > 1)
        {
            echo " ".$arr[$j][$i];
        }
    }
    for ($h=0; $h <$row ; $h++) { 
        
        if($h % 2 == 1)
        {
            echo " ".$arr[$h][$i];
        }
    }

    for ($k=0; $k < $row ; $k++) { 
        
        if($k % 2 == 0 && $k < 1)
        {
            echo " ".$arr[$k][$i];
        }
    }
    echo "<br>";
} 
}
else
{
    for ($i=0; $i < $row; $i++) { 
        for ($j=0; $j < $row; $j++) { 
            if($j % 2 == 1&& $j > 1)
            {
                echo " ".$arr[$j][$i];
            }
        } 
        for ($h=0; $h <$row ; $h++) { 
            
            if($h % 2 == 0 && $h > 1)
            {
                echo " ".$arr[$h][$i];
            }
        }
     
        for ($l=0; $l <$row ; $l++) { 
            
            if($l % 2 == 1 && $l <=1)
            {
                echo " ".$arr[$l][$i];
            }
        }
        for ($k=0; $k < $row ; $k++) { 
            
            if($k % 2 == 0 && $k < 1)
            {
                echo " ".$arr[$k][$i];
            }
        }
        echo "<br>";
    } 
}
?>