<?php
function test(array $arr){
    $valu = [];
    $ret = [];
    for($i=0; $i<count($arr); $i++){
        $el = $arr[$i];
        $map = [];
        for($j=0; $j<strlen($el); $j++){
            if($map[$el[$j]] == ""){
                $map[$el[$j]]=0;
            }
            $map[$el[$j]]++;
        }
        ksort($map);
        
        $key = serialize($map);

        if($valu[$key] == ""){
            $valu[$key] = [];
        }
        $valu[$key][] = $el;
    }
    foreach($valu as $key=>$val){
        $ret[] = $val;
    }
    return $ret;
}
$a =  ["eat", "tea", "tan", "ate", "nat", "bat"];
print_r(test($a));
?>