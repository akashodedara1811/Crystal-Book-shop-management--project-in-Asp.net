<?php 
//Input: "babad"
//Output: "bab" (or "aba")

$str = "babad";
echo "INPUT : $str".str($str)."<br>";
function str($str)
{
$strrev = strrev($str);

$first = str_split($str);
$second = str_split($strrev);

for ($i=0; $i <count($first) ; $i++) { 

       if($first[$i] == $second[$i])
       {
        $val[$i] = $second[$i];
       }
       else
       {
        $val[] = '';
       }
}
echo "OUTPUT : ".implode($val)." Palidrom string.<br>";
}
?>  