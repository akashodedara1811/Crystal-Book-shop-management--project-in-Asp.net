<?php
/* Input: [3, 1, 4], [2, 5]
Output: [1, 2, 3, 4, 5] */

 
/*echo "Before sorting : ";
foreach($sort as $s)
{
    print_r($s);
    foreach($s as $result)
    {
        $re[] = $result;
    }
}
echo "<br><br>After sorting : "; */
$sort = array(array(10,7,4),array(3,1));
$mr = array_column($sort,'1');
$ms = array_column($sort,'2');
$m = array_column($sort,'0');
$mrg = array_merge($mr,$m,$ms);
sort($mrg);
print_r($mrg); 
?>