<?php

$input = array(array(1,2,3),array(4,5,6),array(7,8,9));
echo test($input);


function test($n)
{
    $count = 0; 
    $val = array();
  foreach ($n as $ke) {
    foreach ($ke as $k) {
        echo $k." ";
        $val[] = $k;
    }
    $first = count($ke);
    $count = $count + count($ke);
    echo "<br>";
  }
  $row = $count / $first;
  $c = 0;
$set = array();
 for ($i=0; $i <$row ; $i++)
  { 
    for($j=0;$j<$first;$j++)
    {
        if($j == $c)
        {
        $set[] = $val[$c];
       }
       $c++;  
    }   
    if($c != $first)
    {
    $set[] = $val[$c-1];
    }
 }
    for($j=($c-1);$j >= ($first*2)+1; $j--)
    {
        $set[] = $j;
    }
    $d  = $j-($row-1);

    for($j=$d;$j<($first *2); $j++)
    {
        $set[] = $j;
    }
    echo "<pre>";
 print_r($set);
 echo "<pre>";
     
}
?>