<?php
# task 1 first page
session_start();
?>
<form action="" method="post">
 Name : <input type="text" placeholder="Enter student name:" name="name"><br><br>
  Gujrati:  <input type="text" placeholder="Enter first subject marks:" name="n1"><br>
  English: <input type="text" placeholder="Enter second subject marks:" name="n2"><br>
  hindi: <input type="text" placeholder="Enter thired subject marks:" name="n3"><br>
   sanscrit: <input type="text" placeholder="Enter forth subject marks:" name="n4"><br>
   Maths: <input type="text" placeholder="Enter fifth subject marks:" name="n5"><br>
    sciense<input type="text" placeholder="Enter sixth subject marks:" name="n6"><br>
    sosial sciense:<input type="text" placeholder="Enter seventh subject marks:" name="n7"><br>
    <input type="submit" name="s">
</form>

<?php
if(isset($_POST['s']))
{
    $_SESSION["name"] =  $_POST['name'];
    $_SESSION["num1"] =  $_POST['n1'];
    $_SESSION["num2"] =  $_POST['n2'];
    $_SESSION["num3"] =  $_POST['n3'];
    $_SESSION["num4"] =  $_POST['n4'];
    $_SESSION["num5"] =  $_POST['n5'];
    $_SESSION["num6"] =  $_POST['n6'];
    $_SESSION["num7"] =  $_POST['n7'];
  header("location:task_1_secondpage.php");
   
}
?>