<form action="" method="post">
    <table>
        <Tr>
    <td>Row :</td>
    <td><input type="number" placeholder="please enter row:"  name="row"/></td>
    </Tr>
    <tr>
    <td>columns :</td><td> 
        <input type="number" placeholder="please enter coumans" name="cols" />
        </td>
    </tr>
    <tr>
    <td><input type="submit" value="create table" name="submited"/></td>
    <td></td>
</tr>
    </table>
</form>
<?php
if(isset($_POST['submited']))
{
    include "testing.php";
}
    ?>