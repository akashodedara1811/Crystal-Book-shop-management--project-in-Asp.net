<?php
session_start();
?>
<form method="post">
    <input type="text" name="rows" ><br>
    <input type="text" name="cols"><br>
    <input type="submit" name="s"><br>
</form>
<?php
if(isset($_POST['s']))
{
    echo "<form method='post' >";
    $row = $_POST['rows'];
    $col =$_POST['cols'];
    for($i=1;$i<=$row;$i++)
    {
        for($j=1;$j<=$col;$j++)
        {
          echo "<input type='text' name='val[]'/>";
          echo "<input type='hidden' name='$row'/>";
          echo "<input type='hidden' name='$col'/>";
        }
        $r = $_POST['val'];
    echo "<br>";
    }
    $_SESSION['value'] = $_POST['val'];

    echo "<pre>";
    print_r($r);
    echo "</pre>";
    echo "<input type='submit'/>";
    echo "</form>";
}
?>
<input type="hidden" name="$row">
