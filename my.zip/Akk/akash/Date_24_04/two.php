    <form method="post">
    <input type="text" name="row" ><br>
        <input type="text" name="col"><br>
        <input type="submit" name="s"><br>
    </form>
    <?php

    if(isset($_POST['s']))
    {
        $n=$_POST['row'];
        $n2=$_POST['col'];
        echo "<form action='three.php' method='post'>";
        for ($i=1; $i <= $n ; $i++) { 
            for ($j=1; $j <= $n2 ; $j++) { 
                echo "<input type='text' name='data[$i][$j]'>";
                echo "<input type='hidden' name='row' value='$n'>";
                echo "<input type='hidden' name='col' value='$n2'>";
            }
            echo "<br>";
        }
        echo " <input type='submit' >";
        echo "</form>";
    }  
    ?>