<?php
session_start();
$row = $_POST['row'];
$cols = $_POST['col'];
$arr = $_POST['data'];
echo "<table border=2>";
    for($i=1;$i<=$row;$i++)
    {
        echo "<tr>";
        for($j=1;$j<=$cols;$j++)
        {
            if(!empty($_POST['data'][$i][$j]))
                echo "<td>".$arr[$i][$j]."</td>";
            else
                echo "<td>null</td>";
        }
    echo "</tr>";
    } 
echo "</table>";
?>