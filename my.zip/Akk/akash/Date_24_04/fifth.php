<form action="" method="post">
    <input type="text" placeholder="enter number " name="num1"><br>
    <input type="text" placeholder="enter second number" name="nm"><br>
    <input type="submit" name="s">
</form>

<?php
if(isset($_POST['s']))
{
    $num1 = $_POST["num1"];
    $num2 = $_POST["nm"];
 
    for ($i=1; $i<= $num2 ; $i++)
    { 
    echo $num1."*".$i."=".($num1*$i)."<br>";
    }
 }
?>