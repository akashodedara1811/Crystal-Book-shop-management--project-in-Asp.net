<form action="" method="post">
    <input type="text" placeholder="please enter number" name="nm">
    <input type="submit" name="s">
</form>

<?php
if(isset($_POST['s']))
{
    $num = $_POST['nm'];
    for ($i=$num; $i >=1 ; $i--)
     { 
        for ($j=$num; $j >=$i ; $j--) {

            echo " ".$j;
        }
        echo "<br>";
    }
}
?>