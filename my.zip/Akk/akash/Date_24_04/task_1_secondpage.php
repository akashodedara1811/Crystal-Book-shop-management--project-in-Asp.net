<?php
session_start();
$name = $_SESSION["name"];
$num1 = $_SESSION["num1"];
$num2 = $_SESSION["num2"];
$num3 = $_SESSION["num3"];
$num4 = $_SESSION["num4"];
$num5 = $_SESSION["num5"];
$num6 = $_SESSION["num6"];
$num7 = $_SESSION["num7"]; 

?>
<table border=2>
    <tr>
        <th>details:</th>
        <th>Marks:</th>
    </tr>
<?php
 $pr = (($num1+$num2+$num3+$num4+$num5+$num6+$num7)/7);

if($num1 >= 30 &&$num2 >= 30 &&$num3 >= 30 &&$num4 >= 30 &&$num5 >= 30 &&$num6 >= 30 &&$num7 >= 30)
{
    echo "<tr>";
    echo "<td>name:</td><td>".$name."</td>";
    echo "</tr>";
echo "<tr>";
echo "<td>Total marks:</td><td>".($num1+$num2+$num3+$num4+$num5+$num6+$num7)."</td>";
echo "</tr>";

echo "<tr>";
echo "<td>pr:</td><td>".$pr."</td>";
echo "</tr>";

if($pr >= 80)
{
echo "<tr>";
echo "<td>Grad:</td><td>A</td>";
echo "</tr>";
}
else if($pr >= 70 && $pr < 80)
{
    echo "<tr>";
    echo "<td>Grad:</td><td>B</td>";
    echo "</tr>";
    
}
else
{
    echo "<tr>";
    echo "<td>Grad:</td><td>C</td>";
    echo "</tr>";
    
}

}
else
{

    echo "<tr>";
    echo "<td>name:</td><td>".$name."</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td>Total marks:</td><td> Faild</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td>pr:</td><td> Faild</td>";
    echo "</tr>";
} 
?>
</table>
<!-- /* if($num1 >= 30)
{
echo "<tr>";
echo "<td>subject1:</td><td>".$num1."</td>";
echo "</tr>";
}
else
{
    echo "<tr>";
    echo "<td>subject1:</td><td>faild</td>";
    echo "</tr>";
}
if($num2 >= 30)
{

echo "<tr>";
echo "<td>subject2:</td><td>".$num2."</td>";
echo "</tr>";
}
else
{
    echo "<tr>";
    echo "<td>subject2:</td><td>faild</td>";
    echo "</tr>";
}
if($num3 >= 30)
{

echo "<tr>";
echo "<td>subject3:</td><td>".$num3."</td>";
echo "</tr>";
}
else
{
    echo "<tr>";
    echo "<td>subject3:</td><td>faild</td>";
    echo "</tr>";
    }
if($num4 >= 30)
{

echo "<tr>";
echo "<td>subject4:</td><td>".$num4."</td>";
echo "</tr>";
}
else
{
    echo "<tr>";
    echo "<td>subject4:</td><td>faild</td>";
    echo "</tr>";
    }
if($num5 >= 30)
{
echo "<tr>";
echo "<td>subject5:</td><td>".$num5."</td>";
echo "</tr>";
}
else
{
    echo "<tr>";
    echo "<td>subject5:</td><td>faild</td>";
    echo "</tr>";
}
if($num6 >= 30)
{
echo "<tr>";
echo "<td>subject6:</td><td>".$num6."</td>";
echo "</tr>";
}
else
{
    echo "<tr>";
    echo "<td>subject6:</td><td>faild</td>";
    echo "</tr>";
}
if($num7 >= 30)
{
echo "<tr>";
echo "<td>subject7:</td><td>".$num7."</td>";
echo "</tr>";
}
else{
    echo "<tr>";
    echo "<td>subject7:</td><td>faild</td>";
    echo "</tr>";
} */ -->