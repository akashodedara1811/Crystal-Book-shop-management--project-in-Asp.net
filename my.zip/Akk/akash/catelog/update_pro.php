<?php
$id = $_POST['id'];
$pname = $_POST['pname'];
$pdes = $_POST['pdes'];
$pcat = $_POST['pcat'];
$psub1 = $_POST['psub'];
$pprice = $_POST['pprice'];
$pstock = $_POST['pstock'];
$psub = implode(",",$psub1);

echo $psub;
if($psub == "" || $pcat == "")
{
    $con = mysqli_connect("localhost","root","root","Ajax_catlog");
    mysqli_query($con,"update product set pname='{$pname}',pdes='{$pdes}',pprice='{$pprice}',pstock='{$pstock}' where id ='{$id}'");     

}
else
{
    $con = mysqli_connect("localhost","root","root","Ajax_catlog");
    mysqli_query($con,"update product set pname='{$pname}',pdes='{$pdes}',pcat='{$pcat}',psub='{$psub}',pprice='{$pprice}',pstock='{$pstock}' where id ='{$id}'");     
 }
     ?>