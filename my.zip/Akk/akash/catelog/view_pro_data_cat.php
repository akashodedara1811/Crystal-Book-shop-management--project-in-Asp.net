<?php
      $sid = $_POST['vid'];
     $con = mysqli_connect("localhost","root","root","Ajax_catlog");
     $q = mysqli_query($con,"select * from product where id = '{$sid}'");
     while($r = mysqli_fetch_assoc($q))
     {
      echo "<p align=center><b>product id</b> : {$r['id']}<p>";
      echo "<p align=center><b>product Name</b> : {$r['pname']}<p>";
      echo "<p align=center><b>product Description</b> : {$r['pdes']}<p>";
      echo "<p align=center><b>product category</b> : {$r['pcat']}<p>";
      echo "<p align=center><b>product sub category</b> : {$r['psub']}<p>";
      echo "<p align=center><b>product price</b> : {$r['pprice']}<p>";
      echo "<p align=center><b>product stock</b> : {$r['pstock']}<p>";
     }
     
    ?>