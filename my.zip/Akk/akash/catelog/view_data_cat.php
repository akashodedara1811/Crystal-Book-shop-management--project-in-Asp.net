
<?php
      $sid = $_POST['vid'];
     $con = mysqli_connect("localhost","root","root","Ajax_catlog");
     $q = mysqli_query($con,"select * from category where id = '{$sid}'");
     while($r = mysqli_fetch_assoc($q))
     {
      echo "<p align=center><b>id</b> : {$r['id']}<p>";
      echo "<p align=center><b>category Name</b> : {$r['cname']}<p>";
      echo "<p align=center><b>sub category name</b> : {$r['csname']}<p>";
      echo "<p align=center><b>Image </b>: <img src='img/{$r['pic']}' width='100' height='100'/><p>";
     }
     
    ?>
    
   