<?php
      $sid = $_POST['eid'];
      $con = mysqli_connect("localhost","root","root","Ajax_catlog");
     $q = mysqli_query($con,"select * from product where id = '{$sid}'");
     echo "<form id='test'>";
     while($r = mysqli_fetch_assoc($q))
     {
      echo "<p align=center><b>id</b> {$r['id']}<p>";
      echo "<p align=center><b>product Name</b> : <input type='text' value ='{$r['pname']}' class='pname'/><p>";
      echo "<p align=center><b>Product Description</b> :<input type='text' value ='{$r['pdes']}' class='pdes'/><p>";
      echo "<p align=center><b>product category</b> :<select id='select_cats'><option>'{$r['pcat']}'</option></select><br><p>";
      echo "<p align=center><b>product sub category</b> :<div id='sets' align=center></div></p>";
      echo "<p align=center><b>product Name</b> : <input type='text' value ='{$r['pprice']}'class='pprice'/><p>";
      echo "<p align=center><b>Product Description</b> :<input type='text' value ='{$r['pstock']}' class='pstock'/><p>";
      echo "<p align=center><input type='submit' value ='EDIT NOW' data-vid='{$r['id']}' class='edit' style='background-color:yellow;padding-left:2%'/><p>";
    }
     echo "</form>"; 
    
     ?> 
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
     $.ajax({
         url: "show_cat_for_drop.php",
        type: "POST",
      success:function(data)
      {
        $("#select_cats").html(data);
      }
     });

     $("#select_cats").change(function(e)
     {
        e.preventDefault();
    var value = $(this).val();
   
    $.ajax({
        url:"set_sub_cat.php",
        type:"post",
        data:{set:value},
        success:function(data)
        {
            
           $("#sets").html(data);
        }
    })
     });


     $(".edit").click(function(e){
    e.preventDefault();
    var id = $(this).data("vid");
    var pname = $(".pname").val();
    var pdes = $(".pdes").val();
    var select_cat = $("#select_cats").val();
    var data = [];
        $(":checkbox:checked").each(function(key){
             data[key] = $(this).val();
        });
    var pprice = $(".pprice").val();
    var pstock = $(".pstock").val();
        $.ajax({
         url: "update_pro.php",
          type: "POST",
          data:{id:id, pname:pname , pdes:pdes , pcat:select_cat , psub:data , pprice:pprice , pstock:pstock },
          success:function(data)
          {
             display();
            $("#show").html(data);  
           } 

   }) 
   })
</script>