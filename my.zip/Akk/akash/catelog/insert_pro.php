<?php
$pname = $_POST['pname'];
$pdes = $_POST['pdes'];
$pcat = $_POST['pcat'];
$psub1 = $_POST['psub'];
$pprice = $_POST['pprice'];
$pstock = $_POST['pstock'];
$psub = implode(",",$psub1);

$con = mysqli_connect("localhost","root","root","Ajax_catlog");
 
        mysqli_query($con,"insert into product(pname,pdes,pcat,psub,pprice,pstock) values ('{$pname}','{$pdes}','{$pcat}','{$psub}','{$pprice}','{$pstock}')"); 
?>