
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <!-- Button to Open the Modal -->
  <button type="button" class="btn btn-primary p-2" data-toggle="modal" data-target="#myModal" style='margin-left:80%;margin-top:5%'>
    Add category
  </button>

  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Add category</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modals-body">
          <form id="test">
            <div style='margin-left:20%' >
                <input type="text" name="cname" id="cname" class='form-text' placeholder="Enter category Name:"><br>
                <input type="text" name="csname" id="csname" class='form-text' placeholder="Enter sub-category Name:"><br><br>
                <input type="file" name="file" id="file" class='form-text'><br>
                </div>
          </form>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer" align=center>
          <button type="button" class="btn btn-primary" id='save' data-dismiss="modal">Save</button>
        </div>
        
      </div>
    </div>
  </div>
  
</div> 
<div class="modal fade" id="data" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header" style='text-align:center'>
        <h4 class="modal-title m-3" >Category View</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         
        </div>
        <div class="modal-body">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
<table class='table table-striped' align=center style='margin-top:8%;width:70%' id='show'>

</table>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    
    function display()
    {
    $.ajax({
         url: "show.php",
        type: "POST",
      success:function(data)
      {
        $("#show").html(data);
      }
     })
    }

        
$(document).ready(function(){
  display();
  $("#save").click(function(e){
    e.preventDefault();
    var formData = new FormData($("#test")[0]);
    $.ajax({
         url: "insert_cat.php",
   type: "POST",
    data: formData,
    contentType: false,
         cache: false,
    processData:false,
      success:function(data)
      {
       
       display();
       $("#show").html(data); 
       $("#Mymodel").load("category.php"); 
       }
    });    
    $("#cname").val('');
    $("#csname").val('');
    $("#file").val('');
  });
 
})
  
</script> 
