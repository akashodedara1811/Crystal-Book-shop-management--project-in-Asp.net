<?php
$name = $_POST['cname'];
$csname= $_POST['csname'];
$file= $_FILES['file']['name'];
$tmp = $_FILES['file']['tmp_name'];
$con = mysqli_connect("localhost","root","root","Ajax_catlog");

    move_uploaded_file($tmp,"img/".$file);
 
        mysqli_query($con,"insert into category(cname,csname,pic) values ('{$name}','{$csname}','{$file}')"); 
?>