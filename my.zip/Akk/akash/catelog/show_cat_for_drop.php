<?php
$con = mysqli_connect("localhost","root","root","Ajax_catlog");
$q = mysqli_query($con,"select count(id),cname from category group by cname");
while($r = mysqli_fetch_assoc($q))
{
    echo "<option>{$r["cname"]}</option>";
    }
?>