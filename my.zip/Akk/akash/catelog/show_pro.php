<?php
$con = mysqli_connect("localhost","root","root","Ajax_catlog");
if(!$con)
{

    echo "connection is failed";
}
else
{
    echo " <tr>
        <th>product Id</th>
        <th>product name</th>
        <th>product Desciption</th>
        <th>Category Name</th>
        <th>Sub Category Name</th>
        <th>product price</th>
        <th>product stock</th>
        <th>Edit</th>
        <th>View</th>
        <th>Delete</th>
        </tr>";
    $q = mysqli_query($con,"select * from product");
    echo "<form>";
    while($r = mysqli_fetch_assoc($q))
    {
        echo "<tr>";
        echo "<td >{$r['id']}</td>";
        echo "<td>{$r['pname']}</td>";
        echo "<td>{$r['pdes']}</td>";
        echo "<td>{$r['pcat']}</td>";
        echo "<td>{$r['psub']}</td>";
        echo "<td>{$r['pprice']}</td>";
        echo "<td>{$r['pstock']}</td>";
        echo "<td><input type='submit' class='view' value='View' data-toggle='modal' data-target='#data' style='background-color:skyblue' data-vid='{$r['id']}'></td>";
        echo "<td><input type='submit' class='Edit'  value='Edit' data-toggle='modal' data-target='#data' style='background-color:yellow' data-eid='{$r['id']}'></td>";
        echo "<td><input type='submit' class='delete' value='Delete' style='background-color:red' data-did='{$r['id']}'></td>";
        echo "</tr>";
    }
    echo "</form>";
}  
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    $(".view").click(function(e){
    e.preventDefault();
      var data = $(this).data("vid");
      
     $.ajax({
         url: "view_pro_data_cat.php",
          type: "POST",
         data:{vid:data},
          success:function(data)
          {
            $(".modal-body").html(data);
          }

   }) 
   })
   $(".Edit").click(function(e){
    e.preventDefault();
      var data = $(this).data("eid");
        $.ajax({
         url: "edit_pro_data_cat.php",
          type: "POST",
         data:{eid:data},
          success:function(data)
          {
            $(".modal-body").html(data);
          } 
        }) 
   })
   $(".delete").click(function(e){
    e.preventDefault();
      var data = $(this).data("did");
      
        $.ajax({
         url: "delete_pro.php",
          type: "POST",
         data:{did:data},
          success:function(data)
          {
          display();
          $("#show").html(data);  
          } 
        })  
   })
   </script>
