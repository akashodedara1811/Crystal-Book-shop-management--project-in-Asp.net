<?php
$set = $_POST['set'];
$con = mysqli_connect("localhost","root","root","Ajax_catlog");
$q = mysqli_query($con,"select csname from category where cname='{$set}'");
while($r = mysqli_fetch_assoc($q))
{
   $e[] = $r['csname'];
} 
$val = implode(",",$e);
$exp = explode(",",$val);
//print_r($exp);
foreach ($exp as $k)
 {
 echo "<input type='checkbox' class='check' value='{$k}'/> {$k}<br>";;
}
?>