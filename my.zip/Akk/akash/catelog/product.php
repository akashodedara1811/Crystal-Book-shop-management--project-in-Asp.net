<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="boostrap/css/bootstrap.min.css">
   <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
 </head>
<body>

<div class="container">
  <button type="button" class="btn btn-primary p-2" data-toggle="modal" data-target="#myModal" style='margin-left:80%;margin-top:5%'>
    Add Product
  </button>

  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Add product</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modals-body">
          <form id="test">
            <div style='margin-left:20%' >
                <input type="text" name="cname" id="pname" class='form-text' placeholder="Enter Product Name:"><br>
                <textarea placeholder="Enter product Description:" id='pdes'></textarea ><br>
                <select id='select_cat'><option>select category</option></select><br>
                <div id='set'></div>
                <input type="text" name="csname" id="pprice" class='form-text' placeholder="Enter product price:"><br>
                <input type="text" name="csname" id="pstock" class='form-text' placeholder="Enter product stock:"><br>
                </div>
          </form>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer" align=center>
          <button type="button" class="btn btn-primary" id='save' data-dismiss="modal">Save</button>
        </div>
        
      </div>
    </div>
  </div>
  
</div> 
<div class="modal fade" id="data" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header" style='text-align:center'>
        <h4 class="modal-title m-3" >View product</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         
        </div>
        <div class="modal-body">

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
<table class='table table-striped' align=center style='margin-top:8%;width:70%' id='show'>

</table>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    

    $.ajax({
         url: "show_cat_for_drop.php",
        type: "POST",
      success:function(data)
      {
        $("#select_cat").html(data);
      }
     });


     $("#select_cat").change(function(e)
     {
        e.preventDefault();
    var value = $(this).val();
    $.ajax({
        url:"set_sub_cat.php",
        type:"post",
        data:{set:value},
        success:function(data)
        {
           $("#set").html(data);
        }
    })
     });
  //display data
  function display()
    {
    $.ajax({
         url: "show_pro.php",
        type: "POST",
      success:function(data)
      {
        $("#show").html(data);
      }
     })
    }
    display();
   //save data
   $("#save").click(function(e)
     {
        display();
        e.preventDefault();
    var pname = $("#pname").val();
    var pdes = $("#pdes").val();
    var select_cat = $("#select_cat").val();
    var data = [];
        $(":checkbox:checked").each(function(key){
             data[key] = $(this).val();
        });
    var pprice = $("#pprice").val();
    var pstock = $("#pstock").val();
       $.ajax({
        url:"insert_pro.php",
        type:"post",
        data:{pname:pname,pdes:pdes,pcat:select_cat,psub:data,pprice:pprice,pstock:pstock},
        success:function(data)
        {
            display();
        }
    }) 
    $("#pname").val('');
    $("#pdes").val('');
    $("#select_cat").val('');
    $("#pprice").val('');
    $("#pstock").val('');
     });
</script>