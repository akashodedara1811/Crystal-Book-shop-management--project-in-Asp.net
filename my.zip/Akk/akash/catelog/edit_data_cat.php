<?php
      $sid = $_POST['eid'];
      $con = mysqli_connect("localhost","root","root","Ajax_catlog");
     $q = mysqli_query($con,"select * from category where id = '{$sid}'");
     echo "<form id='testd'>";
     while($r = mysqli_fetch_assoc($q))
     {
      echo "<p align=center><b>id</b> :{$r['id']}<p>";
      echo "<p align=center> : <input type='hidden' value ='{$r['id']}' name ='id'/><p>";
      echo "<p align=center><b>category Name</b> : <input type='text' value ='{$r['cname']}'name ='cname'class='cname'/><p>";
      echo "<p align=center><b>sub category name</b> :<input type='text' value ='{$r['csname']}' name ='csname' class='csname'/><p>";
      echo "<p align=center><b>Image </b>: <img src='img/{$r['pic']}' width='100' height='100'/><p>";
      echo "<p align=center>: <input type='file' name ='file' class='file'/> <p>";
      echo "<p align=center><input type='submit' value ='EDIT NOW' data-vid='{$r['id']}' class='edit' style='background-color:yellow;padding-left:2%'/><p>";
     
    }
     echo "</form>"; 
    
     ?> 
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    /*  $(".edit").click(function(e){
    e.preventDefault();
      var data = $(this).data("vid");
      var cname = $(".cname").val();
      var csname = $(".csname").val();
        $.ajax({
         url: "update_cat.php",
          type: "POST",
         data:{vid:data,cname:cname,csname:csname},
          success:function(data)
          {
            display();
            $("#show").html(data); 
          } 

   }) 
   }) */
   $(document).ready(function(){
  display();
  $(".edit").click(function(e){
    e.preventDefault();
    var formData = new FormData($("#testd")[0]);
    $.ajax({
         url: "update_cat.php",
   type: "POST",
    data: formData,
    contentType: false,
         cache: false,
    processData:false,
      success:function(data)
      {
        display();
       $("#show").html(data);  
       }
    });    
    $("#cname").val('');
    $("#csname").val('');
    $("#file").val('');
  });
 
})
</script>