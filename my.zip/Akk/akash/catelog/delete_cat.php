<?php
      $sid = $_POST['did'];
     $con = mysqli_connect("localhost","root","root","Ajax_catlog");
     $q = mysqli_query($con,"delete from category where id = '{$sid}'");
    ?>