<?php
$con = mysqli_connect("localhost","root","root","Ajax_catlog");
if(!$con)
{

    echo "connection is failed";
}
else
{
    echo " <tr>
        <th>Category Id</th>
        <th>Category Name</th>
        <th>Sub Category Name</th>
        <th>Pic</th>
        <th>Edit</th>
        <th>View</th>
        <th>Delete</th>
        </tr>";
    $q = mysqli_query($con,"select * from category");
    echo "<form>";
    while($r = mysqli_fetch_assoc($q))
    {
        echo "<tr>";
        echo "<td >{$r['id']}</td>";
        echo "<td>{$r['cname']}</td>";
        echo "<td>{$r['csname']}</td>";
        echo "<td><img src='img/{$r['pic']}' width=100 height='100'</td>";
        echo "<td><input type='submit' class='view' value='View' data-toggle='modal' data-target='#data' style='background-color:skyblue' data-vid='{$r['id']}'></td>";
        echo "<td><input type='submit' class='Edit'  value='Edit' data-toggle='modal' data-target='#data' style='background-color:yellow' data-eid='{$r['id']}'></td>";
        echo "<td><input type='submit' class='delete' value='Delete' style='background-color:red' data-did='{$r['id']}'></td>";
        echo "</tr>";
    }
    echo "</form>";
}  
?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    $(".view").click(function(e){
    e.preventDefault();
      var data = $(this).data("vid");
    //  alert(data);
      $.ajax({
         url: "view_data_cat.php",
          type: "POST",
         data:{vid:data},
          success:function(data)
          {
           // alert(data);
            $(".modal-body").html(data);
          }

   })
   })
   $(".Edit").click(function(e){
    e.preventDefault();
      var data = $(this).data("eid");
       $.ajax({
         url: "edit_data_cat.php",
          type: "POST",
         data:{eid:data},
          success:function(data)
          {
           // alert(data);
            $(".modal-body").html(data);
          } 
        })
   })
   $(".delete").click(function(e){
    e.preventDefault();
      var data = $(this).data("did");
      //alert(data);
        $.ajax({
         url: "delete_cat.php",
          type: "POST",
         data:{did:data},
          success:function(data)
          {
          //  alert(data);
          display();
          $("#show").html(data);  
          } 
        }) 
   })
   </script>
