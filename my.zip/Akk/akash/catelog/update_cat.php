<?php
 $id = $_POST['id']; 
$name = $_POST['cname'];
$csname = $_POST['csname']; 
$file = $_FILES['file']['name'];
$tmp = $_FILES['file']['tmp_name'];


if($_FILES['file']['name']== "")
{
    echo "not updated";
    $con = mysqli_connect("localhost","root","root","Ajax_catlog");
    mysqli_query($con,"update category set cname='{$name}',csname='{$csname}' where id ='{$id}'"); 
  
} 
else
{
    echo "update";
    $con = mysqli_connect("localhost","root","root","Ajax_catlog");
    move_uploaded_file($tmp,"img/".$file);
     mysqli_query($con,"update category set cname='{$name}',csname='{$csname}',pic='{$file}' where id ='{$id}'"); 

} 
?>