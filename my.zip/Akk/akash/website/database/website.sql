-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 21, 2024 at 04:43 PM
-- Server version: 8.0.36-0ubuntu0.20.04.1
-- PHP Version: 7.4.3-4ubuntu2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `addpro`
--

CREATE TABLE `addpro` (
  `id` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `addpro`
--

INSERT INTO `addpro` (`id`) VALUES
('71'),
('71'),
('71'),
('71'),
('74'),
('74'),
('74'),
('74'),
('74');

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `id` int NOT NULL,
  `name` varchar(260) NOT NULL,
  `password` varchar(230) NOT NULL,
  `cpassword` varchar(250) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `hobby` varchar(250) NOT NULL,
  `pic` text NOT NULL,
  `email` varchar(240) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`id`, `name`, `password`, `cpassword`, `gender`, `hobby`, `pic`, `email`) VALUES
(5, 'Akash odedara', '202cb962ac59075b964b07152d234b70', '123', 'Male', 'Reading,Playing', 'download.jpeg', 'akash12@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `category_tbl`
--

CREATE TABLE `category_tbl` (
  `id` int NOT NULL,
  `cname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `csname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `pic` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `category_tbl`
--

INSERT INTO `category_tbl` (`id`, `cname`, `csname`, `pic`) VALUES
(34, 'Apple', 'iphone 6', 'apple_icon.jpg'),
(35, 'Vivo', 'VIVO V19', 'vivo logo.png'),
(37, 'OPPO', 'oppo 12', 'oppo.jpg'),
(41, 'Vivo', 'VIVO V19', 'vivo logo.png'),
(43, 'Apple', 'iphone 6', 'apple_icon.jpg'),
(44, 'Apple', 'iphone 6', 'apple_icon.jpg'),
(45, 'Apple', 'iphone 12', 'apple_icon.jpg'),
(46, 'Apple', 'iphone 16', 'apple_icon.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `id` int NOT NULL,
  `Fname` varchar(300) NOT NULL,
  `Lname` varchar(230) NOT NULL,
  `phone` varchar(250) NOT NULL,
  `address` text NOT NULL,
  `proid` varchar(240) DEFAULT NULL,
  `proitems` varchar(240) DEFAULT NULL,
  `progtotal` varchar(240) DEFAULT NULL,
  `email` text,
  `date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `checkout`
--

INSERT INTO `checkout` (`id`, `Fname`, `Lname`, `phone`, `address`, `proid`, `proitems`, `progtotal`, `email`, `date`) VALUES
(13, 'dipen', 'vyash', '1212121212', 'rajkot', '70,74', '1,2', '42000', 'dipen12@gmail.com', '13-05-2024&nbsp03:59'),
(14, 'test', 'test', '546356454', 'yjhmjghkmj', '65,76,79,74', '1,1,1,2', '283000', 'test@eg.com', '13-05-2024&nbsp04:36'),
(15, 'Bharat', 'odedara', '12121212', 'sdfafafasf', '71,70,78,80', '13,3,1,1', '237323', 'akmer12@gmail.com', '15-05-2024&nbsp12:20'),
(16, 'testt', 'testtt', '12121212', 'ghdfshdh', '71,65', '2,1', '38000', 'akmer12@gmail.com', '15-05-2024&nbsp12:31'),
(17, 'dsgfdsgf', 'dfgdfgdf', '12121212', '213123dsfdsf', '71,65', '7,8', '187000', 'bharatmer11@gmail.com', '15-05-2024&nbsp02:41');

-- --------------------------------------------------------

--
-- Table structure for table `product_tbl`
--

CREATE TABLE `product_tbl` (
  `id` int NOT NULL,
  `pname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `des` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `sdes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `cname` varchar(240) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `scname` varchar(230) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `price` int DEFAULT NULL,
  `stock` int DEFAULT NULL,
  `pic` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `product_tbl`
--

INSERT INTO `product_tbl` (`id`, `pname`, `des`, `sdes`, `cname`, `scname`, `price`, `stock`, `pic`) VALUES
(65, 'Akash odedara', '<p>dsgfdsg<em><strong>dsgdsgdsg</strong></em></p>\r\n', 'dgsdgdsgdsg', 'Apple', 'iphone 13', 12000, 123, 'iphon13.jpg'),
(70, 'Bharat odedara', '<p>This mobile is owner is <em><strong>Bharat&nbsp;odedara.</strong></em></p>\r\n', 'This mobile is owner is Bharat odedara.', 'Apple', 'iphone 11', 18000, 1, 'iphon12.jpg'),
(71, 'vIVO', '<p>ERGERTERTRETRETRETRETRET</p>\r\n', 'this product is used', 'Vivo', 'VIVO V19,VIVO V14', 13000, 123, 'vivo1.jpg'),
(73, 'SMITE rathod', '<ol>\r\n	<li>smite rathod is a owner of this phone.</li>\r\n	<li>Charging Is providede ...</li>\r\n	<li><em>this not using another value</em></li>\r\n	<li><em><strong>this is very power full bettry bekup</strong></em></li>\r\n</ol>\r\n', 'smite rathod is a owner of this phone.', 'SAMSUNG', 'S galexi 10', 11000, 130, 'samsung.jpg'),
(74, 'aka', '<p>!) this ABC</p>\r\n\r\n<p>2) RHTTI xcv</p>\r\n\r\n<p>3) FHDFHFD</p>\r\n\r\n<p>4)ndzjvmxcz</p>\r\n', 'this product is used', 'Vivo', 'VIVO V14', 12000, 12, 'iphon12.jpg'),
(75, 'A man, a plan, a canal, Panama', '<p>Adasdasdsa<em><strong>dsadsadsad</strong></em></p>\r\n', 'this is a ', 'OPPO', 'oppo 12', 12000, 12, 'oppo1.png'),
(76, 'abc', '<p>asdfsfyvsa dsdfhuksj dn<em>fcnsdfb jmnfcsdf</em></p>\r\n', 'dsgfdsfdsfdsfdsf', 'Apple', 'iphone 11,iphone 6', 1000, 1, 'iphon13.jpg'),
(78, 'Apple iphone 14', '<p>THIS IS<em><strong> IS MJDJJJDJJJDJ X</strong></em>BNDA&nbsp; BSDMX SDHC*SW USSD BHSDNND</p>\r\n', 'this product is used', 'Apple', 'iphone 6,iphone 6', 12000, 12, 'iphon12.jpg'),
(79, 'poco', '<p>This is a pr<em><strong>oduct of poco</strong></em></p>\r\n', 'original owner etc', 'OPPO', 'oppo 12', 12000, 12, 'oppo.jpg'),
(80, 'abcsd', '<p>asdafa<em><strong>sfasfasfasf</strong></em></p>\r\n', 'this is a ', 'Vivo', 'VIVO V19', 2323, 23, 'Screenshot from 2024-05-14 10-59-29.png');

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE `user_tbl` (
  `id` int NOT NULL,
  `name` varchar(250) NOT NULL,
  `password` text NOT NULL,
  `cpassword` varchar(250) NOT NULL,
  `email` text NOT NULL,
  `gender` varchar(230) NOT NULL,
  `hobby` varchar(340) NOT NULL,
  `pic` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`id`, `name`, `password`, `cpassword`, `email`, `gender`, `hobby`, `pic`) VALUES
(1, 'abc', 'c20ad4d76fe97759aa27a0c99bff6710', '12', 'akash12@gmail.com', 'Male', 'Reading,Playing', 'Screenshot from 2024-04-30 17-15-28.png'),
(2, 'root', '698d51a19d8a121ce581499d7b701668', '111', 'akmer@12.com', 'Male', 'Reading,Playing', 'Screenshot from 2024-04-30 17-15-28.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_tbl`
--
ALTER TABLE `category_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_tbl`
--
ALTER TABLE `product_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_tbl`
--
ALTER TABLE `user_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `category_tbl`
--
ALTER TABLE `category_tbl`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `product_tbl`
--
ALTER TABLE `product_tbl`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `user_tbl`
--
ALTER TABLE `user_tbl`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
