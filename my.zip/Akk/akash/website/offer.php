<?php
session_start();
$con = mysqli_connect("localhost","root","root","website");
$code = $_POST['code'];
echo "<input type='text' class='code' value='{$code}'>";
$na[] = '';
$que = mysqli_query($con,"select cname from offer where coupen='{$code}'");
 while($r = mysqli_fetch_assoc($que))
{
   if(explode($r['cname']) == $_SESSION['user'])
  {
    echo "Matched.";
    echo "USer name:".$_SESSION['user'];
    $_SESSION['matched'] = 1;
   } 
} 
//}
$qew = mysqli_query($con,"select cname from offer where coupen='{$code}'");
while($r = mysqli_fetch_assoc($qew))
{
    foreach(explode(",",$r['cname']) as $n)
    {
     if($_SESSION['user'] != $n)
    {
        $num = 0;
        $nu[] = $r['cname'];
    } 
    else
    {
        $num = 1;
    }
            
    }
    $i++;
    }
    if($num == 0)
    {
        foreach($nu as $n)
        {
        $value = $n.",".$_SESSION['user'];
          }
        
       mysqli_query($con,"update offer set cname='{$value}' where coupen='{$code}'");
    }
    else
    {
        echo "<script>alert('you can you all redy this..')</script>";
        ?>
        <h1>Order Details:</h1>
        <h3>Total Item(<?php echo $values; ?>)</h3>
        <?php
        $i = 0;
        $sets=0;
        foreach($_SESSION['id'] as $id)
        {
             
            $con = mysqli_connect("localhost","root","root","website");
            $q = mysqli_query($con,"select * from product_tbl where id='{$id}'");
            while($r = mysqli_fetch_assoc($q))
            {
                echo "<b><li>product Name:&nbsp;&nbsp;{$r['pname']}</li></b>";
                echo "<br>";
                echo "<p> Price :".$r['price']."( *{$_SESSION['value'][$i]})</p>";
                echo $r['price'] * $_SESSION['value'][$i];
                $sets = $r['price'] * $_SESSION['value'][$i];
                $i++;
            }
          
        }
        echo " <h2><li>Total :{$_SESSION['total']}";

        
    }

$a = mysqli_query($con,"select cname from offer where coupen='{$code}'");
while($r= mysqli_fetch_assoc($a))
{
    $nm = explode(",",$r['cname']);
}
$av = mysqli_query($con,"select cname from offer where coupen='{$code}' where cname='{$nm}'");
 if(mysqli_num_rows($av) > 0)
{
  echo "not insert this code";

  ?> 
  <h1>Order Details:</h1>
         <h3>Total Item(<?php echo $values; ?>)</h3>
         <?php
         $i = 0;
         $sets=0;
         foreach($_SESSION['id'] as $id)
         {
              
             $con = mysqli_connect("localhost","root","root","website");
             $q = mysqli_query($con,"select * from product_tbl where id='{$id}'");
             while($r = mysqli_fetch_assoc($q))
             {
                 echo "<b><li>product Name:&nbsp;&nbsp;{$r['pname']}</li></b>";
                 echo "<br>";
                 echo "<p> Price :".$r['price']."( *{$_SESSION['value'][$i]})</p>";
                 echo $r['price'] * $_SESSION['value'][$i];
                 $sets = $r['price'] * $_SESSION['value'][$i];
                 $i++;
             }
           
         }
         echo " <h2><li>Total :{$_SESSION['total']}";
        
}
  else
{
$code = $_POST['code'];
$strings = " ";
$off = "";
$cname[] = "";

$qw = mysqli_query($con,"select * from offer where coupen ='{$code}'");
while($a = mysqli_fetch_assoc($qw))
{
    $off = $a['offer'];
    $cname[] = explode(",",$a['cname']);
}
$q = mysqli_query($con,"select cname from offer where coupen='{$code}'");
if(mysqli_num_rows($q) > 0)
{
    
$i =0;
while($r = mysqli_fetch_assoc($q))
{
   $values[] = $r['coupen'];
  $val2 = $r['offer'];
  $qe = mysqli_query($con,"select cname from offer where cname='{$cname}'");
 if(mysqli_num_rows($qe) > 0)
 {
    echo "<script>alert('{$r['cname']}')</script>";
 }
 else
 { 
    if($_SESSION['matched']!= 1)
        {
                    ?> 
    <h1>Order Details:</h1>
           <h3>Total Item(<?php echo $values; ?>)</h3>
           <?php
           $i = 0;
           $sets=0;
           foreach($_SESSION['id'] as $id)
           {
                
               $con = mysqli_connect("localhost","root","root","website");
               $q = mysqli_query($con,"select * from product_tbl where id='{$id}'");
               while($r = mysqli_fetch_assoc($q))
               {
                   echo "<b><li>product Name:&nbsp;&nbsp;{$r['pname']}</li></b>";
                   echo "<br>";
                   echo "<p> Price :".$r['price']."( *{$_SESSION['value'][$i]})</p>";
                   echo $r['price'] * $_SESSION['value'][$i];
                   $sets = $r['price'] * $_SESSION['value'][$i];
                   $i++;
               }
             
           }
          
           $val = $_SESSION['total'];
           $offer = (int)$val - (int)$off;
           $_SESSION['gtotal'] = $offer;
           if($_SESSION['total'] == "")
           {
               header("location:add.php");
           }
           else
           {
            
            
                echo " <h2><li>Total :<del>{$_SESSION['total']}</del>&nbsp;&nbsp;&nbsp;&nbsp;<br><span style='color:green'>$off Rupess OFF to use this cupen code.<br></span><br>Your Total price:<span style='color:green'>{$offer}</span></li></h2>";
              echo " <button style='color:white;background-color:red' class='rem'>Remove coupen code</button>";
            } 
         
         }    
         else
            {
                ?>
                <h1>Order Details:</h1>
        <h3>Total Item(<?php echo $values; ?>)</h3>
        <?php
        $i = 0;
        $sets=0;
        foreach($_SESSION['id'] as $id)
        {
             
            $con = mysqli_connect("localhost","root","root","website");
            $q = mysqli_query($con,"select * from product_tbl where id='{$id}'");
            while($r = mysqli_fetch_assoc($q))
            {
                echo "<b><li>product Name:&nbsp;&nbsp;{$r['pname']}</li></b>";
                echo "<br>";
                echo "<p> Price :".$r['price']."( *{$_SESSION['value'][$i]})</p>";
                echo $r['price'] * $_SESSION['value'][$i];
                $sets = $r['price'] * $_SESSION['value'][$i];
                $i++;
            }
          
        }
        echo " <h2><li>Total :{$_SESSION['total']}";

        
            }
        } 
        } 
}
}

          

 ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
        $(".rem").click(function(e){ 
           e.preventDefault();
          // location.replace("check.php");
         var code= $(".code").val();
         alert(code);
           $.ajax({
            url : "ref.php",
            type:"post",
            data:{code:code},
            success:function(data)
            {
                $("body").html(data);
                //alert(data);
            }
           })
        })
         
        </script>