<?php
session_start();
$code = $_POST['code'];
$val[] = '';
$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select cname from offer where coupen='{$_POST['code']}'");
echo $_SESSION['user'];
while($r = mysqli_fetch_assoc($q))
{
    foreach (explode(",",$r['cname']) as $k) {
        if($_SESSION['user'] == $k)
        {
            continue;
        }    
        else
        {
            $val[] = $k;
        }
    }
    
}
print_r($val);
foreach($val as $v)
{
mysqli_query($con,"update offer set cname='{$v}' where coupen='{$code}'");
}
header("location:check.php");
    ?>