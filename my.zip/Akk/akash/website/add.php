<?php
session_start();
/* session_destroy(); */
?>
<div id="show"></div>
<input type="hidden" name="stocks" id="stock_In_checkout">
<input type="hidden" name="" class="gtotall">
<div align=center>
<a href="shop.php" name="ss" class="continueshop">continue Shoping</a>&nbsp;&nbsp;&nbsp;
<a href="check.php" name="val"   class="test">checkout now</a>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
  
    $( document ).ready(function() {
        
    $.ajax({
        url : "show_addto.php",
        type : "post",
        success : function(data)
        {
            $("#show").html(data);
        }
    });
  $(".test").click(function(e){
  //e.preventDefault();
    var arrNumber = new Array();
        $('input[type=number]').each(function(){
        arrNumber.push($(this).val());
})
    $("#stock_In_checkout").val(arrNumber);
    var defaultval = $("#defaultval").val();
    var totalprice = $(".gtotall").val();
    $.ajax({
        url : "checkout.php",
        type : "post",
        data : {che:arrNumber,tprice: totalprice,defaultval:defaultval},
        success:function(data)
        {
            //alert();
        }
    });
});

  $(".continueshop").click(function(e){
 // e.preventDefault();
    var add_to_cart_value= $("#defaultval").val();
      $.ajax({
        url : "stock_set.php",
        type : "post",
        data : {set:add_to_cart_value},
        success:function(data)
        {
         // alert("value is "+data);
        }
    });   
  });
});

</script>
<?php

?>