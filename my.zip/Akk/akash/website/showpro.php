<?php
session_start();
$pro = $_GET['c'];
if($_SESSION['user'] != "")
{ 
?>
<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">  
    <title>Price Range Slider | CodingNepal</title>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body>
    <h3 align=center>User Name:&nbsp;&nbsp;<?php echo $_SESSION['user']; ?>&nbsp;&nbsp; <a href="logout.php?c=<?php echo $pro; ?>">Logout</a></h3>
   <form method="POST">
    <div class="wrapper">
      <div class="price-input">
        <div class="field">
          <span>Min</span>
          <input type="number" class="input-min" value="0">
        </div>
        <div class="separator">-</div>
        <div class="field">
          <span>Max</span>
          <input type="number" class="input-max" value="19000">
        </div>
      </div>
      <div class="slider">
        <div class="progress"></div>
      </div>
      <div class="range-input">
        <input type="range" class="range-min" min="0" max="19000" value="0" step="50" >
        <input type="range" class="range-max" min="0" max="19000" value="19000" >
      </div>
    </div>
    <input type="button" value="Search" name="btn" style="margin-left:15%" class="btn">
    </form>
    <div id="values"></div>&nbsp;&nbsp;&nbsp;
    <div id="values1"></div>

  </body>
</html>
<a href="shop.php">Back</a>
<?php
}
else
{
 
  header("location:login.php");
} 
?>
    <script src="script.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
      //------------------------ this code to get value from url --------
      var name = "";
      const searchParams = new URLSearchParams(window.location.search);
      for (const param of searchParams) {
       console.log(param[0]);
       name = param[1];
       }
        //--------------------------------------------------------------
   
      $(".btn").click(function(e){
        
            var val1= $(".input-min").val();
            var val2= $(".input-max").val();
             $.ajax({
                   url:"slider.php",
                   type:"post",
                   data:{promin : val1,promax : val2,value:name},
                   success:function(data)
                   {
                   $("#values").html(data);
                   }
             });
        
      });
    $.ajax({
         url : "showall.php",
         type:"post",
         data : {value:name},
         success:function(data)
         {
                   $("#values").html(data);
         }
      });
        </script>