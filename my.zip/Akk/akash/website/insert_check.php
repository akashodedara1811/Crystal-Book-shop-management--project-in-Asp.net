<?php
echo "this code is working";
 mysqli_query($con,"delete from addpro");
session_start();
$first_name = $_POST['fname'];
    $last_name = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $product_id = implode(",",$_SESSION['id']);
    $product_item = implode(",",$_SESSION['value']);
    $product_total = $_SESSION['total'];
    //echo $first_name;
   $code = $_POST['code'];
   echo "code:".$code;
     $con = mysqli_connect("localhost","root","root","website");
  $q = mysqli_query($con,"select * from checkout where Fname = '{$first_name}'");
   if(mysqli_num_rows($q) > 0)
   {
    echo "already existed...";
    }
    else
    {
       $date = date("d-m-Y");
       $time = date("h:i");
       $current = $date."&nbsp".$time;
        $q = mysqli_query($con,"insert into checkout(Fname,Lname,email,phone,address,proid,proitems,progtotal,date,off) values ('{$first_name}','{$last_name}','{$email}','{$phone}','{$address}','{$product_id}','{$product_item}','{$product_total}','{$current}','{$code}')");
        mysqli_query($con,"delete * from addpro");
        header("location:thank.php");
       // session_destroy();
    }  
 // 
    ?>