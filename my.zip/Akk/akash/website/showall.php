<?php
session_start();
$val = $_POST["value"];
?>
<form method='post' enctype='multipart/form-data'>
<div style='display:flex'>
<?php     
   $con = mysqli_connect("localhost","root","root","website");
   $q = mysqli_query($con,"select *  from user_tbl where name='{$_SESSION['user']}' and product='{$val}'");
   if(mysqli_num_rows($q))
   {
      while($r = mysqli_fetch_assoc($q))
      {
        $ps = explode(",",$r['productname']);              
      }
      foreach ($ps as $p) 
      {
         $q = mysqli_query($con,"select * from product_tbl where  id='{$p}'");
         while($r = mysqli_fetch_assoc($q))
            { 
            ?>
               <div style="border:2px solid black;width:19%;color:gray">
               <input type="hidden"  name="val" class="val" value="<?php echo $r['id'] ?>">
               <a href="proinfo.php?p=<?php echo $r['id']?>"> <img class="pic" src="Admin/img/<?php echo $r['pic']?>" alt="" width=250 height=250 align=center style="margin-top:2%;padding:2%;"></a><br>
               <a href="proinfo.php?p=<?php echo $r['id']?>">Product Name:  <p align=center class="pname"><?php echo $r["pname"]; ?></p></a>
               Product Description:<p align=center class="des"> <?php echo $r["sdes"]; ?></p>
               Product price: <p align=center><?php echo $r["price"]; ?></p>
               <p align=center><a name="sub" data-id="<?php echo $r['id'] ?>" class="value" href="add.php">ADD TO CART</a></p>
               </div> 
               &nbsp;&nbsp;&nbsp;
            <?php
               }
            }         
      
   }
   else
   {
      echo "<h2 align=center>Not found</h2>";
   }
         ?>


   </div>
   </form>
   <div id="show"></div>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
   <script>
    
      $(".value").click(function(e){
       // e.preventDefault();
         var value  = $(this).data("id");
          $.ajax({
            url : "insert.php",
            type : "post",
            data :{id : value},
            success:function(data)
            {
            alert(data);
            // $("#show").html(data);
            }
         });  
      });
      
   </script>