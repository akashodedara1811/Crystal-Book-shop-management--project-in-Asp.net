<h1>thank you tu checkout</h1>
<h2>order status :</h2>

<?php
$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from checkout order by id DESC LIMIT 0,1");
while($r = mysqli_fetch_assoc($q))
{
?>
<b>Refrence id:</b> #<?php echo $r['id']; ?>
<br><br><b>Total:</b> <?php echo $r['progtotal']; ?>
<br><br><b>Buyr name:</b> <?php echo $r['Fname']." ".$r['Lname']; ?>
<br><br><b>Email:</b> <?php echo $r['email'] ?><br><br>
<b>Phone:</b> <?php echo $r['phone']; ?>
<br><br><b>Address:</b> <?php echo $r['address']; ?>
<?php
}
?><br><br>
<a href="shop.php">continue New product</a>