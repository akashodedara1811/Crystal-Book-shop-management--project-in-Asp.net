
<?php
session_start();
echo"<form method='post' style='position:relative;margin-top:0px'>";
echo "<table border='2' align='center'>";
echo "<tr>
     <th><input type='checkbox' class='select_all' /></th>
     <th>product Image </th>
     <th>product Id:</th> 
     <th>product Name:</th>
     <th> Choose product Stock </td>
     <th>product price</th>
     <th>product stock</th>
     <th>Delete</th>
     </tr>";
     $print = implode(",",$_SESSION['set']);
     echo "<input type='hidden' name='default' id='defaultval' value='{$print}'>";
    $con = mysqli_connect("localhost","root","root","website");
    $q = mysqli_query($con,"select * from addpro");
    echo "<form method='post'>";
    $i=0;
    while($r=mysqli_fetch_assoc($q)) 
    {
    $id[] = $r['id'];
    } 
    
    $valu = array_count_values($id);
    foreach($id as $i)
    {
    $qu = mysqli_query($con,"select * from product_tbl where id={$i}");
    while($r = mysqli_fetch_assoc($qu))
    {
    $idl[$i] = $i;
    $pname[$i] = $r['pname'];
    $pic[$i] = $r['pic'];
    $re[$i] = $r['price'];
    $rez[$i] = $r['stock'];
    $_SESSION['id'] = array_unique($idl);
    $_SESSSION['name'] = $r['pname'];
    $_SESSION['price'] = $re;
    ?>
    <?php
    $i++;
    } 
    }
$a = 0;
foreach(array_unique($id) as $i)
{
   
   echo "<tr>";
   echo "<td><input type='checkbox'  data-sid='{$i}' name='value' id='check'/></td>";
   echo "<td><img src='Admin/img/$pic[$i]' height='100' width='100'/>";
   echo "<td>{$i}</td>
   <td>{$pname[$i]}</td>";
   echo "<input type='hidden' value='{$i}'class='id'/>";
      echo "<td><input type='number'  data-sid='{$r['price']}' name='value[]' onchange='sub()' value='$valu[$i]'  class='stock'/><input type='hidden' value='{$_SESSION['value'][$a]}' class='fixval'></td>";  
   echo "<td class='price' name ='product-cal'>$re[$i]</td><input type='hidden' class='pr' name='snum' value='$re[$i]'/>";
   $c = $c + $re[$i];
   echo "<td class='quen'>$rez[$i]</td><br><input type='hidden' class='stocks' value='$rez[$i]'/>";
   echo "<td><input type='submit' data-id='$i' value='Delete' class='del'/>";
   echo "</tr>";
   $a++;
}
echo"<tr><td colspan=8 align=center>Total :<spam class='gtotal'>$c</spam></tr>";
?>

<?php
echo"</form>";
echo "</table>";
echo "<input type='submit' data-id='$i' value='Delete only selected item'  class='dele' style='margin-left:50%'/>";
$_SESSION['total'] = $c;
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
   $(".dele").click(function(e)
{
   var data = [];
   $(":checkbox:checked").each(function(key){
             data[key] = $(this).data("sid");
   });
      $.ajax({
        url : "delete_add_to_cart.php",
        type : "post",
        data : {id : data},
        success : function(data)
        {
        // alert(data);
        }
      }); 

});
$(".select_all").click(function(){
   $(":checkbox:checked").each(function(key){
            $("#check").prop("checked",true);
   });
   });
 $(".del").click(function(e)
{
   var val = $(this).data("id");
    $.ajax(
      {
        url : "delete_add_to_cart_row.php",
        type : "post",
        data : {id : val},
        success : function(data)
        {
        // alert(data);
        // alert("data deleted....");
        }
      }); 

}); 

var g = 0;
var total = document.getElementsByClassName("price");
var stock = document.getElementsByClassName("stock");
var fixval = document.getElementsByClassName("fixval");
var quen = document.getElementsByClassName("quen");
var price = document.getElementsByClassName("pr");

for(i=0;i<quen.length;i++)
{
   if(fixval[i].value != "")
   {
   stock[i].value = fixval[i].value;
   }
   g = g + (price[i].value * stock[i].value);
   //quen[i].innerHTML =  Number(stock[i].value)  +  Number(stocks[i].value);
   total[i].innerHTML = price[i].value * stock[i].value;
}
$(".gtotal").html(g);
$(".gtotall").val(g);
function sub()
{
   var q= []
   var g = 0;
var first = 0;
var stocks = document.getElementsByClassName("stocks");
var curent =document.getElementById("currenstock");
var gtotal = 0;
var j =[];
var idl = document.getElementsByClassName("id");
 for(i=0;i<price.length;i++)
{
       total[i].innerHTML = price[i].value * stock[i].value;
    quen[i].innerHTML =  Number(stock[i].value)  +  Number(stocks[i].value);
     gtotal = price[i].value;
       g = g + (price[i].value * stock[i].value); 
      q[i] = stock[i].value;  
  }
defaultval.value = q;
$(".gtotal").html(g);
$(".gtotall").val(g);     
      } 
    </script>  