<?php
session_start();
unset($_SESSION['value']);
$value = $_POST["id"];

print_r( $value);

 $con = mysqli_connect("localhost","root","root","website");

foreach($value as $v)
{
    $qu = mysqli_query($con,"delete from addpro where id IN ('{$v}')"); 
}
if(mysqli_num_rows($qu) > 0)
{
    return 0;
}
else
{
    return 1;
} 
 ?>