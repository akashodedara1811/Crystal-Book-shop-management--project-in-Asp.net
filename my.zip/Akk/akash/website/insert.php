<?php
session_start();
$id = $_POST['id'];
$value = $_SESSION['value'];
$con =mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from addpro where id='{$id}'");
while($r = mysqli_fetch_assoc($q))
{
  $val[] = $r['id'];
}
//print_r(count($val));
//print_r(array_count_values($val));
$start = count($val); //count database value
/* foreach($_SESSION['last'] as $s)
    {
                    
          if($s < 0)
          { 
            echo "add";
            mysqli_query($con,"delete from addpro where id='{$id}'"); 
            for ($i=0; $i <abs($s) ; $i++)
                 { 
                 mysqli_query($con,"insert into addpro(id) values('{$id}')");  
                 }   
              
          }
          else
          {
            for ($i=0; $i <$s ; $i++)
                 { 
                 mysqli_query($con,"insert into addpro(id) values('{$id}')");  
                 }   
            
              }
          }
     

 */
//unset($_SESSION['last']);
$con =mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from product_tbl where id='{$id}'");
$qw =  mysqli_query($con,"select * from addpro where id='{$id}'");

while($r= mysqli_fetch_assoc($q))
{ 
  mysqli_query($con,"insert into addpro(id) values('{$id}')")or die(mysqli_error($con));  
}   
 

?>