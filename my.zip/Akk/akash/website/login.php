<?php
session_start();
$pro = $_GET['c'];
if($_SESSION['user'] == "")
{

?>
<h2 align=center>user login</h2>
<form action="" method="post" align=center>
<input type="text" placeholder="enter username" name="nm"><br>
<input type="password" placeholder="enter passwored" name="pass"><br><br>
<input type="submit" name="s" value="Login now">
</form>

<?php
if(isset($_POST['s']))
{
    
    $nm = trim($_POST['nm']);
    $pass = $_POST['pass'];
    echo "name : ".$nm."<br>";
    echo "passwored : ".$pass."<br>";

    $con = mysqli_connect("localhost","root","root","website");
    mysqli_query($con,"delete from addpro");
    $q = mysqli_query($con,"select * from user_tbl where name='{$nm}' and cpassword='{$pass}'");
    if(mysqli_num_rows($q) > 0)
    {
       echo "login user";
         $_SESSION['user'] = $nm;
        header("location:shop.php?c=$pro"); 
    }   
    else
    {
         echo "please enter valid username and passwored";
    }     
}
}
else
{
    header("location:showpro.php?c=$pro");
}

?>
