<?php
session_start();
unset($_SESSION['set']);
$stock = $_POST['che'];
$total = $_POST['tprice']; 

$_SESSION['value'] = $stock;
if($_SESSION['total'] == "")
{
  $_SESSION['total'] = $_SESSION['defult'];
}
else
{
$_SESSION['total'] = $total;
} 
?>

