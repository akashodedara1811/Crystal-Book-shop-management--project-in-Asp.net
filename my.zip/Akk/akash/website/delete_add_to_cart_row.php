<?php
session_start();
unset($_SESSION['value']);
$value = $_POST["id"];
echo $value;
$con = mysqli_connect("localhost","root","root","website");
$qu = mysqli_query($con,"delete from addpro where id='$value'");
?>