<?php
//get number input value
session_start();
 $get1 = $_POST['set'];
$ending_value = explode(",",$get1);//user input
$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from addpro");
while($r=mysqli_fetch_assoc($q)) 
{
   $id[] = $r['id'];
} 
print_r($id);
$_SESSION['end'] = $ending_value;
print_r($_SESSION['end']);
$valu = array_count_values($id);//fixed value
   $i =0;
  foreach ($ending_value  as $e) {
   if($ending_value[$i]== "")
   {
       $_SESSION['value'] =  $valu;
   $i++;
   }
}
$count = array_map("sub",$ending_value,$valu);
$_SESSION['last'] = $count; 
function sub($a,$b)
{
   return $a-$b;
}
?>