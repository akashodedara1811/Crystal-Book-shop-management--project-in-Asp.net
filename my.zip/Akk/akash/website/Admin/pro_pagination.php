<?php
$limit = $_GET['page'];
echo "<form method='post'>";
echo "<table border=2 align=Center>";
echo "<tr>
  <th>select</th>
  <th>Id</th>
  <th>product name</th>
  <th>product description</th>
  <th>category name</th>
  <th>sub category name</th>
  <th>product price</th>
  <th>product pic</th>
  <th>Edit</th>
  <th>Delete</th>
</tr>";

$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from product_tbl limit 0,{$limit}");
while($r = mysqli_fetch_assoc($q))
{
    echo "<tr><td align='center'><input type='checkbox' name='checked[]' Value='{$r["id"]}'/></td>";
    echo "<td align='center'>{$r["id"]}</td>";
    echo "<td align='center'>{$r["pname"]}</td>";
    echo "<td align='center'>{$r["des"]}</td>";
    echo "<td align='center'>{$r["cname"]}</td>";
    echo "<td align='center'>{$r["scname"]}</td>";
    echo "<td align='center'>{$r["price"]}</td>";
   echo "<td><img src='img/{$r["pic"]}' width=100 height=100/></td>";
   echo "<td><input type='submit' class='e2' value='Edit' name='up' data-uid='{$r["id"]}'/></td>";
   echo "<td><input type='submit' class='d2'value='Delete' data-did='{$r["id"]}'/></td>";
}
echo "</table>";
echo "<input type='submit' id='delete' value='delete'  style='margin-left:50%;margin-top:3%;background-color:red'/>";
echo "<input type='submit' id='deleteAll' value='delete All' style='background-color:red' name='de'/>";
echo "</form>";

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
  
    $("#delete").click(function(e){
     
      var val = [];
         $(':checkbox:checked').each(function(i){
               val[i] = $(this).val();     
               
            });
            alert(val);
     $.ajax({
          url : "udel.php",
          type: "post",
          data : {id : val},
          success:function(data)
          {
            if(data == 0)
            {
            alert('data deleted...');
            }
            else
            {
              alert("data return an error...");
            }
          }
      }); 
    });
  $(".d2").click(function(e){
     
      var val = $(this).data("did");
      alert(val);
       $.ajax({
          url : "udel2.php",
           type: "post",
          data : {id : val},
          success:function(data)
          {
            if(data == 0)
            {
            alert('data deleted...');
            }
            else
            {
              alert("data return an error...");
            }
          }
      }); 
    }); 
    $(".e2").click(function(e){
        e.preventDefault();
        var val = $(this).data("uid");
        $(location).prop('href', "update_pro.php?u="+val);//this is used to rediredt the page
      });

  $(".search").keyup(function(){
        var val = $(this).val();
        $.ajax({
          url : "live_pro_search.php",
           type: "post",
          data : {id : val},
          success:function(data)
          {
            $("#value").html(data);
          }  
      });
  });
    </script>
    <?php
    if(isset($_POST['deleteAll']))
    {
  header("location:udelall.php");
    }