<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<?php
$val = $_POST['value'];

     $con = mysqli_connect("localhost","root","root","website");
     $q = mysqli_query($con,"select csname from category_tbl where cname='{$val}'");

      $i = 0;

     $out = "<form type='post'>";
     while($r=mysqli_fetch_assoc($q))
     {
      $out.="<input type='checkbox'  class='scat' name='sbcat' value='{$r['csname']}' onchange='tested(this.value)'/>{$r['csname']}<br>";
     } 
    $out.="</form>";
     echo $out;
     
?>
<script>
     function tested(val)
       {
        var val = [];
         $('.scat:checked').each(function(i){
               val[i] = $(this).val();     
            });
            $("#input").val(val);
            $(".category").val(val);  

         }  
</script>
   