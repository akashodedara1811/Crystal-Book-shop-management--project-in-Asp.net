<?php
session_start();
if($_SESSION['Admin'] == "")
{
 header("location:index.php");
}
else
{
?>
<h2 align=center> Add category</h2>
<table align=center>
<form method="post" enctype="multipart/form-data">
     
    <tr><td>Enter Category:</td><td><input type="text" placeholder="enter Category Name:" name="nm" require></td></tr>
    <tr><td>Enter Sub-category :</td><td><input type="text" placeholder="enter sub-Category Name" name="csname" ></td></tr>
    <tr><td>category Pic :</td><td><input type="file" name="cpic"></td></tr>
    <tr><td></td><td><input type="submit" name="s" value="Add category"></td></tr>
</form>
</table>
<a href="dashboard.php">Back</a>
<?php
}
if(isset($_FILES['cpic']))
{
    if(isset($_POST['s']))
    {
     
    $cname = $_POST['nm'];
    $csname = $_POST['csname'];
    $pictmp = $_FILES['cpic']['tmp_name'];
    $picname = $_FILES['cpic']['name']; 
            $con = mysqli_connect("localhost","root","root","website");
            $q =
            move_uploaded_file($pictmp,"img/".$picname);
            $source = imagecreatefromjpeg('img/'.$picname);
            list($width, $height) = getimagesize('img/'.$picname);
            $newWidth = 300;
            $newHeight = 300;
            $thumb = imagecreatetruecolor($newWidth, $newHeight);
            imagecopyresized($thumb, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
            imagejpeg($thumb, 'img/thumb/'.$picname, 100);
            $q = mysqli_query($con,"insert into category_tbl(cname,csname,pic) values('{$cname}','{$csname}','{$picname}')");
            echo "new data inserted...";
    }
}
?>