<?php
$val = $_POST['valu'];

$value = implode(",",$val);
echo $val;
$con = mysqli_connect("localhost","root","root","website");
mysqli_query($con,"insert into product_tbl(scname) values('{$value}')");
 
?>