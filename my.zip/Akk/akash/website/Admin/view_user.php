<?php
$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from user_tbl");
echo "<table border=2 align=center>";
echo "<tr>
    <th>Id</th>
    <th>user name</th>
    <th>user passwored</th>
    <th>email</th>
    <th>gender</th>
    <th>hobby</th>
    <th>image</th>
    <th>category</th>
    <th> selected product id</th></tr>";
while($r = mysqli_fetch_assoc($q))
{
    echo "<tr>
    <td>{$r['id']}</td>
    <td>{$r['name']}</td>
    <td>{$r['cpassword']}</td>
    <td>{$r['email']}</td>
    <td>{$r['gender']}</td>
    <td>{$r['hobby']}</td>
    <td><img src='img/{$r['pic']}' width='100px' height='100px'/></td>
    <td>{$r['product']}</td>
    <td>{$r['productname']}</td>
    </tr>";
}
echo "</table>";
echo "<a href='index.php'>Back</a>";
?>