<?php
session_start();
if($_SESSION['Admin'] =="")
{
 header("location:index.php");
}
else
{
?>
<h2>Hello Admin : <?php echo $_SESSION['Admin']; ?></h2>
<?php
 $con = mysqli_connect("localhost","root","root","website");
 $q = mysqli_query($con,"select pic from admin_tbl where name='{$_SESSION['Admin']}'");
 while($r = mysqli_fetch_assoc($q))
 {
    echo "<img src='img/{$r['pic']}' width='100' height='100' align=center>";
 }
?>
<br><br>
<form action="" method="post" enctype='multipart/form-data'>
   <input type="file" name="file">
   <input type="submit" value="Import Now" name='Import'>
</form>
<br><br>
<a href="Add_new_user.php">Add New user</a>&nbsp;&nbsp;&nbsp;
<a href="Add_category.php">Add New category</a>&nbsp;&nbsp;&nbsp;
<a href="Add_product.php">Add New product</a>&nbsp;&nbsp;&nbsp;
<a href="view_cat.php">View category</a>&nbsp;&nbsp;&nbsp;
<a href="order.php">orderes</a>&nbsp;&nbsp;&nbsp;
<a href="view_pro.php">View product</a>&nbsp;&nbsp;&nbsp;
<a href="view_user.php">View user</a>&nbsp;&nbsp;&nbsp;
<a href="add_offer.php">set offer</a>&nbsp;&nbsp;&nbsp;
<a href="logout.php">Logout</a>&nbsp;&nbsp;&nbsp;
<br><br><br>
<?php
}
$i = 0;
if(isset($_POST["Import"])){
		
   $filename=$_FILES["file"]["tmp_name"];		


    if($_FILES["file"]["size"] > 0)
    {
        $file = fopen($filename, "r");
        while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
         {
            
         if($i == 0)
         {
            $i++;
            continue;
         }
         else
         {
            $con = mysqli_connect("localhost","root","root","website");
          
               $q = "insert into product_tbl(pname,sdes,cname,scname,price,stock,pic,des) values ('{$getData[1]}','{$getData[2]}','{$getData[3]}','{$getData[4]}','{$getData[5]}','{$getData[6]}','{$getData[7]}','{$getData[8]}')";
               mysqli_query($con,$q);
            
            
         // echo $getData[0]."&nbsp;&nbsp;".$getData[1]."&nbsp;&nbsp;".$getData[2]."&nbsp;&nbsp;".$getData[3]."&nbsp;&nbsp;".$getData[4]."&nbsp;&nbsp;".$getData[5]."&nbsp;&nbsp;".$getData[6]."&nbsp;&nbsp;".$getData[7]."&nbsp;&nbsp;".$getData[8]."<br>";
         }
         }
      
         fclose($file);	
    }
}	 
print_r($name);
?>