<input type="hidden" name="" class="page"><br>
<center><input type='text' placeholder='please enter value..' class='search'  /></center><br><br>
<center><select name='cname' id="cname" onchange="change(this.value)"></center><br><br>
    <option>select category</option>
   <?php
     $con = mysqli_connect("localhost","root","root","website");
     $qs = "select cname from category_tbl";
     $q = mysqli_query($con,"select count(id), cname from category_tbl group by cname;");
     while($r=mysqli_fetch_assoc($q))
     {
        echo "<option value='{$r['cname']}'>{$r['cname']}</option>";
     }
     
    ?>
    <select>
    <select onchange="page1(this.value)" class="option">
         <option value="2">2</option>
         <option value="4">4</option>
         <option value="50">50</option>
         <option value="100">100</option>
   </select>
<div id="value"></div>
<a href="dashboard.php">Back</a>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
    var name = "";
      const searchParams = new URLSearchParams(window.location.search);
      for (const param of searchParams) {
       console.log(param[0]);
       name = param[1];
       }
       $(".page").val(name);

   function change(val)
       {
        var valu = $("#cname").val();
        var page = $(".page").val();
        
         $.ajax({
            url : "get_sub_cate_use_searching.php",
            type : "post",
            data: {value:valu, p:page},
            success:function(data)
            {
               $("#value").html(data);
            }
        }); 
       } 
       var page = $(".page").val();
       $.ajax({
          url : "view_all_cat.php",
           type: "post",
           data : {p : page},
          success:function(data)
          {
            $("#value").html(data);
          }  
      });
      function page1(val){
            var t = $(".option").val();
          $(document).ready(function(){

            $.ajax({
              url : "view_all_cat.php",
               type: "post",
               data : {id : t},
             success:function(data)
            {
              $("#value").html(data);
            }  
           });
          });
          }
      </script>
      
     