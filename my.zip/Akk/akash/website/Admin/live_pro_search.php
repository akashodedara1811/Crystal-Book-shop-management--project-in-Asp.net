<?php
$val = $_POST['id'];
echo "<form method='post'>";
echo "<table border=2 align=Center>";
echo "<tr>
  <th>select</th>
  <th>Id</th>
  <th>product name</th>
  <th>product description</th>
  <th>category name</th>
  <th>sub category name</th>
  <th>product price</th>
  <th>product pic</th>
  <th>Edit</th>
  <th>Delete</th>
</tr>";

$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"SELECT * FROM product_tbl where cname like '%{$val}%' OR scname like '%{$val}%' OR des like '%{$val}%' OR sdes like '%{$val}%' OR  pname like '%{$val}%'");
while($r = mysqli_fetch_assoc($q))
{
    echo "<tr><td align='center'><input type='checkbox' name='checked[]' Value='{$r["id"]}'/></td>";
    echo "<td align='center'>{$r["id"]}</td>";
    echo "<td align='center'>{$r["pname"]}</td>";
    echo "<td align='center'>{$r["des"]}</td>";
    echo "<td align='center'>{$r["cname"]}</td>";
    echo "<td align='center'>{$r["scname"]}</td>";
    echo "<td align='center'>{$r["price"]}</td>";
   echo "<td><img src='img/{$r["pic"]}' width=100 height=100/></td>";
   echo "<td><input type='submit' class='e2' value='Edit' name='up' data-uid='{$r["id"]}'/></td>";
   echo "<td><input type='submit' class='d2'value='Delete' data-did='{$r["id"]}'/></td>";
}
echo "</table>";
echo "<input type='submit' id='delete' value='delete'  style='margin-left:50%;margin-top:3%;background-color:red'/>";
echo "<input type='submit' id='deleteAll' value='delete All' style='background-color:red' name='de'/>";
echo "</form>";

?>