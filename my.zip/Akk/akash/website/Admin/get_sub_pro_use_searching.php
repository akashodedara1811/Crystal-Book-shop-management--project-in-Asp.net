<?php
$val = $_POST['value'];


     $con = mysqli_connect("localhost","root","root","website");
     $q = mysqli_query($con,"select * from product_tbl where cname='{$val}'");
      echo "<form method='post'>";
echo "<table border=2 align=Center>";
echo "<tr>
  <th>select</th>
  <th>Id</th>
  <th>cname</th>
  <th>csname</th>
  <th>Pic</th>
  <th>Edit</th>
  <th>Delete</th>
</tr>";
     while($r=mysqli_fetch_assoc($q))
     {
        echo "<tr><td align='center'><input type='checkbox' name='checked[]' Value='{$r["id"]}'/></td>";
        echo "<td align='center'>{$r["id"]}</td>";
        echo "<td align='center'>{$r["pname"]}</td>";
        echo "<td align='center'>{$r["des"]}</td>";
        echo "<td align='center'>{$r["cname"]}</td>";
        echo "<td align='center'>{$r["scname"]}</td>";
        echo "<td align='center'>{$r["price"]}</td>";
       echo "<td><img src='img/{$r["pic"]}' width=100 height=100/></td>";
       echo "<td><input type='submit' class='e2' value='Edit' name='up' data-uid='{$r["id"]}'/></td>";
       echo "<td><input type='submit' class='d2'value='Delete' data-did='{$r["id"]}'/></td>";
     } 
   echo "</table>";
   echo "<input type='submit' id='delete' value='delete Selected value' style='margin-left:40%;margin-top:3%;background-color:red'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
   echo "<input type='submit' name='deleteAll' id='deleteAll' value='delete All' style='background-color:red' name='de'/>";
   echo "</form>";
     
?>