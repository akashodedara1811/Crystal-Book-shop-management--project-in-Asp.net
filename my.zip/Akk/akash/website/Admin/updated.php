<?php
$val = $_GET['u'];
$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from category_tbl where id={$val}");
while($r = mysqli_fetch_assoc($q))
{
?>

<h2 align=center> Edit category</h2>
<table align=center>
<form method="post" enctype="multipart/form-data">
<tr><td><input type="hidden" name="id" value="<?php echo $val; ?>"> </td></tr>
    <tr><td>Enter Category:</td><td><input type="text" placeholder="enter Category Name:" name="nm" value="<?php echo $r['cname']; ?>" require></td></tr>
    <tr><td>Enter Sub-category :</td><td><input type="text" placeholder="enter sub-Category Name" name="csname" value="<?php echo $r['csname']; ?>"></td></tr>
    <tr><td></td><td><img src="img/<?php echo $r['pic']; ?>" width=100 height=100/></td></tr>
    <tr><td>category Pic :</td><td><input type="file" name="cpic" ></td>
    <tr><td></td><td><input type="submit" name="s" value="Add category"></td></tr>
    
</form>
</table>
<a href="dashboard.php">Back</a>
<?php
break;
}

if(isset($_FILES['cpic']))
{
    if(isset($_POST['s']))
    {
     $id = $_POST['id'];
    $cname = $_POST['nm'];
    $csname = $_POST['csname'];
    $pictmp = $_FILES['cpic']['tmp_name'];
    $picname = $_FILES['cpic']['name']; 
           $con = mysqli_connect("localhost","root","root","website");
            move_uploaded_file($pictmp,"img/".$picname);
            if($picname == "")
            {
                $q = mysqli_query($con,"update category_tbl set cname='{$cname}',csname='{$csname}' where id='{$id}'");
            header("location:view_cat.php");
            }
            else
            {
                $q = mysqli_query($con,"update category_tbl set cname='{$cname}',csname='{$csname}',pic= '{$picname}' where id='{$id}'");
            header("location:view_cat.php");
            }
            
    }
}
?>