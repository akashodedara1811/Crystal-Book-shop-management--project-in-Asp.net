<?php
$con = mysqli_connect("localhost","root","root","website");
$q = "select * from product_tbl";
$qu = mysqli_query($con,$q);

?>
<table>
<form action="" method="post" align=center>
    <tr><td>Enter Offer:</td><td><input type="text" name="off" placeholder="Enter offer value" ></td></tr>
    <tr><td>Enter cupone code:</td><td><input type="text" name="cupen" placeholder="Enter coupen code" ></td></tr>
    <?php
      echo "<tr><td>Select Customer:</td><td>";
    while($r = mysqli_fetch_assoc($qu))
    {
      
        echo "<input type='checkbox' value='{$r['pname']}' name='check[]'/>{$r['pname']}<br>";
        
    }
    echo "</td></tr>";
    ?>
    <br>
    <tr><td></td><td><input type="submit" value="Set Offer" name='s'></td></tr>
</form>
</table>

<?php
if(isset($_POST['s']))
{
  $offer = $_POST['off'];
  $cupen = $_POST['cupen'];
  $cust = $_POST['check'];
  $customer=implode(",",$cust);
  $con = mysqli_connect("localhost","root","root","website");
  $q = "insert into offer(offer,coupen,customer) values('{$offer}','{$cupen}','{$customer}')";
  $qu = mysqli_query($con,$q);
}
?>
<a href="dashboard.php">back</a>