<?php
session_start();
if($_SESSION['Admin'] == "")
{
 header("location:index.php");
}
else
{
?>
<h2 align=center> Register page</h2>
<table align=center>
<form method="post" enctype="multipart/form-data" id='test'>
     
    <tr><td>Name :</td><td><input type="text" placeholder="enter Name:" class="name" name="nm" required></td></tr>
    <tr><td>passwored :</td><td><input type="password" placeholder="enter passwored" name="pass" id="pass"></td></tr>
    <tr><td>confirm passwored :</td><td><input type="password" placeholder="enter confirm passwored" name="cpass" id="cpass"></td></tr>
    <tr><td>Email :</td><td><input type="email" placeholder="enter email" name="em" id="email"></td></tr>
    <tr><td>Gender:</td><td><input type="radio" name="gender" value="Male">Male<input type="radio" name="gender" value="Female">Female</td></tr>
     <tr><td>Hobby:</td><td><input type="checkbox" name="hob[]" value="Reading" class="hob">Reading</td></tr>
    <tr><td></td><td><input type="checkbox" name="hob[]" value="Playing" class="hob">Playing</td></tr>
    <tr><td></td><td><input type="checkbox" name="hob[]" value="Traveling" class="hob">Traveling</td></tr>
    <tr><td>product category:</td><td><select class='test' name='cat'  id="cname" onchange="change(this.value)"><option value="">select category</option>
    <?php
     $con = mysqli_connect("localhost","root","root","website");
     $qs = "select cname from category_tbl";
     $q = mysqli_query($con,"select count(id), cname from category_tbl group by cname;");
     while($r=mysqli_fetch_assoc($q))
     {
        echo "<option value='{$r['cname']}'>{$r['cname']}</option>";
     }
     
    ?>
    </select></td></tr>
    <tr><td>sub - Category name:</td><td><div id="value"></div></td></tr>
    <input type="hidden" class='category' name='sbcat'>
    <tr><td></td><td><input type="file" name="uploade" class=""></td></tr>
    <tr><td></td></tr><td></td><td><input type="submit" name="s" value="Register Now" id="red"></td><tr><td></td></tr>
</form>
</table>
<?php
}
if(isset($_FILES['uploade']))
{
    if(isset($_POST['s']))
    {
       
    $nm = $_POST['nm'];
    $pass = md5($_POST['pass']);
    $ccpass =md5($_POST['cpass']);
    $cpass = $_POST['cpass'];
    $email=$_POST['em'];
    $gen = $_POST['gender'];
    $hob = $_POST['hob'];
    $hobby = implode(",",$hob);
    $filetemp = $_FILES['uploade']['tmp_name'];
    $filename = $_FILES['uploade']['name'];
    $sbcat =$_POST['sbcat'];
    $cat = $_POST['cat'];
    if($ccpass == $pass || $pass == $ccpass)
    {
        echo $nm;
         move_uploaded_file($filetemp,"img/".$filename);
        $con = mysqli_connect("localhost","root","root","website");
        mysqli_query($con,"insert into user_tbl(name,password,cpassword,email,gender,hobby,pic,productname,product) values('{$nm}','{$pass}','{$cpass}','{$email}','{$gen}','{$hobby}','{$filename}','{$sbcat}','{$cat}')");
        echo"data inserted ...";  
     }
    else
    {
        echo "Both passwored are not same...";
    }
    }
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
     function change(val)
       {
        var valu = $("#cname").val();
       $.ajax({
            url : "get_sub_pro.php",
            type : "post",
            data: {value:valu},
            success:function(data)
            {
              
               $("#value").html(data);
            }
        }); 
       }
 
 </script>
<a href="dashboard.php">Back</a>
<!--jami ne product category get krava ni pachhi product get karvani-->