<?php
$con = mysqli_connect("localhost","root","root","website");
?>