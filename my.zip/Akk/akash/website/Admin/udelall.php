<?php
$value = $_POST["id"];
 $con = mysqli_connect("localhost","root","root","website");
 $qu = mysqli_query($con,"delete from product_tbl"); 
header("location:view_cat.php");
 ?>
 