<?php
$id = $_GET['id'];
$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from checkout where id='{$id}'"); 
$i=0;
while($r = mysqli_fetch_assoc($q))
{
    $product_id = explode(",",$r['proid']);
    $product_item = explode(",",$r['proitems']);
    $total = $r['progtotal'];
    $off = $r['off'];
    $i++;
}
echo "<table border=2 align=center>";
echo "<tr>
         <td>Id</td>
         <td>Product Name</td>
         <td>Product category</td>
         <td>Product original price</td>
         <td>product quntity</td>
         <td>product Total price</td>
         <td>product grand total</td>
         <td>Offer</td>
         <td>product status</td>
         <td>product image</td>
 </tr>";
 $i=0;
 foreach($product_id as $pid)
 {
    echo "<tr>";   
    $qu = mysqli_query($con,"select * from product_tbl where {$pid}");
    while($r = mysqli_fetch_assoc($qu))
    {
        if($r['id'] == $pid)
        {
            echo "<td>{$pid}</td>";
            echo "<td>{$r['pname']}</td>";
            echo "<td>{$r['cname']}</td>";
            echo "<td>{$r['price']}</td>"; 
            echo "<td>{$product_item[$i]}</td>";
            $pr[$i] = $r['price'] * $product_item[$i];
            echo "<td>{$pr[$i]}</td>";
            echo "<td>{$total}</td>";
            if($off == "")
            {
                    echo "<td>No offer get</td>";
            }
            else
            {
            echo "<td>{$off}</td>";
             }
            echo "<td>Pending</td>";
            echo "<td><img src='img/{$r['pic']}' width=100 height=100/></td>";
           
        }
    }
    echo "</tr>";  
    $i++;
 }
echo "</table>"; 
?>
