<?php
$day =$_POST['day'];
$con = mysqli_connect("localhost","root","root","website");
echo "<table border=2 align=center>";
echo "<tr>
         <td>Id</td>
         <td>Name</td>
         <td>Email</td>
         <td>Phone</td>
         <td>address</td>
         <td>Date</td>
         <td>Details</td>
 </tr>";

$q = mysqli_query($con,"select * from checkout where date like '%$day%' order by Fname asc");
while($r = mysqli_fetch_assoc($q))
{
    echo "<tr>";
    echo "<td>{$r['id']}</td>";
    echo "<td>{$r['Fname']} {$r['Lname']}</td>";
    echo "<td>{$r['email']}</td>";
    echo "<td>{$r['phone']}</td>";
    echo "<td>{$r['address']}</td>";
    echo "<td>{$r['date']}</td>";
    echo "<td><a href='viewproduct.php?id={$r[id]}'> View details </a></td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";
?>