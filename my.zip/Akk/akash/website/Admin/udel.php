
<?php
$value = $_POST["id"];
 $con = mysqli_connect("localhost","root","root","website");

foreach($value as $v)
{
    $qu = mysqli_query($con,"delete from product_tbl where id IN ('{$v}')"); 
}
if(mysqli_num_rows($qu) > 0)
{
    return 0;
}
else
{
    return 1;
}
 ?>