<?php
session_start();
?>
<h2 align=center>Login </h2>
<form action="" method="post" align=center>
    <input type="text" placeholder="enter username" name="nm"><br>
    <input type="password" placeholder="enter passwored" name="pass"><br><br>
    <input type="submit" name="s" value="Login now">
</form>

<?php
if($_SESSION["Admin"]!="")
{
  header("location:dashboard.php");
}
else
{
if(isset($_POST['s']))
{
    $name = $_POST['nm'];
    $pass = $_POST['pass'];
    $con = mysqli_connect("localhost","root","root","website");
    $q = mysqli_query($con,"select * from admin_tbl where name='{$name}' and cpassword={$pass}");
    if(mysqli_num_rows($q) > 0)
    {
    $_SESSION['Admin'] = $_POST['nm'];
    header("location:dashboard.php");
    }
    else
    {
    echo "please enter valide username and passwored";
    }
}
}
?>
