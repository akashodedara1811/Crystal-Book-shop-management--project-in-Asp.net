<?php
session_start();
if($_SESSION['Admin'] == "")
{
 header("location:index.php");
}
else
{
?>
<script src="https://cdn.ckeditor.com/4.19.1/standard/ckeditor.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<h2 align=center> Add Product</h2>
<table align=center>
<form method="post" enctype="multipart/form-data">
     
    <tr><td>Enter Product:</td><td><input type="text" placeholder="enter product Name:" name="nm" class="nm" require></td></tr>
    <tr><td>Enter Description :</td><td><textarea name="des" cols="30" rows="10" class="des"></textarea></td></tr>
    <tr><td>Enter Sub-Description:</td><td><input type="text" placeholder="enter product sub-description Name:" name="sdes" require></td></tr>
    <tr><td>Category name:</td><td><select name='cname' id="cname" onchange="change(this.value)">
    <option>select category</option>
   <?php
     $con = mysqli_connect("localhost","root","root","website");
     $qs = "select cname from category_tbl";
     $q = mysqli_query($con,"select count(id), cname from category_tbl group by cname;");
     while($r=mysqli_fetch_assoc($q))
     {
        echo "<option value='{$r['cname']}'>{$r['cname']}</option>";
     }
     
    ?>
    <select></td></tr>
    <tr><td>sub - Category name:</td><td><div id="value"></div></td></tr>
    <tr><td>Enter Product price:</td><td><input type="text" placeholder="enter product price:" name="price"  require></td></tr>
    <tr><td>Enter Product Stock:</td><td><input type="text" placeholder="enter product stock:" class="stock" name="stock" require></td></tr>
    <tr><td></td><td><input type="file" name="uploade" require></td></tr>
    <tr><td></td><td><input type="submit" id="s" name="s" value="Add Product"></td></tr>
    <input type="hidden" id="input" value="" name="sb"/>
</form>
</table>
<?php
}
  if(isset($_POST['s']))
{
$des = $_POST['des'];
$nm = $_POST['nm'];
$sdes=$_POST['sdes'];
$cname = $_POST['cname'];
$scat = $_POST['sb'];
$price = $_POST['price'];
$stock = $_POST['stock'];
$protmp = $_FILES['uploade']['tmp_name'];
$proname = $_FILES['uploade']['name']; 

 $con = mysqli_connect("localhost","root","root","website");
 move_uploaded_file($protmp,"img/".$proname);
$source = imagecreatefromjpeg('img/'.$proname);
list($width, $height) = getimagesize('img/'.$proname);
$newWidth = 300;
$newHeight = 300;
$thumb = imagecreatetruecolor($newWidth, $newHeight);
imagecopyresized($thumb, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
imagejpeg($thumb, 'img/thumb/'.$proname, 100);
       $q = "insert into product_tbl(pname,des,sdes,cname,scname,price,stock,pic) values ('{$nm}','{$des}','{$sdes}','{$cname}','{$scat}','{$price}','{$stock}','{$proname}')";
        mysqli_query($con,$q);
        echo "product inserted.....";  
}

?>
<script>
   CKEDITOR.replace('des');
       function change(val)
       {
        var valu = $("#cname").val();
         $.ajax({
            url : "get_sub_cate.php",
            type : "post",
            data: {value:valu},
            success:function(data)
            {
              
               $("#value").html(data);
            }
        }); 
       }
               
</script>
<br><br>
<a href="dashboard.php">back</a>

