<?php
$limit = $_GET['page'];
echo $limit;
echo "<form method='post'>";
echo "<table border=2 align=Center>";
echo "<tr>
  <th>select</th>
  <th>Id</th>
  <th>cname</th>
  <th>csname</th>
  <th>Pic</th>
  <th>Edit</th>
  <th>Delete</th>
</tr>";
$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from category_tbl limit 0,2");
while($r = mysqli_fetch_assoc($q))
{
  echo "<tr><td align='center'><input type='checkbox' name='checked[]' Value='{$r["id"]}' id='val'/></td><td>{$r["id"]}</td>";
     echo "<td align='center'>{$r["cname"]}</td>";
    echo "<td align='center'>{$r["csname"]}</td>";
   echo "<td><img src='img/{$r["pic"]}' width=100 height=100/></td>";
   echo "<td><input type='submit' class='e2' value='Edit' name='up' data-uid='{$r["id"]}'/></td>";
   echo "<td><input type='submit' class='d2'value='Delete' data-did='{$r["id"]}'/></td>";
}
echo "</table>";
echo "<input type='submit' id='delete' value='delete Selected value' style='margin-left:5%;margin-top:3%;background-color:red'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<input type='submit' name='deleteAll' id='deleteAll' value='delete All' style='background-color:red' name='de'/>";
echo "</form>";

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
  $(document).ready(function(){
    $("#delete").click(function(e){
    //e.preventDefault();
      var val = [];
         $(':checkbox:checked').each(function(i){
               val[i] = $(this).val();     
               
            });
            alert(val);
      $.ajax({
          url : "del.php",
          type: "post",
          data : {id : val},
          success:function(data)
          {
            if(data == 0)
            {
            alert('data deleted...');
            }
            else
            {
              alert("data return an error...");
            }
          }
      });  
    });

     
    $(".d2").click(function(e){
     // e.preventDefault();
      var val = $(this).data("did");
      alert(val);
       $.ajax({
          url : "del2.php",
           type: "post",
          data : {id : val},
          success:function(data)
          {
            if(data == 0)
            {
            alert('data deleted...');
            }
            else
            {
              alert("data return an error...");
            }
          }
      }); 
    }); 
      $(".e2").click(function(e){
       e.preventDefault();
        var val = $(this).data("uid");
        $(location).prop('href', "updated.php?u="+val);
      });

      $(".search").keyup(function(){
        var val = $(this).val();
        $.ajax({
          url : "live_cat_search.php",
           type: "post",
          data : {id : val},
          success:function(data)
          {
            $("#value").html(data);
          }  
      });
  });
});
</script>
<?php
if(isset($_POST['deleteAll']))
{
  header("location:delall.php");
}

?>