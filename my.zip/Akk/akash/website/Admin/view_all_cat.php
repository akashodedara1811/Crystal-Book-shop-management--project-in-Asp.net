<?php
  $limit = 2;
  $value = $_POST['id'];
$pagee = $_POST["p"];
if($pagee == "")
{
  $pagee = 2;
}
else
{
  $pagee = $_POST["p"];
}
$offset = $limit * ($pagee - 1);
echo "<form method='post'>";
echo "<table border=2 align=Center>";
echo "<tr>
  <th>select</th>
  <th>Id</th>
  <th>cname</th>
  <th>csname</th>
  <th>Pic</th>
  <th>Edit</th>
  <th>Delete</th>
</tr>";
if($value != "")
{
  $con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from category_tbl limit 0,{$value}");
while($r = mysqli_fetch_assoc($q))
{
  echo "<tr><td align='center'><input type='checkbox' name='checked[]' Value='{$r["id"]}' id='val'/></td><td>{$r["id"]}</td>";
     echo "<td align='center'>{$r["cname"]}</td>";
    echo "<td align='center'>{$r["csname"]}</td>";
   echo "<td><img src='img/{$r["pic"]}' width=100 height=100/></td>";
   echo "<td><input type='submit' class='e2' value='Edit' name='up' data-uid='{$r["id"]}'/></td>";
   echo "<td><input type='submit' class='d2'value='Delete' data-did='{$r["id"]}'/></td>";
}
echo "</table>";
echo "<input type='submit' id='delete' value='delete Selected value' style='margin-left:40%;margin-top:3%;background-color:red'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<input type='submit' name='deleteAll' id='deleteAll' value='delete All' style='background-color:red' name='de'/>";
echo "</form>";


$q = mysqli_query($con,"select * from category_tbl");
$total = mysqli_num_rows($q);
$cal = ceil($total / $value);
echo "<center>";
echo "<a href='view_cat.php?page={$pagee}'>NEXT</a>";
for($i = 1;$i<=$cal;$i++)
{
  
  if($i == 1)
  {

  }
   echo "<a href='view_cat.php?page={$i}'>{$i}</a>";
   echo "&nbsp;&nbsp;&nbsp;"; 
}
echo "<center><br>";
echo "change value : <input type='text' style='Width:2%' class='pagechange' placeholder='{$pagee}/{$cal}' onkeyup='pagechange(this.value)'/>";

}
else
{
$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from category_tbl limit {$offset},{$limit}");
while($r = mysqli_fetch_assoc($q))
{
  echo "<tr><td align='center'><input type='checkbox' name='checked[]' Value='{$r["id"]}' id='val'/></td><td>{$r["id"]}</td>";
     echo "<td align='center'>{$r["cname"]}</td>";
    echo "<td align='center'>{$r["csname"]}</td>";
   echo "<td><img src='img/{$r["pic"]}' width=100 height=100/></td>";
   echo "<td><input type='submit' class='e2' value='Edit' name='up' data-uid='{$r["id"]}'/></td>";
   echo "<td><input type='submit' class='d2'value='Delete' data-did='{$r["id"]}'/></td>";
}
echo "</table>";
echo "<input type='submit' id='delete' value='delete Selected value' style='margin-left:40%;margin-top:3%;background-color:red'/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
echo "<input type='submit' name='deleteAll' id='deleteAll' value='delete All' style='background-color:red' name='de'/>";
echo "</form>";


$q = mysqli_query($con,"select * from category_tbl");
$total = mysqli_num_rows($q);
$cal = ceil($total / $limit);
echo "<center>";
$next = $pagee + 1;
$pre = $pagee - 1;
if($next <= $cal)
{
echo "<a href='view_cat.php?page={$next}'>previes</a>&nbsp;";
}
for($i = 1;$i<=$cal;$i++)
{
   echo "<a href='view_cat.php?page={$i}'>{$i}</a>";
   echo "&nbsp;&nbsp;&nbsp;"; 
}
if($next >= $cal)
{
  echo "<a href='view_cat.php?page={$pre}'>next</a>&nbsp;";
}
echo "<center><br>";
echo "change value : <input type='text' style='Width:2%' class='pagechange' placeholder='{$pagee}/{$cal}' onkeyup='pagechange(this.value)'/>";
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
  function pagechange(n)
    {
      var p = $(".pagechange").val();
      $(location).prop('href', "view_cat.php?page="+p);
    }
  $(document).ready(function(){
    $("#delete").click(function(e){
    //e.preventDefault();
      var val = [];
         $(':checkbox:checked').each(function(i){
               val[i] = $(this).val();     
               
            });
            alert(val);
      $.ajax({
          url : "del.php",
          type: "post",
          data : {id : val},
          success:function(data)
          {
            if(data == 0)
            {
            alert('data deleted...');
            }
            else
            {
              alert("data return an error...");
            }
          }
      });  
    });

     
    $(".d2").click(function(e){
     // e.preventDefault();
      var val = $(this).data("did");
      alert(val);
       $.ajax({
          url : "del2.php",
           type: "post",
          data : {id : val},
          success:function(data)
          {
            if(data == 0)
            {
            alert('data deleted...');
            }
            else
            {
              alert("data return an error...");
            }
          }
      }); 
    }); 
      $(".e2").click(function(e){
       e.preventDefault();
        var val = $(this).data("uid");
        $(location).prop('href', "updated.php?u="+val);
      });

      $(".search").keyup(function(){
        var val = $(this).val();
        $.ajax({
          url : "live_cat_search.php",
           type: "post",
          data : {id : val},
          success:function(data)
          {
            $("#value").html(data);
          }  
      });
  });
});
</script>
<?php
if(isset($_POST['deleteAll']))
{
  header("location:delall.php");
}

?>