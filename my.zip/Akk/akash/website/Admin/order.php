<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<?php
$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select count(*),date from checkout group by date");
$out = array();
while($r = mysqli_fetch_assoc($q))
{
   $str = array(":","-",);
   $str_replace = str_replace($str,",",$r['date']);
   $value = explode(",",$str_replace);
   for($i=0;$i<=count($value[0]);$i++)
   {
       if($i % 2 == 0)
       {  
               $val[] = $value[$i];
      }      
      else
      {
          $month[] = $value[$i];
      } 
       }
   }
   echo "<select style='margin-left:50%' class='day'>";
   
   foreach (array_unique($val) as $v) {
      echo "<option>".$v."</option>"; 
   }  
   echo "</select>";  
   echo "<select style='margin-left:2%' class='month'>";
   foreach (array_unique($month) as $m) {
      echo "<option>".$m."</option>"; 
   }  
   echo "</select><br><br><br>";  


echo "<div class='value'>";
echo "<table align=center style='border:2px solid black;line-height:30px;>";
echo "<tr style='border:2px solid black;padding:3%'>
         <td style='border:2px solid black'>Id</td>
         <td style='border:2px solid black'>Name</td>
         <td style='border:2px solid black'>Email</td>
         <td style='border:2px solid black'>Phone</td>
         <td style='border:2px solid black'>address</td>
         <td style='border:2px solid black'>Date</td>
         <td style='border:2px solid black'>Details</td>
 </tr>";
$q = mysqli_query($con,"select * from checkout");
while($r = mysqli_fetch_assoc($q))
{
   echo "<tr style='border:2px solid black'>";
   echo "<td style='border:2px solid black'>{$r['id']}</td>";
   echo "<td style='border:2px solid black'>{$r['Fname']} {$r['Lname']}</td>";
   echo "<td style='border:2px solid black'>{$r['email']}</td>";
   echo "<td style='border:2px solid black'>{$r['phone']}</td>";
   echo "<td style='border:2px solid black'>{$r['address']}</td>";
   echo "<td style='border:2px solid black'>{$r['date']}</td>";
   echo "<td style='border:2px solid black'><a href='viewproduct.php?id={$r[id]}'> View details </a></td>";
   echo "</tr>";
  
}
echo "</table>";
echo "</div>";
?>
   <a href="dashboard.php">back</a>
<?php
$alldata="";
$q = mysqli_query($con,"select * from checkout");
while($r = mysqli_fetch_assoc($q))
{
   $alldata.= $r['id'].','.$r['Fname'].','.$r['Lname'].','.$r['email'].','.$r['phone'].','.$r['address'].$r['date']."\n";
   $res = "data:text/csv;charset=utf-8\n";
   $res.=$alldata;

}
 echo "<br><a href='".$res."' class='btn btn-primary' style='margin-left:43%' download='c.csv'>Export Data</a>";
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
   $(".day").change(function(e){
      e.preventDefault();
  var value = $(this).val();
   $.ajax({
      url:"sorting_order_day.php",
      type:"post",
      data:{day:value},
      success:function(data)
      {
         $(".value").html(data);
      }
   }) 
   });
   $(".month").change(function(e){
      e.preventDefault();
  var value = $(this).val();
  $.ajax({
      url:"sorting_order_month.php",
      type:"post",
      data:{month:value},
      success:function(data)
      {
         $(".value").html(data);
      }
   }) 
   });
   </script>
