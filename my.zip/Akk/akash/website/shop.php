<?php
session_start();

if($_SESSION['user'] == "")
{
 header("location:login.php");
}
else
{
echo "<form method='post'>";
$con = mysqli_connect("localhost","root","root","website");
 $qe = mysqli_query($con,"select count(*),cname,pic from category_tbl group by cname,pic");
echo "<div style='display:flex'>";
while($r = mysqli_fetch_assoc($qe))
{?>
    <div style="border:2px solid black;width:19%;background-color:skyblue">
    <a href="showpro.php?c=<?php echo $r['cname']; ?>"><img src="Admin/img/<?php echo $r['pic']?>" alt="" width=250 height=250 align=center style="margin-top:2%;padding:2%;"><br></a>
   <a href="showpro.php?c=<?php echo $r['cname']; ?>"> <p align=center>Category Name: <?php echo $r["cname"]; ?></p></a>
     </div>
    &nbsp;
    &nbsp;
    &nbsp;
    <?php 
} 
echo "</div>";
echo "</form>";
}

?>