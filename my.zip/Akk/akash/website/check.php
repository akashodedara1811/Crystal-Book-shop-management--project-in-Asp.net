<div  style="display:flex" class='chance'>
<?php

session_start();session_unset($_SESSION['gtotal']);

?>

<div>
<h2> Contect Details</h2>
<table>
<form action="" method="post">
    <tr><td>First Name:</td><td><input type="text"  name='fname' class='fname' required></td></tr>
    <tr></tr>
   <tr><td>Last Name:</td><td><input type="text" name='lname' class='lname'></td></tr>
   <tr></tr>
    <tr><td>Email:</td><td><input type="text" name='email' class='email'></td></tr>
    <tr></tr>
    <tr><td>phone Name:</td><td><input type="text"  name='phone' class='phone'></td></tr>
    <tr></tr>
    <tr><td>Address :</td><td><textarea row=30 cols=20  name='address' class='address'></textarea></td></tr>
    <tr></tr>
    <tr><td></td><td><input type="submit"  name='sub' class='sub'></td></tr>
</form>
</table>
</div>
<form action="" method='post'>
    <input type="text" name="" placeholder="enter Coupen code" class='coupen'>
    <input type="submit" value="Get" class='get'>
</form>
<?php
$value = count($_SESSION['id']);
?>
<div style="margin-left:40%" class='chenge'>
    <h1>Order Details:</h1>
    <h3>Total Item(<?php echo $value; ?>)</h3>
    <?php
       
    $i = 0;
    $set = 0;
    foreach($_SESSION['id'] as $id)
    {
        $con = mysqli_connect("localhost","root","root","website");
        $q = mysqli_query($con,"select * from product_tbl where id='{$id}'");
        while($r = mysqli_fetch_assoc($q))
        {
            echo "<b><li>product Name:&nbsp;&nbsp;{$r['pname']}</li></b>";
            echo "<br>";
            echo "<p> Price :".$r['price']."( *{$_SESSION['value'][$i]})</p>";
            echo $r['price'] * $_SESSION['value'][$i];
            $set = $r['price'] * $_SESSION['value'][$i];
            $i++;
        }
      
    }
    if($_SESSION['total'] == "")
    {
     
        header("location:add.php");
    }
    else
    {
        if($set > $_SESSION['total'])
        {
            echo " <h2><li>Total :{$set}</li></h2>";
        }
        else
        {
    echo " <h2><li>Total :{$_SESSION['total']}</li></h2>";
        }
   }
    ?>
   
</div>
</div>
<?php
print_r($_SESSION['code']); 
 if(isset($_POST['sub']))
{
    echo "<script>{$_SESSION['coupen']}</script>";
      $cons = mysqli_query($con,"select * from offer where coupen='{$_SESSION['code']}' and cname='{$_SESSION['user']}'");
  if(mysqli_num_rows($cons) > 0)
  {
    echo "not inserted this code youcan allredy use this code";
  }
  else
  {
    if($_SESSION['gtotal'] == "")
    {
        $first_name = $_POST['fname'];
    $last_name = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $product_id = implode(",",$_SESSION['id']);
    $product_item = implode(",",$_SESSION['value']);
    $product_total = $_SESSION['total'];
    $code = $_SESSION['code'];
    
   $con = mysqli_connect("localhost","root","root","website");
  $q = mysqli_query($con,"select * from checkout where Fname = '{$first_name}'");
   if(mysqli_num_rows($q) > 0)
   {
    echo "already existed...";
    }
    else
    {
       $date = date("d-m-Y");
       $time = date("h:i");
       $current = $date."&nbsp".$time;
       $q = mysqli_query($con,"insert into checkout(Fname,Lname,email,phone,address,proid,proitems,progtotal,date,off) values ('{$first_name}','{$last_name}','{$email}','{$phone}','{$address}','{$product_id}','{$product_item}','{$product_total}','{$current}','{$code}')");
       header("location:thank.php");
        session_destroy();  
    } 
    }
    else
    {
        if($_SESSION['user'] != 1)
        {
        $first_name = $_POST['fname'];
    $last_name = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $product_id = implode(",",$_SESSION['id']);
    $product_item = implode(",",$_SESSION['value']);
    $product_total =$_SESSION['gtotal'] ;
    $code = $_SESSION['code'];
    session_unset($_SESSION['gtotal']);
   $con = mysqli_connect("localhost","root","root","website");
  $q = mysqli_query($con,"select * from checkout where Fname = '{$first_name}'");
   if(mysqli_num_rows($q) > 0)
   {
    echo "already existed...";
    }
    else
    {
       $date = date("d-m-Y");
       $time = date("h:i");
       $current = $date."&nbsp".$time;
       session_destroy();
       $q = mysqli_query($con,"insert into checkout(Fname,Lname,email,phone,address,proid,proitems,progtotal,date,off) values ('{$first_name}','{$last_name}','{$email}','{$phone}','{$address}','{$product_id}','{$product_item}','{$product_total}','{$current}','{$code}')");
        
              
    } 
    }
    mysqli_query($con,"delete from addpro"); 
    $code = $_SESSION['code'];
        
  $qz= mysqli_query($con,"select cname from offer");
$code = $_SESSION['code'];
$i=0;
while($r=mysqli_fetch_assoc($qz))
{
   $name[$i] = $r['cname'];
   $i++;
}
       
    header("location:thank.php");
    session_destroy(); 
}  
} 
$i = 0;
$num = 2;
$qew = mysqli_query($con,"select cname from offer where coupen='{$code}'");
while($r = mysqli_fetch_assoc($qew))
{
    foreach(explode(",",$r['cname']) as $n)
    {
     if($_SESSION['user'] != $n)
    {
        $num = 0;
        $nu[] = $r['cname'];
    } 
    else
    {
        $num = 1;
    }
            
    }
    $i++;
    }
    if($num == 0)
    {
        foreach($nu as $n)
        {
        $value = $n.",".$_SESSION['user'];
          }
        
       mysqli_query($con,"update offer set cname='{$value}' where coupen='{$code}'");
    }
    else
    {
        echo "<script>alert('you can you all redy this..')</script>";
        header("location:thank.php");
    }  
}

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
        $(".get").click(function(e)
        { 
            e.preventDefault();
           var coupen = $(".coupen").val();
           var name = $(".name").val();
           $.ajax({
            url : "offer.php",
            type:"post",
            data:{code:coupen,name:name},
            success:function(data)
            {
                if(data == "")
                {
                    alert('not mached');
                }
                else
                {
                $(".chenge").html(data);
            }
            }
           }) 
        })
        $(".sub").click(function(e){
           // e.preventDefault();
         // alert("this is workin");
         var fname = $(".fname").val();
         var lname = $(".lname").val();
         var email = $(".email").val();
         var phone = $(".phone").val();
         var address = $(".address").val();
         var coupen = $(".coupen").val();
         var code = $(".code").val();
         
          if(coupen == "")
         {
            $.ajax({
            url : "insert_check.php",
            type:"post",
            data:{code:code,fname:fname,lname:lname,email:email,phone:phone,address:address},
            success:function(data)
            {
              alert(data);
              //location.place("thank.php");
            }
           }) 
           $(location).prop("href","thank.php"); 
        } 
        });
    
          
       </script>
