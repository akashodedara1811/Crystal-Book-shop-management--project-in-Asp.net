<?php
$value = $_GET['p'];

$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from product_tbl where id='{$value}'");
echo "<div style='font-size:23px;background-color:lightyellow;position:relative'>";
while($r = mysqli_fetch_assoc($q))
{
    echo "<div align=right><img src='Admin/img/{$r["pic"]}' width=200 height=200/></div><br>";
    echo "<div align='right'><b>Id number :</b>&nbsp;&nbsp;{$r["id"]}</div><br>";
    echo "<div align='center'><b>Product Name:</b>&nbsp;&nbsp;{$r["pname"]}</div><br>";
    echo "<div ><b>Product Descriotion:</b>&nbsp;&nbsp;{$r["des"]}</div><br>";
    echo "<div align='center'><b>Product Category Name:</b>&nbsp;&nbsp;{$r["cname"]}</div><br>";
    echo "<div align='center'><b>Product Sub category Name:</b>&nbsp;&nbsp;{$r["scname"]}</div><br>";
    echo "<div align='center'><b>Product Price:</b>&nbsp;&nbsp;&nbsp;{$r["price"]}</div><br>";
    echo "<div align='center'><b>Product Stock:</b>&nbsp;&nbsp;&nbsp;{$r["stock"]}</div><br>";
    echo "<p align=center><a name='sub' data-id='{$r['id']}' class='value' href='add.php'>ADD TO CART</a></p>";
}
echo "</div>";
?>
<a href="index.php" style="font-size:30px">Back</a>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
     $(".value").click(function(e){
//e.preventDefault();
         var value  = $(this).data("id");
          $.ajax({
            url : "insert.php",
            type : "post",
            data :{id : value},
            success:function(data)
            {
           //alert(data);
            // $("#show").html(data);
            }
         });  
      });
</script>