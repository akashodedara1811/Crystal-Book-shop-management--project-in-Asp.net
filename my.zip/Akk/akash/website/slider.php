<?php
$min = $_POST['promin'];
$max = $_POST['promax'];
$name = $_POST['value'];
echo "name :".$name;
echo"<form method='post'>";
$con = mysqli_connect("localhost","root","root","website");
$q = mysqli_query($con,"select * from product_tbl where  price between {$min} and {$max}");
if(mysqli_num_rows($q) > 0)
{
    echo "<div style='display:flex'>";
   while($r = mysqli_fetch_assoc($q))
   {
    if($r["cname"] == $name)
    {
      ?>
              <div style="border:2px solid black;width:19%;color:gray">
             <a href="proinfo.php?p=<?php echo $r['id']?>"> <img src="Admin/img/<?php echo $r['pic']?>" alt="" width=250 height=250 align=center style="margin-top:2%;padding:2%;"></a><br>
             <a href="proinfo.php?p=<?php echo $r['id']?>"> <p align=center>Product Name: <?php echo $r["pname"]; ?></p></a>
              <p align=center>Product Description: <?php echo $r["sdes"]; ?></p>
               <p align=center>Product price: <?php echo $r["price"]; ?></p>

               <p align=center><a name="sub" data-id="<?php echo $r['id'] ?>" class="value" href="add.php">ADD TO CART</a></p>
             </div>
            &nbsp;
            &nbsp;
            &nbsp;
        <?php
        }   
    }
    echo "</div>";
   }

else
{
    echo "data not available .....";
}
echo "</form>";
?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
     $(".value").click(function(e){
         var value  = $(this).data("id");
          $.ajax({
            url : "insert.php",
            type : "post",
            data :{id : value},
            success:function(data)
            {
           // alert(data);
            // $("#show").html(data);
            }
         });  
      });
</script>