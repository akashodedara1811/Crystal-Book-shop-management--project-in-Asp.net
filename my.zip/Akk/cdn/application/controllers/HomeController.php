<?php
defined('BASEPATH')OR exit('No direct script access allowed');
class HomeController extends CI_Controller{

    public function index()
    {
        $this->load->model("HomeModel");
        $data['sum'] = $this->HomeModel->calsum();
        $data['sub'] = $this->HomeModel->calsub();//this array gets the model sub 
        $data['mul'] = $this->HomeModel->calmul();
        $data['div'] = $this->HomeModel->caldiv();
        $this->load->view("Home",$data);//this method calls automatically 
    }
    public function test(){
        echo "<h2>test function</h2>";
    }
}
?>