<h2>calculate the sum: <?php echo $sum ?></h2>
<h2>calculate the sub: <?php echo $sub ?></h2>
<h2>calculate the mul: <?php echo $mul ?></h2>
<h2>calculate the div: <?php echo $div ?></h2>