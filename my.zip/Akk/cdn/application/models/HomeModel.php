<?php
defined('BASEPATH')OR exit('No direct script access allowed');
class HomeModel extends CI_model{
    public function calsum()
    {
        $a = 1;
        $b = 2;
        return $a + $b;
    }
    public function calsub()
    {
        $a = 10;
        $b = 2;
        return $a - $b;
    }
    public function calmul()
    {
        $a = 5;
        $b = 2;
        return $a * $b;
    }
    public function caldiv()
    {
        $a = 10;
        $b = 2;
        return $a / $b;
    }
}